(() => {
  'use strict';

  const runtime = globalThis.browser?.runtime || globalThis.chrome?.runtime;
  const emit = (loggedIn) => {
    document.documentElement?.setAttribute('data-orion-extension', loggedIn ? 'ready' : 'installed');
    window.postMessage({ source: 'orion-extension', type: 'presence', installed: true, loggedIn }, window.location.origin);
  };
  const report = () => Promise.resolve(runtime?.sendMessage({ type: 'orion-status' }))
    .then(response => emit(Boolean(response?.loggedIn)), () => emit(false));

  window.addEventListener('message', (event) => {
    if (event.source === window && event.data?.source === 'orion-app' && event.data.type === 'ping') {
      report();
    }
  });
  report();
})();
