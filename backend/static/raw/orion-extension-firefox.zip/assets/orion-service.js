'use strict';

const api = (globalThis.chrome && globalThis.chrome.runtime) ? globalThis.chrome : globalThis.browser;
const REFRESH_ALARM = 'orion-token-refresh';
const ORION_ORIGINS = [
  'https://127.0.0.1:8443',
  'http://localhost:4200',
  'http://127.0.0.1:4200'
];

async function request(endpoint, options) {
  return Promise.any(ORION_ORIGINS.map(async (origin) => {
    const response = await fetch(`${origin}/api/extension/${endpoint}`, {
      credentials: 'include',
      cache: 'no-store',
      ...options
    });
    if (!response.ok) {
      throw new Error();
    }
    return true;
  })).catch(() => false);
}

api.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === REFRESH_ALARM) {
    request('refresh', { method: 'POST' });
  }
});
api.alarms.create(REFRESH_ALARM, { periodInMinutes: 10 });
request('refresh', { method: 'POST' });

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'orion-status') {
    return false;
  }

  request('session').then(loggedIn => sendResponse({ loggedIn }));
  return true;
});
