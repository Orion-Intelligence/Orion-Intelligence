import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const [extensionId, updateUrlValue, outputDirectory, extensionName] = process.argv.slice(2);

if (!extensionId || !updateUrlValue || !outputDirectory) {
  throw new Error(
    'Usage: node prepare-chromium-policies.mjs '
    + '<extension-id> <update-url> <output-directory> [<extension-name>]'
  );
}

if (!/^[a-p]{32}$/.test(extensionId)) {
  throw new Error(`Invalid Chromium extension ID: ${extensionId}`);
}

function validateHttpUrl(value, label) {
  let parsed;

  try {
    parsed = new URL(value);
  }
  catch {
    throw new Error(`${label} must be an absolute HTTP(S) URL: ${value}`);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error(`${label} must use HTTP or HTTPS: ${value}`);
  }

  if (parsed.username || parsed.password || parsed.hash) {
    throw new Error(`${label} cannot contain credentials or a fragment: ${value}`);
  }

  return parsed.href;
}

function xmlText(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function stableUuid(seed) {
  const digest = createHash('sha256').update(seed).digest();
  digest[6] = (digest[6] & 0x0f) | 0x50;
  digest[8] = (digest[8] & 0x3f) | 0x80;
  const hex = digest.subarray(0, 16).toString('hex').toUpperCase();
  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20, 32)
  ].join('-');
}

const updateUrl = validateHttpUrl(updateUrlValue, 'Chromium update URL');
const displayName = extensionName || 'Orion Social';
const forceListEntry = `${extensionId};${updateUrl}`;
const outputPath = resolve(outputDirectory);

for (const platform of ['linux', 'windows', 'macos']) {
  mkdirSync(resolve(outputPath, platform), { recursive: true });
}

const linuxPolicy = {
  ExtensionInstallForcelist: [forceListEntry],
  ExtensionSettings: {
    [extensionId]: {
      installation_mode: 'force_installed',
      update_url: updateUrl
    }
  }
};

writeFileSync(
  resolve(outputPath, 'linux', 'orion-social.json'),
  `${JSON.stringify(linuxPolicy, null, 2)}\n`,
  { mode: 0o644 }
);

const registryBranches = [
  'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Google\\Chrome\\ExtensionInstallForcelist',
  'HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Chromium\\ExtensionInstallForcelist'
];
const registryLines = ['Windows Registry Editor Version 5.00', ''];

for (const branch of registryBranches) {
  registryLines.push(`[${branch}]`, `"1"="${forceListEntry}"`, '');
}

writeFileSync(
  resolve(outputPath, 'windows', 'orion-social.reg'),
  Buffer.from(`﻿${registryLines.join('\r\n')}`, 'utf16le'),
  { mode: 0o644 }
);

const profileUuid = stableUuid(`${extensionId}:profile`);
const payloadUuid = stableUuid(`${extensionId}:payload`);
const mobileConfig = [
  '<?xml version="1.0" encoding="UTF-8"?>',
  '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">',
  '<plist version="1.0">',
  '<dict>',
  '  <key>PayloadDisplayName</key>',
  `  <string>${xmlText(displayName)} (Chrome)</string>`,
  '  <key>PayloadIdentifier</key>',
  `  <string>org.orionintelligence.chrome.${extensionId}</string>`,
  '  <key>PayloadType</key>',
  '  <string>Configuration</string>',
  '  <key>PayloadUUID</key>',
  `  <string>${profileUuid}</string>`,
  '  <key>PayloadVersion</key>',
  '  <integer>1</integer>',
  '  <key>PayloadScope</key>',
  '  <string>System</string>',
  '  <key>PayloadContent</key>',
  '  <array>',
  '    <dict>',
  '      <key>PayloadDisplayName</key>',
  `      <string>${xmlText(displayName)} force install</string>`,
  '      <key>PayloadIdentifier</key>',
  `      <string>com.google.Chrome.${extensionId}</string>`,
  '      <key>PayloadType</key>',
  '      <string>com.google.Chrome</string>',
  '      <key>PayloadUUID</key>',
  `      <string>${payloadUuid}</string>`,
  '      <key>PayloadVersion</key>',
  '      <integer>1</integer>',
  '      <key>ExtensionInstallForcelist</key>',
  '      <array>',
  `        <string>${xmlText(forceListEntry)}</string>`,
  '      </array>',
  '    </dict>',
  '  </array>',
  '</dict>',
  '</plist>',
  ''
].join('\n');

writeFileSync(
  resolve(outputPath, 'macos', 'orion-social.mobileconfig'),
  mobileConfig,
  { mode: 0o644 }
);

process.stdout.write(outputPath);
