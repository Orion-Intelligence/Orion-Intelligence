'use strict';

const SAME_SITE_IN = { None: 'no_restriction', Lax: 'lax', Strict: 'strict' };
const PROTECTED_COOKIE_NAMES = new Set(['access_token', 'extension_access_token', 'session_present']);

async function storeIdForTab(tabId) {
  try {
    const stores = await api.cookies['getAllCookieStores']();
    const match = (stores || []).find((store) => Array.isArray(store['tabIds']) && store['tabIds'].includes(tabId));
    return match ? match.id : null;
  }
  catch (error) {
    void error;
    return null;
  }
}

async function appCookieHost() {
  try {
    const saved = await api.storage.local.get('orion-url');
    const url = saved['orion-url'];
    return typeof url === 'string' && url ? new URL(url).hostname : '';
  }
  catch (error) {
    void error;
    return '';
  }
}

async function clearCookies(storeId, url) {
  if (!storeId) {
    return;
  }
  let host = '';
  try {
    host = new URL(url).hostname;
  }
  catch (error) {
    void error;
    return;
  }
  const appHost = await appCookieHost();
  try {
    const all = await api.cookies.getAll({ storeId });
    for (const cookie of all || []) {
      const domain = String(cookie.domain || '').replace(/^\./, '');
      if (!domain) {
        continue;
      }
      const applies = cookie.hostOnly
        ? host === domain
        : (host === domain || host.endsWith(`.${domain}`) || domain.endsWith(`.${host}`));
      if (!applies) {
        continue;
      }
      if (appHost && (appHost === domain || appHost.endsWith(`.${domain}`))) {
        continue;
      }
      if (PROTECTED_COOKIE_NAMES.has(cookie.name) && host !== domain) {
        continue;
      }
      const target = `http${cookie.secure ? 's' : ''}://${domain}${cookie.path || '/'}`;
      try { await api.cookies.remove({ url: target, name: cookie.name, storeId }); } catch (error) { void error; }
    }
  }
  catch (error) {
    void error;
  }
}

async function seedCookies(storeId, cookies) {
  if (!storeId) {
    return;
  }
  const appHost = await appCookieHost();
  for (const cookie of cookies || []) {
    const domain = String(cookie.domain || '').replace(/^\./, '');
    if (!cookie.name || !domain) {
      continue;
    }
    if (PROTECTED_COOKIE_NAMES.has(cookie.name)) {
      continue;
    }
    if (appHost && (appHost === domain || appHost.endsWith(`.${domain}`) || domain.endsWith(`.${appHost}`))) {
      continue;
    }
    const path = String(cookie.path || '/');
    const target = `http${cookie.secure ? 's' : ''}://${domain}${path}`;
    const detail = {
      url: target,
      name: String(cookie.name),
      value: String(cookie.value ?? ''),
      path,
      secure: Boolean(cookie.secure),
      httpOnly: Boolean(cookie.httpOnly),
      sameSite: SAME_SITE_IN[cookie.sameSite] || 'unspecified',
      storeId,
    };
    if (String(cookie.domain || '').startsWith('.')) {
      detail.domain = String(cookie.domain);
    }
    const expires = Number(cookie.expires ?? -1);
    if (expires > 0) {
      detail.expirationDate = expires;
    }
    try { await api.cookies.set(detail); } catch (error) { void error; }
  }
}

globalThis['storeIdForTab'] = storeIdForTab;
globalThis['clearCookies'] = clearCookies;
globalThis['seedCookies'] = seedCookies;
