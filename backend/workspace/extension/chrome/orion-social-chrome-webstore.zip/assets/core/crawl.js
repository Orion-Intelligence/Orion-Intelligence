'use strict';

async function defaultStoreId() {
  try {
    const stores = await api.cookies['getAllCookieStores']();
    return stores && stores.length ? stores[0].id : '0';
  }
  catch (error) {
    void error;
    return '0';
  }
}

// A collector that needs a login reads it from the browser it runs in. Seeding
// an attached session first is what lets a signed-in crawl return more than the
// signed-out one, without the collector knowing a session was involved.
async function applySession(session) {
  const cookies = session && Array.isArray(session.cookies) ? session.cookies : [];
  if (!cookies.length) {
    return;
  }
  await seedCookies(await defaultStoreId(), cookies);
}

async function crawl(command) {
  console.info('[orion] crawl start', command.platform, command.crawl_type, command.url || command.username);
  if (command.session) {
    await applySession(command.session);
  }
  const entry = { platform: command.platform || '', url: command.url || '', status: 'crawling', startedAt: Date.now(), finishedAt: null };
  await recordActivity(entry);

  let items = [];
  if (command.url || command.username) {
    const response = await runInRunner(command);
    items = response && Array.isArray(response.items) ? response.items : [];
    entry.status = response ? (items.length ? 'done' : 'empty') : 'failed';
    entry.error = response?.error || (response ? '' : 'runner_unreachable');
  }
  else {
    entry.status = 'failed';
  }

  entry.finishedAt = Date.now();
  await recordActivity(entry);
  return { platform: command.platform, url: command.url, implemented: items.length > 0, items, error: entry.error || '' };
}

globalThis['crawl'] = crawl;

async function crawlAll(command) {
  console.info('[orion] crawl-all start', command.platform, command.url || command.username);
  if (command.session) {
    await applySession(command.session);
  }
  const entry = { platform: command.platform || '', url: command.url || '', status: 'crawling', startedAt: Date.now(), finishedAt: null };
  await recordActivity(entry);

  let items = [];
  let per_type = [];
  if (command.url || command.username) {
    const response = await runInRunner({ ...command, action: 'crawl-all' });
    items = response && Array.isArray(response.items) ? response.items : [];
    per_type = response && Array.isArray(response.per_type) ? response.per_type : [];
    entry.status = response ? (items.length ? 'done' : 'empty') : 'failed';
    entry.error = response?.error || (response ? '' : 'runner_unreachable');
  }
  else {
    entry.status = 'failed';
  }

  entry.finishedAt = Date.now();
  await recordActivity(entry);
  return { platform: command.platform, url: command.url, implemented: items.length > 0, items, per_type, error: entry.error || '' };
}

globalThis['crawlAll'] = crawlAll;

async function post(command) {
  console.info('[orion] post start', command.platform, command.url);
  if (!command.session) {
    return { platform: command.platform, url: command.url, ok: false, error: 'session_required' };
  }
  await applySession(command.session);
  const entry = { platform: command.platform || '', url: command.url || '', status: 'crawling', startedAt: Date.now(), finishedAt: null };
  await recordActivity(entry);

  const response = await runInRunner({ ...command, action: 'post' });
  const ok = Boolean(response && response.ok);
  entry.status = ok ? 'done' : 'failed';
  entry.error = response?.error || (response ? '' : 'runner_unreachable');
  entry.finishedAt = Date.now();
  await recordActivity(entry);
  return { platform: command.platform, url: command.url, ok, error: entry.error || '' };
}

globalThis['post'] = post;
