'use strict';

function seedStorageInPage(payload) {
  try {
    const local = payload.localStorage || {};
    for (const key of Object.keys(local)) {
      try { window.localStorage.setItem(key, String(local[key])); } catch (error) { void error; }
    }
    const session = payload.sessionStorage || {};
    for (const key of Object.keys(session)) {
      try { window.sessionStorage.setItem(key, String(session[key])); } catch (error) { void error; }
    }
    const databases = payload.indexedDB || {};
    for (const dbName of Object.keys(databases)) {
      const spec = databases[dbName] || {};
      const stores = spec.stores || {};
      const request = window.indexedDB.open(dbName, spec.version || 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const storeName of Object.keys(stores)) {
          if (db.objectStoreNames.contains(storeName)) { continue; }
          const meta = stores[storeName] || {};
          const opts = {};
          if (meta.keyPath !== undefined && meta.keyPath !== null) { opts.keyPath = meta.keyPath; }
          if (meta.autoIncrement) { opts.autoIncrement = true; }
          db.createObjectStore(storeName, opts);
        }
      };
      request.onsuccess = () => {
        const db = request.result;
        const names = Object.keys(stores).filter((name) => db.objectStoreNames.contains(name));
        if (!names.length) { db.close(); return; }
        const tx = db.transaction(names, 'readwrite');
        for (const storeName of names) {
          const store = tx.objectStore(storeName);
          for (const row of (stores[storeName].records || [])) {
            try {
              if (store.keyPath !== null && store.keyPath !== undefined) { store.put(row.value); }
              else { store.put(row.value, row.key); }
            }
            catch (error) { void error; }
          }
        }
        tx.oncomplete = () => db.close();
      };
    }
  }
  catch (error) {
    void error;
  }
}

async function wipeStorageInPage() {
  try { window.localStorage.clear(); } catch (error) { void error; }
  try { window.sessionStorage.clear(); } catch (error) { void error; }
  try {
    const databases = typeof window.indexedDB.databases === 'function' ? await window.indexedDB.databases() : [];
    for (const database of databases || []) {
      if (database && database.name) {
        try { window.indexedDB.deleteDatabase(database.name); } catch (error) { void error; }
      }
    }
  }
  catch (error) {
    void error;
  }
  try {
    const keys = await window.caches.keys();
    for (const key of keys) {
      try { await window.caches.delete(key); } catch (error) { void error; }
    }
  }
  catch (error) {
    void error;
  }
  try {
    const registrations = await navigator.serviceWorker.getRegistrations();
    for (const registration of registrations) {
      try { await registration.unregister(); } catch (error) { void error; }
    }
  }
  catch (error) {
    void error;
  }
}

function injectCapture() {
  if (!document.documentElement) {
    return false;
  }
  if (window.__orionCapture) {
    if (typeof window.__orionCaptureMount === 'function') {
      try { window.__orionCaptureMount(); } catch (error) { void error; }
    }
    return true;
  }
  const runtime = (globalThis['chrome'] || globalThis['browser']).runtime;
  const readStore = (store) => {
    const out = {};
    try {
      for (let index = 0; index < store.length; index += 1) {
        const key = store.key(index);
        out[key] = store.getItem(key);
      }
    }
    catch (error) {
      void error;
    }
    return out;
  };

  const isX = /(^|\.)(x|twitter)\.com$/i.test(location.hostname);
  const BEARER = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';

  const { card, head, dot, status, button, collapseBtn, body, siteValue, authValue, signInValue } = buildCard();
  let observedRoot = null;
  const mount = () => {
    const root = document.documentElement;
    if (!root) {
      return;
    }
    ensureStyle();
    if (card.parentNode !== root || !card.isConnected) {
      root.appendChild(card);
    }
    if (card.style.display === 'none' || card.style.visibility === 'hidden') {
      card.style.display = 'flex';
      card.style.visibility = 'visible';
    }
    if (observedRoot !== root) {
      observedRoot = root;
      try {
        new MutationObserver(mount).observe(root, { childList: true });
      }
      catch (error) {
        void error;
      }
    }
  };
  window.__orionCaptureMount = mount;
  window.__orionCapture = true;
  mount();
  setInterval(mount, 1000);
  wireCollapse();
  wireDrag();

  function ensureStyle() {
    if (!document.getElementById('orion-auto-style')) {
      const style = document.createElement('style');
      style.id = 'orion-auto-style';
      style.textContent = `
        #orion-auto-card,#orion-auto-card *{box-sizing:border-box}
        #orion-auto-card *{margin:0;letter-spacing:normal;text-transform:none}
        #orion-auto-card button{appearance:none;transition:background .15s ease,filter .15s ease,transform .15s ease;min-height:36px}
        #orion-auto-card button:focus-visible{outline:2px solid #a6d3ff;outline-offset:3px}
        #orion-auto-card .orion-collapse:hover{border-color:#ffffff38!important;color:#fff!important}
        #orion-auto-card .orion-chevron{transition:transform .2s ease;display:block}
        #orion-auto-card .orion-primary:hover:not(:disabled){filter:brightness(1.12)}
        #orion-auto-card .orion-primary:active:not(:disabled){transform:translateY(1px)}
        #orion-auto-card .orion-primary:disabled{opacity:.6;cursor:wait!important;box-shadow:none!important}
        #orion-auto-card .orion-row + .orion-row{border-top:1px solid #ffffff0d;padding-top:10px}
        @media(prefers-reduced-motion:reduce){#orion-auto-card *{transition:none!important}}
      `;
      (document.head || document.documentElement).appendChild(style);
    }
  }

  function buildCard() {
    const card = document.createElement('div');
    card.id = 'orion-auto-card';
    card.setAttribute('role', 'region');
    card.setAttribute('aria-label', 'Orion Session Generator');
    card.style.cssText = 'position:fixed;z-index:2147483647;left:16px;top:16px;display:flex;flex-direction:column;gap:16px;width:312px;max-width:calc(100vw - 32px);max-height:calc(100dvh - 32px);padding:16px;border-radius:16px;background:linear-gradient(145deg,#182638,#101923 75%);color:#f1f5fa;font:400 13px/1.5 system-ui,-apple-system,sans-serif;text-align:left;color-scheme:dark;box-shadow:0 16px 48px #020a1440,0 2px 8px #020a1430;border:1px solid #ffffff1f;overflow:hidden';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;gap:12px;flex-shrink:0;touch-action:none;user-select:none';
    head.title = 'Drag to move';
    const dot = document.createElement('span');
    dot.style.cssText = 'width:9px;height:9px;border-radius:50%;background:#4ea2f1;box-shadow:0 0 0 4px rgba(78,162,241,0.22);flex:0 0 auto;transition:background .2s';
    const title = document.createElement('span');
    title.textContent = 'Session Generator';
    title.style.cssText = 'font:650 14px/1.4 system-ui,sans-serif';
    const brand = document.createElement('span');
    brand.textContent = 'ORION';
    brand.style.cssText = 'display:block;font:700 10px/1.6 system-ui,sans-serif;letter-spacing:1.8px;color:#93b5d7';
    title.prepend(brand);
    head.style.cursor = 'move';
    const collapseBtn = document.createElement('button');
    collapseBtn.className = 'orion-collapse';
    collapseBtn.title = 'Collapse';
    collapseBtn.type = 'button';
    collapseBtn.setAttribute('aria-label', 'Collapse session panel');
    collapseBtn.setAttribute('aria-expanded', 'true');
    collapseBtn.setAttribute('aria-controls', 'orion-auto-body');
    collapseBtn.style.cssText = 'margin-left:auto;cursor:pointer;width:36px;height:36px;flex:0 0 auto;border:1px solid #ffffff26;border-radius:10px;background:transparent;color:#e7eff8;padding:0;display:flex;align-items:center;justify-content:center';
    const chevron = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    chevron.setAttribute('class', 'orion-chevron');
    chevron.setAttribute('viewBox', '0 0 24 24');
    chevron.setAttribute('width', '16');
    chevron.setAttribute('height', '16');
    chevron.setAttribute('fill', 'none');
    chevron.setAttribute('focusable', 'false');
    const chevronPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    chevronPath.setAttribute('d', 'M6 15l6-6 6 6');
    chevronPath.setAttribute('stroke', 'currentColor');
    chevronPath.setAttribute('stroke-width', '2');
    chevronPath.setAttribute('stroke-linecap', 'round');
    chevronPath.setAttribute('stroke-linejoin', 'round');
    chevron.appendChild(chevronPath);
    chevron.setAttribute('aria-hidden', 'true');
    chevron.style.cssText = 'width:16px;height:16px;flex:none;transform:rotate(0deg)';
    collapseBtn.appendChild(chevron);
    head.appendChild(dot);
    head.appendChild(title);
    head.appendChild(collapseBtn);
    const status = document.createElement('div');
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    status.setAttribute('aria-atomic', 'true');
    status.style.cssText = 'font:600 13px/1.5 system-ui,sans-serif;color:#e7eff8;padding:12px 14px;border-radius:10px;background:#60a5fa0d;border:1px solid #60a5fa26';
    status.textContent = 'Scanning page…';
    const details = document.createElement('div');
    details.style.cssText = 'display:flex;flex-direction:column;gap:10px;padding:2px;font:400 12px/1.5 system-ui,sans-serif;color:#c7d6e6';
    const makeRow = (label) => {
      const row = document.createElement('div');
      row.className = 'orion-row';
      row.style.cssText = 'display:flex;justify-content:space-between;gap:10px';
      const key = document.createElement('span');
      key.textContent = label;
      key.style.cssText = 'color:#8fb0cc;flex:0 0 auto';
      const val = document.createElement('span');
      val.style.cssText = 'color:#e2ebf5;font-weight:600;text-align:right;overflow-wrap:anywhere;min-width:0';
      row.appendChild(key);
      row.appendChild(val);
      details.appendChild(row);
      return val;
    };
    const siteValue = makeRow('Site');
    const authValue = makeRow('Authentication');
    const signInValue = makeRow('Account');
    siteValue.textContent = location.hostname || location.origin;
    authValue.textContent = '—';
    signInValue.textContent = 'Checking…';
    const button = document.createElement('button');
    button.className = 'orion-primary';
    button.type = 'button';
    button.textContent = 'Regenerate session';
    button.style.cssText = 'display:flex;align-items:center;justify-content:center;text-align:center;width:100%;min-height:44px;cursor:pointer;padding:12px;border-radius:10px;border:1px solid #ffffff1a;background:linear-gradient(135deg,#277ac6,#2064ad);color:#fff;font:650 13px/1.4 system-ui,sans-serif;box-shadow:0 4px 12px #00000020';
    const body = document.createElement('div');
    body.id = 'orion-auto-body';
    body.style.cssText = 'display:flex;flex-direction:column;gap:14px;overflow-y:auto;min-height:0;padding:3px;margin:-3px';
    const hint = document.createElement('div');
    hint.id = 'orion-auto-hint';
    hint.textContent = 'Sign in if needed, then regenerate to save this browser session.';
    hint.style.cssText = 'font:400 12px/1.6 system-ui,sans-serif;color:#a6b8cb';
    button.setAttribute('aria-describedby', hint.id);
    body.appendChild(status);
    body.appendChild(details);
    body.appendChild(hint);
    body.appendChild(button);
    card.appendChild(head);
    card.appendChild(body);
    return { card, head, dot, status, button, collapseBtn, body, siteValue, authValue, signInValue };
  }

  function wireCollapse() {
    let collapsed = false;
    const chevron = collapseBtn.querySelector('.orion-chevron');
    collapseBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      collapsed = !collapsed;
      body.style.display = collapsed ? 'none' : 'flex';
      card.style.gap = collapsed ? '0' : '16px';
      if (chevron) { chevron.style.transform = collapsed ? 'rotate(180deg)' : 'rotate(0deg)'; }
      collapseBtn.title = collapsed ? 'Expand' : 'Collapse';
      collapseBtn.setAttribute('aria-label', collapsed ? 'Expand session panel' : 'Collapse session panel');
      collapseBtn.setAttribute('aria-expanded', String(!collapsed));
      keepInViewport();
    });
  }

  function wireDrag() {
    let dragging = false;
    let dragX = 0;
    let dragY = 0;
    head.addEventListener('pointerdown', (event) => {
      if (collapseBtn.contains(event.target) || event.button !== 0) {
        return;
      }
      const rect = card.getBoundingClientRect();
      dragging = true;
      head.setPointerCapture(event.pointerId);
      dragX = event.clientX - rect.left;
      dragY = event.clientY - rect.top;
      card.style.transform = 'none';
      card.style.top = rect.top + 'px';
      card.style.left = rect.left + 'px';
      card.style.right = 'auto';
      event.preventDefault();
    });
    head.addEventListener('pointermove', (event) => {
      if (!dragging) {
        return;
      }
      const x = Math.max(16, Math.min(event.clientX - dragX, window.innerWidth - card.offsetWidth - 16));
      const y = Math.max(16, Math.min(event.clientY - dragY, window.innerHeight - card.offsetHeight - 16));
      card.style.left = x + 'px';
      card.style.top = y + 'px';
    });
    head.addEventListener('pointerup', () => { dragging = false; });
    head.addEventListener('pointercancel', () => { dragging = false; });
    head.addEventListener('lostpointercapture', () => { dragging = false; });
    window.addEventListener('resize', keepInViewport);
    new ResizeObserver(keepInViewport).observe(card);
  }

  function keepInViewport() {
    const rect = card.getBoundingClientRect();
    card.style.left = Math.max(16, Math.min(rect.left, window.innerWidth - rect.width - 16)) + 'px';
    card.style.top = Math.max(16, Math.min(rect.top, window.innerHeight - rect.height - 16)) + 'px';
  }

  const setStatus = (text, color) => {
    status.textContent = text;
    if (color) {
      dot.style.background = color;
      dot.style.boxShadow = '0 0 0 4px ' + color + '22';
    }
  };
  const refreshInfo = (state) => {
    const auth = hasAuth();
    authValue.textContent = !isX ? 'Site managed' : auth ? 'Cookie detected' : 'Not detected';
    signInValue.textContent = state === 'in' ? 'Signed in' : state === 'out' ? 'Signed out' : 'Not verified';
  };

  const csrf = () => (document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/) || [])[1] || '';
  const hasAuth = () => /(?:^|;\s*)auth_token=/.test(document.cookie) || Boolean(csrf());

  const isChallenge = () => {
    const t = (document.title || '').toLowerCase();
    if (t.includes('just a moment') || t.includes('checking your browser') || t.includes('attention required')) {
      return true;
    }
    const onScreen = (el) => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    if (Array.from(document.querySelectorAll('iframe[src*="challenges.cloudflare.com"], #challenge-running, #challenge-form')).some(onScreen)) {
      return true;
    }
    const body = ((document.body && document.body.innerText) || '').toLowerCase();
    return body.includes('verify you are human') || body.includes('verifying you are human') || body.includes('needs to review the security');
  };

  const CLICK_LABELS = ['accept all cookies', 'accept cookies', 'accept all', 'allow all cookies', 'allow all', 'allow cookies', 'i accept', 'i agree to cookies', 'got it'];
  const CLICK_SELECTORS = ['#onetrust-accept-btn-handler', '[data-testid="cookie-policy-manage-dialog-accept-button"]', '[data-cookiebanner="accept_button"]', '[aria-label="Accept all cookies"]', '[aria-label="Allow all cookies"]'];
  const visible = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  };
  const isUnsafe = (el) => {
    if (el.type === 'submit' || el.getAttribute('type') === 'submit') {
      return true;
    }
    const form = el.closest('form');
    if (form && form.querySelector('input[type="password"]')) {
      return true;
    }
    const probe = ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.name || '') + ' ' + (el.id || '')).toLowerCase();
    return /log ?in|sign ?in|sign ?up|register|continue|submit|next|confirm/.test(probe);
  };
  const dismissBlockers = () => {
    let clicked = 0;
    const hit = (el) => {
      if (el && !card.contains(el) && visible(el) && !isUnsafe(el)) {
        try { el.click(); clicked += 1; } catch (error) { void error; }
      }
    };
    CLICK_SELECTORS.forEach((selector) => document.querySelectorAll(selector).forEach(hit));
    document.querySelectorAll('button, [role="button"], a[role="button"]').forEach((el) => {
      if (card.contains(el)) {
        return;
      }
      const label = (el.textContent || '').trim().toLowerCase();
      if (label && label.length <= 24 && CLICK_LABELS.includes(label)) {
        hit(el);
      }
    });
    return clicked;
  };

  let done = false;
  let tries = 0;
  const withTimeout = (promise, ms, fallback) => Promise.race([
    promise,
    new Promise((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);

  const dumpIndexedDBInner = async () => {
    const out = {};
    if (!globalThis.indexedDB || typeof indexedDB.databases !== 'function') {
      return out;
    }
    let dbs = [];
    try {
      dbs = await withTimeout(indexedDB.databases(), 2000, []);
    }
    catch (error) {
      void error;
      return out;
    }
    for (const info of dbs) {
      const name = info && info['name'];
      if (!name) {
        continue;
      }
      try {
        const db = await withTimeout(new Promise((resolve, reject) => {
          const request = indexedDB.open(name);
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
          request.onblocked = () => resolve(null);
        }), 2000, null);
        if (!db) {
          continue;
        }
        const storeNames = Array.from(db['objectStoreNames']);
        const stores = {};
        for (const storeName of storeNames) {
          try {
            const dumped = await withTimeout(new Promise((resolve, reject) => {
              const tx = db['transaction'](storeName, 'readonly');
              const store = tx.objectStore(storeName);
              const meta = { keyPath: store.keyPath, autoIncrement: store.autoIncrement, records: [] };
              const cursorRequest = store.openCursor();
              cursorRequest.onsuccess = () => {
                const cursor = cursorRequest.result;
                if (cursor) {
                  meta.records.push({ key: cursor.key, value: cursor.value });
                  cursor.continue();
                }
                else {
                  resolve(meta);
                }
              };
              cursorRequest.onerror = () => reject(cursorRequest.error);
            }), 2000, { keyPath: null, autoIncrement: false, records: [] });
            stores[storeName] = dumped;
          }
          catch (error) {
            void error;
          }
        }
        out[name] = { version: db['version'], stores };
        db['close']();
      }
      catch (error) {
        void error;
      }
    }
    return out;
  };

  const dumpIndexedDB = () => withTimeout(dumpIndexedDBInner(), 6000, {});

  let capturing = false;
  const capture = async (username) => {
    if (capturing) {
      return;
    }
    capturing = true;
    done = true;
    button.disabled = true;
    button.textContent = 'Collecting session…';
    button.setAttribute('aria-busy', 'true');
    setStatus('Collecting your browser session…', '#4ea2f1');
    if (username) { signInValue.textContent = '@' + username; }
    let indexedDb = {};
    try {
      indexedDb = await dumpIndexedDB();
    }
    catch (error) {
      void error;
    }
    try {
      await runtime.sendMessage({
        type: 'orion-session-captured',
        origin: location.origin,
        username,
        userAgent: navigator.userAgent,
        localStorage: readStore(localStorage),
        sessionStorage: readStore(sessionStorage),
        indexedDB: indexedDb
      });
      setStatus('Session sent to Orion', '#3ddc84');
      button.textContent = 'Session sent';
    }
    catch (error) {
      capturing = false;
      done = false;
      button.disabled = false;
      button.textContent = 'Try again';
      setStatus('Could not send session. Please try again.', '#f47174');
    }
    finally {
      button.setAttribute('aria-busy', 'false');
    }
  };
  const checkLogin = async () => {
    const token = csrf();
    if (!token) {
      return 'unknown';
    }
    try {
      const response = await fetch('https://api.x.com/1.1/account/settings.json', {
        credentials: 'include',
        headers: {
          authorization: 'Bearer ' + BEARER,
          'x-csrf-token': token,
          'x-twitter-active-user': 'yes',
          'x-twitter-auth-type': 'OAuth2Session'
        }
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.screen_name) {
          return 'in';
        }
        return 'unknown';
      }
      if (response.status === 401 || response.status === 403) {
        return 'out';
      }
    }
    catch (error) {
      void error;
    }
    return 'unknown';
  };

  const tick = async () => {
    if (done) {
      return;
    }
    tries += 1;
    mount();
    if (isChallenge()) {
      setStatus('Security check in progress…', '#f4b740');
      if (tries < 300) {
        setTimeout(tick, 2000);
      }
      return;
    }
    const cleared = dismissBlockers();
    const state = isX ? await checkLogin() : 'unknown';
    if (done) { return; }
    refreshInfo(state);
    if (!isX) {
      setStatus('Ready to capture this session', '#4ea2f1');
      return;
    }
    if (state === 'in') {
      setStatus('Signed in · Ready to regenerate', '#3ddc84');
      return;
    }
    if (state === 'out') {
      setStatus('Signed out — please log in', '#f47174');
    }
    else if (hasAuth()) {
      setStatus('Verifying session…', '#4ea2f1');
    }
    else {
      setStatus(cleared ? 'Cleared a prompt — waiting for sign-in…' : 'Waiting for you to sign in…', '#4ea2f1');
    }
    if (tries < 300) {
      setTimeout(tick, 2000);
    }
    else {
      setStatus('Automatic checking paused. Regenerate when ready.', '#f4b740');
    }
  };

  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Checking session…';
    setStatus('Checking session…', '#4ea2f1');
    dismissBlockers();
    if (isX) {
      const state = await checkLogin();
      if (state === 'out') {
        setStatus('Signed out — sign in, then regenerate', '#f47174');
        button.disabled = false;
        button.textContent = 'Regenerate session';
        return;
      }
    }
    void capture('');
  });

  if (!isX) {
    setStatus('Sign in on this page to capture', '#f4b740');
  }
  void tick();
  return true;
}

globalThis['seedStorageInPage'] = seedStorageInPage;
globalThis['wipeStorageInPage'] = wipeStorageInPage;
globalThis['injectCapture'] = injectCapture;
