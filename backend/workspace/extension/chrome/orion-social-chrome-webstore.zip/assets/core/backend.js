'use strict';

const ORION_URL_KEY = 'orion-url';
const ORION_URLS_KEY = 'orion-urls';
const ORION_TOKEN_KEY = 'orion-token';
const ORION_REMOTE_URL = 'https://try.orionintelligence.org';
const ORION_LOCAL_URL = 'http://localhost:4200';

async function isDevelopmentInstall() {
  try {
    const self = await api.management['getSelf']();
    return self && self.installType === 'development';
  }
  catch (error) {
    void error;
    return false;
  }
}

async function ensureDefaultUrls() {
  try {
    const defaults = (await isDevelopmentInstall()) ? [ORION_LOCAL_URL, ORION_REMOTE_URL] : [ORION_REMOTE_URL];
    const saved = await api.storage.local.get([ORION_URL_KEY, ORION_URLS_KEY]);
    const urls = Array.isArray(saved[ORION_URLS_KEY]) ? saved[ORION_URLS_KEY].filter((url) => typeof url === 'string') : [];
    const merged = urls.concat(defaults.filter((url) => !urls.includes(url)));
    const selected = typeof saved[ORION_URL_KEY] === 'string' ? saved[ORION_URL_KEY] : '';
    const update = {};
    if (merged.length !== urls.length) {
      update[ORION_URLS_KEY] = merged;
    }
    if (!selected) {
      update[ORION_URL_KEY] = defaults[0];
    }
    if (Object.keys(update).length) {
      await api.storage.local.set(update);
    }
  }
  catch (error) {
    void error;
  }
}

async function authHeaders(initialHeaders) {
  const headers = new Headers(initialHeaders);
  const saved = await api.storage.local.get(ORION_TOKEN_KEY);
  const token = saved[ORION_TOKEN_KEY];
  if (typeof token === 'string' && token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  return headers;
}

async function request(endpoint, options) {
  const saved = await api.storage.local.get(ORION_URL_KEY);
  const origin = saved[ORION_URL_KEY];
  if (!origin) {
    return null;
  }

  try {
    const headers = await authHeaders(options && options.headers);
    const response = await fetch(`${origin}/api/extension/${endpoint}`, { credentials: 'include', cache: 'no-store', ...options, headers });
    return response.ok ? origin : null;
  }
  catch (error) {
    void error;
    return null;
  }
}

async function wsTicket() {
  const saved = await api.storage.local.get(ORION_URL_KEY);
  const origin = saved[ORION_URL_KEY];
  if (!origin) {
    return null;
  }

  try {
    const response = await fetch(`${origin}/api/extension/ws-ticket`, { method: 'POST', credentials: 'include', cache: 'no-store', headers: await authHeaders() });
    if (!response.ok) {
      return null;
    }
    const body = await response.json();
    return body && typeof body.ticket === 'string' ? body.ticket : null;
  }
  catch (error) {
    void error;
    return null;
  }
}

globalThis['ensureDefaultUrls'] = ensureDefaultUrls;
globalThis['request'] = request;
globalThis['wsTicket'] = wsTicket;
