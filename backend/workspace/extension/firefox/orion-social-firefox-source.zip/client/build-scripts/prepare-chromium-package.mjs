import { createHash, createPublicKey } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const [
  sourceDirectory,
  signingKeyFile,
  updateUrlValue,
  crxUrlValue,
  updatesFile
] = process.argv.slice(2);

if (!sourceDirectory || !signingKeyFile) {
  throw new Error(
    'Usage: node prepare-chromium-package.mjs '
    + '<source-directory> <signing-key> [<update-url> <crx-url> <updates-file>]'
  );
}

const updateArguments = [updateUrlValue, crxUrlValue, updatesFile];
const shouldGenerateUpdates = updateArguments.every(Boolean);

if (!shouldGenerateUpdates && updateArguments.some(Boolean)) {
  throw new Error('Chromium update URL, CRX URL, and updates file must be provided together');
}

function validateHttpUrl(value, label) {
  let parsed;

  try {
    parsed = new URL(value);
  }
  catch {
    throw new Error(`${label} must be an absolute HTTP(S) URL: ${value}`);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error(`${label} must use HTTP or HTTPS: ${value}`);
  }

  if (parsed.username || parsed.password || parsed.hash) {
    throw new Error(`${label} cannot contain credentials or a fragment: ${value}`);
  }

  return parsed.href;
}

function xmlAttribute(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function extensionId(publicKey) {
  const digest = createHash('sha256').update(publicKey).digest('hex').slice(0, 32);
  return [...digest]
    .map(character => String.fromCharCode('a'.charCodeAt(0) + Number.parseInt(character, 16)))
    .join('');
}

const sourcePath = resolve(sourceDirectory);
const manifestPath = resolve(sourcePath, 'manifest.json');
const updateUrl = shouldGenerateUpdates
  ? validateHttpUrl(updateUrlValue, 'Chromium update URL')
  : undefined;
const crxUrl = shouldGenerateUpdates
  ? validateHttpUrl(crxUrlValue, 'Chromium CRX URL')
  : undefined;
const privateKey = readFileSync(resolve(signingKeyFile));
const publicKey = createPublicKey(privateKey).export({ type: 'spki', format: 'der' });
const id = extensionId(publicKey);
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));

if (typeof manifest.version !== 'string' || !/^\d+(?:\.\d+){0,3}$/.test(manifest.version)) {
  throw new Error(`Invalid Chromium extension version: ${String(manifest.version)}`);
}

manifest.key = publicKey.toString('base64');
if (shouldGenerateUpdates) {
  manifest.update_url = updateUrl;
}
else {
  delete manifest.update_url;
}
writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o644 });

if (shouldGenerateUpdates) {
  const updatesXml = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<gupdate xmlns="http://www.google.com/update2/response" protocol="2.0">',
    `  <app appid="${id}">`,
    `    <updatecheck codebase="${xmlAttribute(crxUrl)}" version="${xmlAttribute(manifest.version)}" />`,
    '  </app>',
    '</gupdate>',
    ''
  ].join('\n');

  writeFileSync(resolve(updatesFile), updatesXml, { mode: 0o644 });
}
process.stdout.write(id);
