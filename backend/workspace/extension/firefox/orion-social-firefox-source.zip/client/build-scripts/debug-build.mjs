import { rm } from 'node:fs/promises';

const prerenderRoutesPath = new URL('../build/prerendered-routes.json', import.meta.url);
await rm(prerenderRoutesPath, { force: true });
console.log('Debug bundle ready (console preserved, harden skipped)');
