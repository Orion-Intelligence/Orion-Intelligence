'use strict';

async function crawl(command) {
  console.info('[orion] crawl start', command.platform, command.crawl_type, command.url || command.username);
  const entry = { platform: command.platform || '', url: command.url || '', status: 'crawling', startedAt: Date.now(), finishedAt: null };
  await recordActivity(entry);

  let items = [];
  if (command.url || command.username) {
    const response = await runInRunner(command);
    items = response && Array.isArray(response.items) ? response.items : [];
    entry.status = response ? (items.length ? 'done' : 'empty') : 'failed';
    entry.error = response?.error || (response ? '' : 'runner_unreachable');
  }
  else {
    entry.status = 'failed';
  }

  entry.finishedAt = Date.now();
  await recordActivity(entry);
  return { platform: command.platform, url: command.url, implemented: items.length > 0, items, error: entry.error || '' };
}

globalThis['crawl'] = crawl;
