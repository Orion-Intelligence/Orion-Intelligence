'use strict';

async function tabReady(tabId) {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const tab = await api.tabs.get(tabId);
      if (tab.status === 'complete') {
        return true;
      }
    }
    catch (error) {
      void error;
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return false;
}

async function incognitoAllowed() {
  try {
    return Boolean(await api.extension['isAllowedIncognitoAccess']());
  }
  catch (error) {
    void error;
    return false;
  }
}

async function startCapture(url, sendResponse, seed) {
  const useIncognito = await incognitoAllowed();
  let win = null;
  try {
    win = await api.windows.create({ url: api.runtime.getURL('assets/verifying.html'), type: 'popup', incognito: useIncognito, focused: true, width: 960, height: 820 });
  }
  catch (error) {
    void error;
    win = null;
  }
  if (!win) {
    try {
      win = await api.windows.create({ url: api.runtime.getURL('assets/verifying.html'), type: 'popup', focused: true, width: 960, height: 820 });
    }
    catch (error) {
      void error;
      win = null;
    }
  }
  if (!win || !win.tabs || !win.tabs[0]) {
    sendResponse(null);
    return;
  }
  const tab = win.tabs[0];
  const winId = win.id;
  sessionWindowId = winId;
  const onReady = (tabId, info) => {
    if (tabId === tab.id && info.status === 'complete') {
      api.scripting['executeScript']({ target: { tabId: tab.id }, func: injectCapture }).catch((error) => void error);
    }
  };
  const entry = { sendResponse, url, onReady, storeId: null };
  sessionPending.set(tab.id, entry);
  const stillOpen = () => sessionWindowId === winId && sessionPending.has(tab.id);

  await tabReady(tab.id);
  if (!stillOpen()) {
    return;
  }
  const storeId = await storeIdForTab(tab.id);
  entry.storeId = storeId;
  if (useIncognito || seed) {
    await clearCookies(storeId, url);
  }
  if (!stillOpen()) {
    return;
  }
  if (seed) {
    if (storeId) {
      await seedCookies(storeId, seed.cookies || []);
    }
    await seedWindow(tab.id, url, seed);
    if (!stillOpen()) {
      return;
    }
  }
  api.tabs['onUpdated'].addListener(onReady);
  await api.tabs.update(tab.id, { url });
}

async function seedWindow(tabId, url, session) {
  if (!session) {
    return;
  }
  const storeId = await storeIdForTab(tabId);
  if (storeId) {
    await clearCookies(storeId, url);
    await seedCookies(storeId, session.cookies || []);
  }
  const hasStorage = Object.keys(session.localStorage || {}).length
    || Object.keys(session.sessionStorage || {}).length
    || Object.keys(session.indexedDB || {}).length;
  if (!hasStorage) {
    return;
  }
  await api.tabs.update(tabId, { url });
  await tabReady(tabId);
  try {
    await api.scripting['executeScript']({ target: { tabId }, world: 'MAIN', func: seedStorageInPage, args: [session] });
  }
  catch (error) {
    void error;
  }
}

globalThis['startCapture'] = startCapture;
