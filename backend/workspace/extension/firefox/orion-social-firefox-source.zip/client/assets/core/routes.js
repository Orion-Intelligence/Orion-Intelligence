'use strict';

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'orion-socket' && message.info) {
    api.storage.local.set({ 'orion-socket': message.info }).then(() => sendResponse({ ok: true }), () => sendResponse({ ok: false }));
    return true;
  }

  if (message?.type === 'orion-ws-ticket') {
    wsTicket().then((ticket) => sendResponse({ ticket }), () => sendResponse({ ticket: null }));
    return true;
  }

  if (message?.type === 'orion-url') {
    api.storage.local.get(ORION_URL_KEY).then((saved) => sendResponse({ url: saved[ORION_URL_KEY] || '' }), () => sendResponse({ url: '' }));
    return true;
  }

  void ensureRunner();

  if (message?.type === 'orion-tab-open') {
    tabOpen(message.active, message.popup).then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === 'orion-tab-close' && message.tabId != null) {
    tabClose(message.tabId).then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === 'orion-tab-run' && message.tabId != null && message.action) {
    tabRun(message.tabId, message.action, message.value).then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === 'orion-crawl') {
    crawl({ platform: message.platform, url: message.url, username: message.username, crawl_type: message.crawl_type }).then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === 'orion-activity') {
    readActivity().then((items) => sendResponse({ items, active: items.filter((item) => item.status === 'crawling').length }));
    return true;
  }

  if (message?.type === 'orion-activity-record' && message.entry && typeof message.entry.startedAt === 'number') {
    recordActivity(message.entry).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === 'orion-verify-tab') {
    sendResponse({ isVerifyTab: isVerifyTab(sender.tab && sender.tab.id) });
    return false;
  }

  if (message?.type === 'orion-verify-open' && message.url) {
    openVerifyWindow(message.url, message.session).then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === 'orion-verify-close') {
    closeVerifyWindow(message.windowId).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message?.type === 'orion-session' && message.url) {
    if (sessionWindowId !== null) {
      sendResponse(null);
      return true;
    }
    startCapture(message.url, sendResponse, message.payload && message.payload.seed);
    return true;
  }

  if (message?.type === 'orion-session-captured') {
    const tabId = sender.tab && sender.tab.id;
    const entry = sessionPending.get(tabId);
    if (entry) {
      sessionPending.delete(tabId);
      if (entry.onReady) {
        api.tabs.onUpdated.removeListener(entry.onReady);
      }
      const scope = entry.storeId ? { storeId: entry.storeId } : {};
      const hostname = (() => { try { return new URL(entry.url).hostname; } catch (error) { void error; return ''; } })();
      const registrable = hostname.split('.').slice(-2).join('.');
      const byKey = new Map();
      const collect = async (query) => {
        try {
          const found = await api.cookies.getAll({ ...query, ...scope });
          for (const cookie of found) {
            byKey.set(cookie.name + ' ' + cookie.domain + ' ' + cookie.path, cookie);
          }
        }
        catch (error) {
          void error;
        }
      };
      (async () => {
        await collect({ url: entry.url });
        if (hostname) { await collect({ domain: hostname }); }
        if (registrable && registrable !== hostname) { await collect({ domain: registrable }); }
        const cookies = Array.from(byKey.values());
        entry.sendResponse({ cookies, localStorage: message.localStorage, sessionStorage: message.sessionStorage, indexedDB: message.indexedDB || {}, origin: message.origin, username: message.username || '', userAgent: message.userAgent || '' });
        api.tabs.remove(tabId).catch(() => {});
      })();
    }
    return false;
  }

  if (message?.type === 'orion-open') {
    Promise.resolve(api.action.openPopup?.()).catch(() => undefined);
    return false;
  }

  if (message?.type !== 'orion-status') {
    return false;
  }

  request('session').then((origin) => sendResponse({ loggedIn: !!origin }));
  return true;
});
