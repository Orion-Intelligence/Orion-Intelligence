(() => {
  'use strict';

  const api = globalThis.browser || globalThis.chrome;
  const ID = 'orion-verify-overlay';

  const lockScroll = () => {
    if (document.documentElement) {
      document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    }
    if (document.body) {
      document.body.style.setProperty('overflow', 'hidden', 'important');
    }
  };

  const paint = () => {
    lockScroll();
    if (document.getElementById(ID)) {
      return;
    }
    const root = document.documentElement;
    if (!root) {
      return;
    }
    const overlay = document.createElement('div');
    overlay.id = ID;
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;gap:12px;background:#080e16;opacity:0.5;color:#f5f8fb;font:600 15px system-ui,-apple-system,sans-serif;cursor:progress;user-select:none';
    const style = document.createElement('style');
    style.textContent = '@keyframes orion-spin{to{transform:rotate(360deg)}}';
    const spinner = document.createElement('span');
    spinner.style.cssText = 'width:18px;height:18px;border-radius:50%;border:2px solid #4ea2f1;border-top-color:transparent;animation:orion-spin 0.8s linear infinite';
    const label = document.createElement('span');
    label.textContent = 'Verifying session…';
    overlay.appendChild(style);
    overlay.appendChild(spinner);
    overlay.appendChild(label);
    root.appendChild(overlay);
  };

  paint();
  new MutationObserver(paint).observe(document.documentElement, { childList: true, subtree: false });
  document.addEventListener('DOMContentLoaded', paint);

  const swallow = (event) => { event.stopPropagation(); event.preventDefault(); };
  ['click', 'mousedown', 'mouseup', 'keydown', 'keyup', 'keypress', 'submit', 'contextmenu', 'wheel', 'touchstart'].forEach((name) => {
    window.addEventListener(name, swallow, true);
  });

  let attempts = 0;
  const confirmTab = () => {
    try {
      api.runtime.sendMessage({ type: 'orion-verify-tab' }, (response) => {
        void api.runtime.lastError;
        if (response && response.isVerifyTab) {
          return;
        }
        attempts += 1;
        if (attempts < 12) {
          setTimeout(confirmTab, 150);
          return;
        }
        const existing = document.getElementById(ID);
        if (existing) {
          existing.remove();
        }
      });
    }
    catch (error) {
      void error;
    }
  };
  confirmTab();
})();
