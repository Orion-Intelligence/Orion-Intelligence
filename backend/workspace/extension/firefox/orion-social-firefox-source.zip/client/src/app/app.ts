import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './shared/service/auth.service';
import { SocketService } from './shared/service/socket.service';
import { CrawlRunner } from './extension/crawl.runner';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.html'
})
export class App {
  private readonly socket = inject(SocketService);
  private readonly runner = inject(CrawlRunner);

  readonly auth = inject(AuthService);

  constructor() {
    if (!globalThis.location?.search?.includes('runner=1')) {
      return;
    }

    this.socket.connect();
    this.runner.install();
  }
}
