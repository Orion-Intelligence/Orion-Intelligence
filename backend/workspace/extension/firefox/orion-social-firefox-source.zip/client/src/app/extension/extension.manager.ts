import { inject, Injectable } from '@angular/core';
import { CRAWL_ERRORS } from '../../crawler/constant/crawlers';
import { ChallengeError, ChallengeGuard } from '../../crawler/helper/challenge_guard';
import { SessionExport } from '../../crawler/helper/session_export';
import { Crawler } from '../../crawler/abstract/crawler';
import { Identity } from '../../crawler/helper/identity';
import { setVisibilityCrawling, TabController } from '../../crawler/tab_management/tab.controller';
import { CRAWLERS, CRAWL_TYPES } from './constant/extension.constant';
import { CrawlPage, CrawlPayload, CrawlType, ExtensionCommand, ExtensionResult } from './model/extension.model';

const RETRY_DELAY_MS = 1_200;

@Injectable({ providedIn: 'root' })
export class ExtensionManager {
  private readonly challenge = this.#resolveGuard();
  private readonly session = this.#resolve(SessionExport);

  constructor() {
    this.challenge.install();
  }

  async invoke(command: ExtensionCommand): Promise<ExtensionResult> {
    const platform = String(command.platform ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const type = String(command.type ?? '').toLowerCase() as CrawlType;

    if (String(command.command ?? '').toLowerCase() === 'platforms') {
      const items = Object.values(CRAWLERS).filter((crawler) => crawler.profiling).map((crawler) => ({ platform: crawler.platform, base: crawler.base }));
      return { platform, type, implemented: true, items };
    }

    if (String(command.command ?? '').toLowerCase() === 'session') {
      const file = await this.session.export(command.url ?? command.payload?.url ?? '', command.payload?.seed);
      return { platform, type, implemented: !!file, items: file ? [file] : [] };
    }

    if (String(command.command ?? '').toLowerCase() === 'verify') {
      const target = CRAWLERS[platform];
      const identify = target?.identity;
      if (!target || typeof identify !== 'function') {
        return { platform, type, implemented: false, items: [], error: 'unsupported platform' };
      }
      const url = target.base || String(command.url ?? command.payload?.['url'] ?? '');
      const opened = await this.session.openVerifyTab(url, command.payload?.['session']);
      if (opened.error || typeof opened.tabId !== 'number') {
        return { platform, type, implemented: false, items: [], error: opened.error || 'verify_window_failed' };
      }
      const tab = new TabController();
      tab.attach(opened.tabId);
      let result: Identity = { loggedIn: false, username: '' };
      try {
        result = await Promise.race([
          identify.call(target, tab),
          new Promise<Identity>((resolve) => setTimeout(() => resolve({ loggedIn: false, username: '' }), 45000)),
        ]);
      }
      catch (error) {
        void error;
      }
      finally {
        await this.session.closeVerifyTab(opened.windowId);
      }
      return { platform, type, implemented: result.loggedIn, items: result.loggedIn ? [result] : [], error: result.loggedIn ? undefined : 'not logged in' };
    }

    const crawler = CRAWLERS[platform];
    if (!crawler || !CRAWL_TYPES.includes(type)) {
      return { platform, type, implemented: false, items: [] };
    }

    const authError = await this.#verifyAuth(crawler, type);
    if (authError) {
      return { platform, type, implemented: false, items: [], error: authError, login_url: crawler.loginUrl || crawler.base };
    }

    const payload: CrawlPayload = command.payload ?? { url: command.url, username: command.username };
    this.challenge.reset();
    setVisibilityCrawling(crawler.visibilityCrawling === true);
    try {
      let page = this.#toPage(await crawler.invoke(type, payload));
      if (!page.items.length && !this.challenge.detected() && !payload.cursor) {
        await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        this.challenge.reset();
        page = this.#toPage(await crawler.invoke(type, payload));
      }
      if (this.challenge.detected()) {
        return { platform, type, implemented: false, items: [], error: CRAWL_ERRORS.bot };
      }

      const nextCursor = page.next_cursor ? String(page.next_cursor) : undefined;
      return { platform, type, implemented: page.items.length > 0, items: page.items, next_cursor: nextCursor, has_more: !!nextCursor };
    }
    catch (error) {
      const code = error instanceof ChallengeError || this.challenge.detected() ? CRAWL_ERRORS.bot : CRAWL_ERRORS.reach;
      return { platform, type, implemented: false, items: [], error: code };
    }
    finally {
      setVisibilityCrawling(false);
    }
  }

  #toPage(result: unknown[] | CrawlPage | null | undefined): CrawlPage {
    if (Array.isArray(result)) {
      return { items: result as CrawlPage['items'] };
    }
    return { items: Array.isArray(result?.items) ? result.items : [], next_cursor: result?.next_cursor };
  }

  #resolveGuard(): ChallengeGuard {
    return this.#resolve(ChallengeGuard);
  }

  #resolve<T>(token: new () => T): T {
    try {
      return inject(token);
    }
    catch {
      return new token();
    }
  }

  async #verifyAuth(crawler: Crawler, type: CrawlType): Promise<string> {
    if (!crawler.authwall[type]) {
      return '';
    }

    return await crawler.verifyLogin() ? '' : CRAWL_ERRORS.login;
  }
}
