import { CRAWL_TYPES } from '../model/extension.model';
import { CRAWLERS } from '../../../crawler/constant/crawlers';

export { CRAWLERS, CRAWL_TYPES };
