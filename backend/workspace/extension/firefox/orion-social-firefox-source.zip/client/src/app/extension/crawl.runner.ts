import { inject, Injectable } from '@angular/core';
import { ExtensionManager } from './extension.manager';

interface RuntimeMessaging {
  runtime?: {
    onMessage?: { addListener(callback: (message: unknown, sender: unknown, sendResponse: (response: unknown) => void) => unknown): void };
  };
}

@Injectable({ providedIn: 'root' })
export class CrawlRunner {
  private readonly manager = inject(ExtensionManager);

  install(): void {
    const scope = globalThis as unknown as { chrome?: RuntimeMessaging; browser?: RuntimeMessaging };
    const runtime = (scope.browser ?? scope.chrome)?.runtime;
    if (!runtime?.onMessage?.addListener) {
      return;
    }

    runtime.onMessage.addListener((message, _sender, sendResponse) => {
      const command = message as { type?: string; command?: unknown };
      if (command?.type !== 'orion-run') {
        return undefined;
      }

      this.#run(command.command).then((result) => sendResponse(result), (error: unknown) => sendResponse({ items: [], error: String((error as Error)?.message ?? error) }));
      return true;
    });
  }

  async #run(command: unknown): Promise<{ items: unknown[]; error?: string }> {
    const input = (command ?? {}) as { platform?: string; url?: string; username?: string; crawl_type?: string; type?: string };
    const url = String(input.url ?? '');
    const username = String(input.username ?? '') || this.#usernameFromUrl(url);
    const type = String(input.crawl_type ?? input.type ?? 'details').toLowerCase();
    const result = await this.manager.invoke({ command: 'crawl', platform: String(input.platform ?? ''), type, url, username });
    return { items: result.items ?? [], error: result.error };
  }

  #usernameFromUrl(url: string): string {
    try {
      const parts = new URL(url).pathname.split('/').filter(Boolean);
      return (parts[parts.length - 1] ?? '').replace(/^@/, '');
    }
    catch {
      return '';
    }
  }
}
