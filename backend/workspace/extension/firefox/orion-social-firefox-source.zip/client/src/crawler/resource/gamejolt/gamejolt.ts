import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, FOLLOW_PER_PAGE, GAMES_PER_PAGE, MAX_POST_FETCHES, POSTS_PER_PAGE } from './constant';
import { api, clean, parseCursor, positive, scrollId, stamp } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gamejolt.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, GAMES_PER_PAGE, GAMES_PER_PAGE);
    const cursor = parseCursor(payload);
    const page = positive(cursor['page'], 1);
    const offset = Math.max(0, Math.floor(Number(cursor['offset'])) || 0);

    const data = await api(tab, `/web/library/games/developer/@${encodeURIComponent(username)}?page=${page}`);
    const all = (Array.isArray(data?.games) ? data.games : []) as any[];
    const perPage = positive(data?.perPage, GAMES_PER_PAGE);
    const total = Number(data?.gamesCount ?? data?.totalGamesCount);
    const slice = all.slice(offset, offset + limit);
    const consumed = offset + slice.length;

    const items = slice.map((game: any): social_resource => {
      const developer = game.developer ?? {};
      const thumbnail = game.thumbnail_media_item ?? {};
      const header = game.header_media_item ?? {};
      return {
        type: 'games',
        resource_id: String(game.id ?? ''),
        url: `https://gamejolt.com/games/${game.slug ?? game.path ?? ''}/${game.id ?? ''}`,
        parent_url: `https://gamejolt.com/@${username}`,
        title: game.title ?? '',
        caption: clean(game.description ?? game.tagline),
        author: developer.username ?? username,
        datetime: stamp(game.posted_on ?? game.published_on ?? game.added_on),
        media_type: 'game',
        media_url: game.img_thumbnail ?? '',
        thumbnail_url: game.img_thumbnail ?? thumbnail.mediaserver_url ?? '',
        likes: String((game.like_count ?? 0) || ''),
        shares: '',
        views: String((game.play_count ?? game.view_count ?? 0) || ''),
        game_id: game.id ?? 0,
        title_text: game.title ?? '',
        slug: game.slug ?? '',
        path: game.path ?? '',
        description: clean(game.description),
        tagline: clean(game.tagline),
        category: game.category ?? '',
        status: game.status ?? '',
        development_status: game.development_status ?? 0,
        canonical: game.canonical ?? '',
        is_published: Boolean(game.published_on),
        published_on: stamp(game.published_on),
        added_on: stamp(game.added_on),
        modified_on: stamp(game.modified_on),
        posted_on: stamp(game.posted_on),
        like_count: game.like_count ?? 0,
        play_count: game.play_count ?? 0,
        download_count: game.download_count ?? 0,
        follower_count: game.follower_count ?? 0,
        comment_count: game.comment_count ?? 0,
        has_adult_content: game.has_adult_content ?? false,
        is_listable: game.is_listable ?? false,
        compatibility_web: Boolean(game.compatibility?.type_html),
        thumbnail_url_full: thumbnail.mediaserver_url ?? '',
        thumbnail_width: thumbnail.width ?? 0,
        thumbnail_height: thumbnail.height ?? 0,
        thumbnail_filetype: thumbnail.filetype ?? '',
        thumbnail_filesize: thumbnail.filesize ?? 0,
        thumbnail_avg_color: thumbnail.avg_img_color ?? '',
        header_url: header.mediaserver_url ?? '',
        header_width: header.width ?? 0,
        header_height: header.height ?? 0,
        developer_id: developer.id ?? 0,
        developer_username: developer.username ?? '',
        developer_name: developer.display_name ?? developer.name ?? '',
        developer_url: developer.url ? `https://gamejolt.com${developer.url}` : '',
        developer_avatar: developer.img_avatar ?? '',
        developer_website: developer.web_site ?? '',
        developer_followers: developer.follower_count ?? 0,
        developer_verified: developer.is_verified ?? false,
        developer_created_on: stamp(developer.created_on),
      };
    }).filter((item) => item.url);

    if (!items.length) {
      return { items };
    }

    if (consumed < all.length) {
      return { items, next_cursor: JSON.stringify({ page, offset: consumed }) };
    }

    const morePages = Number.isFinite(total) && total > 0 ? page * perPage < total : all.length >= perPage;
    return { items, next_cursor: morePages ? JSON.stringify({ page: page + 1, offset: 0 }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gamejolt.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, POSTS_PER_PAGE * MAX_POST_FETCHES);
    const path = `/web/posts/fetch/user/@${encodeURIComponent(username)}`;
    let cursor = String(payload.cursor ?? '').trim();
    const raw: any[] = [];
    let exhausted = false;

    for (let fetches = 0; fetches < MAX_POST_FETCHES && raw.length < limit; fetches++) {
      const data = await api(tab, cursor ? `${path}?scrollId=${encodeURIComponent(cursor)}` : path);
      const chunk = (Array.isArray(data?.items) ? data.items : []) as any[];
      if (!chunk.length) {
        exhausted = true;
        break;
      }
      raw.push(...chunk);
      const last = scrollId(chunk[chunk.length - 1]);
      if (!last || last === cursor) {
        exhausted = true;
        break;
      }
      cursor = last;
    }

    const kept = raw.slice(0, limit);
    const nextCursor = kept.length < raw.length || !exhausted ? scrollId(kept[kept.length - 1]) : '';

    const items = kept.map((entry: any): social_resource => {
      const post = entry.action_resource_model ?? entry;
      const user = post.user ?? {};
      const game = post.game ?? {};
      const media: any[] = Array.isArray(post.media) ? post.media : [];
      const videos: any[] = Array.isArray(post.videos) ? post.videos : [];
      const communities: any[] = Array.isArray(post.communities) ? post.communities : [];
      const realms: any[] = Array.isArray(post.realms) ? post.realms : [];
      return {
        type: 'posts',
        resource_id: String(post.id ?? ''),
        url: post.url ?? '',
        parent_url: `https://gamejolt.com/@${username}`,
        title: clean(post.leadStr).slice(0, 120),
        caption: clean(post.leadStr),
        author: user.username ?? username,
        datetime: stamp(post.published_on ?? post.added_on),
        media_type: videos.length ? 'video' : media.length ? 'image' : 'text',
        media_url: media[0]?.img_url ?? media[0]?.mediaserver_url ?? '',
        thumbnail_url: media[0]?.mediaserver_url ?? '',
        likes: String((post.like_count ?? 0) || ''),
        shares: '',
        views: String((post.view_count ?? 0) || ''),
        post_id: post.id ?? 0,
        hash: post.hash ?? '',
        slug: post.slug ?? '',
        feed_type: entry.type ?? '',
        status: post.status ?? '',
        lead: clean(post.leadStr),
        lead_length: String(post.leadStr ?? '').length,
        has_article: post.has_article ?? false,
        is_processing: post.is_processing ?? false,
        post_to_user_profile: post.post_to_user_profile ?? false,
        as_game_owner: post.as_game_owner ?? false,
        like_count: post.like_count ?? 0,
        comment_count: post.comment_count ?? 0,
        view_count: post.view_count ?? 0,
        published_on: stamp(post.published_on),
        added_on: stamp(post.added_on),
        updated_on: stamp(post.updated_on),
        scheduled_for: stamp(post.scheduled_for),
        media_count: media.length,
        media_urls: media.map((item: any) => item?.img_url ?? item?.mediaserver_url ?? '').filter(Boolean).join(', '),
        media_types: [...new Set(media.map((item: any) => item?.filetype ?? '').filter(Boolean))].join(', '),
        videos_count: videos.length,
        video_ids: videos.map((video: any) => video?.id ?? '').filter(Boolean).join(', '),
        communities: communities.map((entry_item: any) => entry_item?.community?.name ?? '').filter(Boolean).join(', '),
        communities_count: communities.length,
        realms: realms.map((entry_item: any) => entry_item?.realm?.name ?? '').filter(Boolean).join(', '),
        realms_count: realms.length,
        game_id: game.id ?? 0,
        game_title: game.title ?? '',
        game_url: game.id ? `https://gamejolt.com/games/${game.slug ?? ''}/${game.id}` : '',
        user_id: user.id ?? 0,
        user_username: user.username ?? '',
        user_display_name: user.display_name ?? '',
        user_avatar: user.img_avatar ?? '',
        user_followers: user.follower_count ?? 0,
        user_verified: user.is_verified ?? false,
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && nextCursor && nextCursor !== String(payload.cursor ?? '').trim() ? nextCursor : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

async function people(payload: CrawlPayload, kind: 'followers' | 'friends', segment: string): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gamejolt.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = parseCursor(payload);
    const page = positive(cursor['page'], 1);
    const data = await api(tab, `/web/profile/${segment}/@${encodeURIComponent(username)}?page=${page}`);
    const users = (Array.isArray(data?.users) ? data.users : []) as any[];
    const items = users.map((user: any): social_resource => ({
      type: kind,
      resource_id: String(user.id ?? ''),
      url: user.url ? `https://gamejolt.com${user.url}` : (user.username ? `https://gamejolt.com/@${user.username}` : ''),
      parent_url: `https://gamejolt.com/@${username}`,
      title: user.display_name ?? user.username ?? '',
      caption: '',
      author: user.username ?? '',
      datetime: stamp(user.created_on),
      media_type: 'user',
      media_url: user.img_avatar ?? '',
      thumbnail_url: user.img_avatar ?? '',
      likes: '',
      shares: '',
      views: '',
      user_id: user.id ?? 0,
      profile_username: user.username ?? '',
      display_name: user.display_name ?? '',
      name: user.name ?? '',
      account_type: user.type ?? '',
      avatar: user.img_avatar ?? '',
      website: user.web_site ?? '',
      gamejolt_url: user.url ? `https://gamejolt.com${user.url}` : '',
      follower_count: user.follower_count ?? 0,
      following_count: user.following_count ?? 0,
      is_verified: user.is_verified ?? false,
      status: user.status ?? 0,
      created_at: stamp(user.created_on),
    })).filter((item) => item.url);
    const next_cursor = items.length >= FOLLOW_PER_PAGE ? JSON.stringify({ page: page + 1 }) : undefined;
    return { items, next_cursor };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'followers', 'followers');
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  return people(payload, 'friends', 'following');
}
