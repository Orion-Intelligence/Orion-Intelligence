import { closeTab, fetchInTab, getCookies, getHtml, navigate, openTab, overlayTab, queryTab, scrollCollectTab, TabCollectItem, TabQueryItem, scrollDown, scrollLoad, scrollUp, TabFetchOptions, TabFetchResult } from './tab.helper';

export class TabController {
  private tabId: number | null = null;
  private safety: ReturnType<typeof setTimeout> | null = null;

  get ready(): boolean {
    return this.tabId != null;
  }

  async launch(active = false, popup = false): Promise<boolean> {
    const handle = await openTab(active, popup);
    if (!handle) {
      return false;
    }
    this.tabId = handle.tabId;
    this.safety = setTimeout(() => { void this.close(); }, 120000);
    return true;
  }

  attach(tabId: number): void {
    this.tabId = tabId;
  }

  async scrollCollect(selector: string, steps = 40): Promise<TabCollectItem[]> {
    return this.tabId == null ? [] : scrollCollectTab(this.tabId, selector, steps);
  }

  async query(selector: string): Promise<TabQueryItem[]> {
    return this.tabId == null ? [] : queryTab(this.tabId, selector);
  }

  async cookies(): Promise<string> {
    return this.tabId == null ? '' : getCookies(this.tabId);
  }

  async navigate(url: string): Promise<string> {
    return this.tabId == null ? '' : navigate(this.tabId, url);
  }

  async html(): Promise<string> {
    return this.tabId == null ? '' : getHtml(this.tabId);
  }

  async fetch(url: string, options?: TabFetchOptions): Promise<TabFetchResult> {
    return this.tabId == null ? { ok: false, status: 0, body: '' } : fetchInTab(this.tabId, url, options);
  }

  async overlay(text: string): Promise<void> {
    if (this.tabId != null) {
      await overlayTab(this.tabId, text);
    }
  }

  async scrollDown(): Promise<void> {
    if (this.tabId != null) {
      await scrollDown(this.tabId);
    }
  }

  async scrollLoad(times = 12): Promise<void> {
    if (this.tabId != null) {
      await scrollLoad(this.tabId, times);
    }
  }

  async scrollUp(): Promise<void> {
    if (this.tabId != null) {
      await scrollUp(this.tabId);
    }
  }

  async close(): Promise<void> {
    if (this.safety) {
      clearTimeout(this.safety);
      this.safety = null;
    }
    if (this.tabId != null) {
      await closeTab(this.tabId);
    }
    this.tabId = null;
  }
}

let visibilityCrawling = false;

export function setVisibilityCrawling(value: boolean): void {
  visibilityCrawling = value === true;
}

export async function openSession(origin: string, active = false, popup = visibilityCrawling): Promise<TabController | null> {
  const tab = new TabController();
  if (!await tab.launch(active, popup)) {
    return null;
  }
  await tab.navigate(origin);
  return tab;
}
