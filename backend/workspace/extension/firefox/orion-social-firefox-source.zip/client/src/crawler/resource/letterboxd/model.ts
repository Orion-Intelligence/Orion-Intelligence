export interface ListingCursor {
  page: number;
  skip: number;
}

export interface Feed {
  creator: string;
  items: string[];
  byLink: Map<string, string>;
}
