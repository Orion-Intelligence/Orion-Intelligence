import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function stamp(value: unknown): string {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? new Date(n * 1000).toISOString() : '';
}

export async function maintained(username: string): Promise<any[]> {
  const response = await fetch(`https://aur.archlinux.org/rpc/?v=5&type=search&by=maintainer&arg=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data?.results) ? data.results : [];
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const results = await maintained(username);
    if (!results.length) {
      return EMPTY;
    }

    results.sort((a: any, b: any) => Number(b?.Popularity ?? 0) - Number(a?.Popularity ?? 0));
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = results.slice(offset, offset + limit);

    const items = slice.map((pkg: any): social_resource => {
      const name = String(pkg.Name ?? '');
      return {
        type: 'repositories',
        resource_id: name,
        url: `https://aur.archlinux.org/packages/${name}`,
        parent_url: `https://aur.archlinux.org/packages/?K=${encodeURIComponent(username)}&SeB=m`,
        title: name,
        caption: clean(pkg.Description),
        author: pkg.Maintainer ?? username,
        datetime: stamp(pkg.LastModified),
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: String((pkg.NumVotes ?? 0) || ''),
        shares: '',
        views: '',
        name,
        description: clean(pkg.Description),
        version: pkg.Version ?? '',
        upstream_url: pkg.URL ?? '',
        license: Array.isArray(pkg.License) ? pkg.License.join(', ') : '',
        keywords: Array.isArray(pkg.Keywords) ? pkg.Keywords.join(', ') : '',
        num_votes: pkg.NumVotes ?? 0,
        popularity: pkg.Popularity ?? 0,
        out_of_date: Boolean(pkg.OutOfDate),
        maintainer: pkg.Maintainer ?? '',
        first_submitted: stamp(pkg.FirstSubmitted),
        last_modified: stamp(pkg.LastModified),
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < results.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
