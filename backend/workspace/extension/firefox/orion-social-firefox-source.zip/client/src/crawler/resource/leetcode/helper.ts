import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { UPSTREAM_MAX } from './constant';

export async function graphql(tab: TabController, query: string, variables: Record<string, unknown>): Promise<any> {
  try {
    const response = await tab.fetch('https://leetcode.com/graphql/', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
    });
    return response.ok ? JSON.parse(response.body)?.data ?? null : null;
  }
  catch {
    return null;
  }
}

export function offsetOf(payload: CrawlPayload): number {
  try {
    const parsed: any = JSON.parse(String(payload.cursor ?? '').trim() || '{}');
    return Math.max(0, Math.floor(Number(parsed?.offset) || 0));
  }
  catch {
    return 0;
  }
}

export function slice(list: any[], payload: CrawlPayload): { entries: any[]; next?: string } {
  const offset = offsetOf(payload);
  const size = limitOf(payload, UPSTREAM_MAX, UPSTREAM_MAX);
  const end = offset + size;
  return { entries: list.slice(offset, end), next: end < list.length ? JSON.stringify({ offset: end }) : undefined };
}

export function page(items: social_resource[], next?: string): CrawlPage {
  return { items, next_cursor: items.length && next ? next : undefined };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function stats(raw: unknown): any {
  try {
    return JSON.parse(String(raw ?? '{}'));
  }
  catch {
    return {};
  }
}
