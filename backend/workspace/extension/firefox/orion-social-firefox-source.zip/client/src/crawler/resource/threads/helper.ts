import { TabController } from '../../tab_management/tab.controller';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export async function blocks(tab: TabController, username: string): Promise<any[]> {
  try {
    const response = await tab.fetch(`https://www.threads.net/@${encodeURIComponent(username.replace(/^@/, ''))}`);
    if (!response.ok) {
      return [];
    }

    const html = response.body;
    const parsed: any[] = [];
    for (const match of html.matchAll(/<script type="application\/json"[^>]*>([\s\S]*?)<\/script>/g)) {
      try {
        parsed.push(JSON.parse(match[1]));
      }
      catch {
        continue;
      }
    }
    return parsed;
  }
  catch {
    return [];
  }
}
