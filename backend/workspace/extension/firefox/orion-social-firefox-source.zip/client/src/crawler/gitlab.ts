import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts, projects, repositories } from './resource/gitlab/gitlab';

export class GitLab implements Crawler {
  readonly platform = 'gitlab';
  readonly base = 'https://gitlab.com';
  readonly loginUrl = 'https://gitlab.com/users/sign_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      case 'projects':
        return projects(payload);
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://gitlab.com/api/v4/users?username=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = Array.isArray(payload) ? payload[0] : null;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.name ?? data.username ?? username,
        bio: '',
        description: '',
        location: '',
        profile_url: data.web_url ?? `https://gitlab.com/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.avatar_url ?? '',
        banner: '',
        crawl_type: ['details', 'repositories', 'projects', 'posts'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? 0,
        name: data.name ?? '',
        email: data.public_email ?? '',
        state: data.state ?? '',
        locked: data.locked ?? false,
        web_url: data.web_url ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://gitlab.com/api/v4/user', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
