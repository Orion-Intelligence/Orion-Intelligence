import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, KINDS, PAGE, STATUS } from './constant';
import { Cursor, Kind } from './model';
import { entry, list, parseCursor, stamp } from './helper';

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://myanimelist.net/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, PAGE);
    const items: social_resource[] = [];
    let next: Cursor | undefined = parseCursor(payload.cursor);
    for (let guard = 0; guard < KINDS.length && next && items.length < limit; guard++) {
      const current: Cursor = next;
      const kind = current.kind;
      const offset = current.offset;
      const data = await list(tab, username, kind, offset);
      const take = data.slice(0, limit - items.length);
      items.push(...take.map((item: any) => entry(username, kind, item)).filter((item) => item.url));
      if (data.length > take.length || data.length >= PAGE) {
        next = { kind, offset: offset + take.length };
      }
      else {
        const after = KINDS[KINDS.indexOf(kind) + 1];
        next = after ? { kind: after, offset: 0 } : undefined;
      }
    }

    return { items, next_cursor: items.length && next ? JSON.stringify(next) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
