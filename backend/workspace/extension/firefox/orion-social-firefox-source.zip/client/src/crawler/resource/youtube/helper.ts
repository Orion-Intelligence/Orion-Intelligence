import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function channelUrl(payload: CrawlPayload): string {
  const handle = String(payload.username ?? '').replace(/^@+/, '');
  if (handle) {
    return `https://www.youtube.com/@${handle}`;
  }

  const path = String(payload.url ?? '').replace(/^https?:\/\/[^/]+/i, '').split(/[?#]/)[0].replace(/^\/+|\/+$/g, '');
  const prefixed = /^(c|user|channel)\/([^/]+)/i.exec(path);
  return prefixed ? `https://www.youtube.com/${prefixed[1]}/${prefixed[2]}` : '';
}

export async function tab(session: TabController, channel: string, name: string): Promise<{ data: any; html: string }> {
  try {
    const response = await session.fetch(`${channel}/${name}`);
    if (!response.ok) {
      return { data: null, html: '' };
    }

    const html = response.body;
    const raw = /var ytInitialData = (\{[\s\S]*?\});<\/script>/.exec(html)?.[1] ?? /ytInitialData"\]\s*=\s*(\{[\s\S]*?\});/.exec(html)?.[1] ?? '';
    return { data: raw ? JSON.parse(raw) : null, html };
  }
  catch {
    return { data: null, html: '' };
  }
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export function runs(node: any): string {
  if (!node) {
    return '';
  }
  if (typeof node === 'string') {
    return node;
  }
  if (node.simpleText) {
    return String(node.simpleText);
  }
  if (node.content) {
    return String(node.content);
  }
  if (Array.isArray(node.runs)) {
    return node.runs.map((run: any) => run?.text ?? '').join('');
  }
  return '';
}

export function widest(sources: any[]): string {
  const list = Array.isArray(sources) ? sources : [];
  return list.reduce((best: any, entry: any) => ((entry?.width ?? 0) >= (best?.width ?? 0) ? entry : best), list[0] ?? {})?.url ?? '';
}

export function metaParts(lockup: any): string[] {
  const rows = collect(lockup?.metadata, 'metadataRows').flat();
  const parts: string[] = [];
  rows.forEach((row: any) => {
    (Array.isArray(row?.metadataParts) ? row.metadataParts : []).forEach((part: any) => {
      const text = runs(part?.text);
      if (text) {
        parts.push(text);
      }
    });
  });
  return parts;
}

export function number(text: string): number {
  const match = /([\d.,]+)\s*([KMB])?/i.exec(text ?? '');
  if (!match) {
    return 0;
  }
  const base = Number(match[1].replace(/,/g, ''));
  const scale = { k: 1e3, m: 1e6, b: 1e9 }[String(match[2] ?? '').toLowerCase()] ?? 1;
  return Number.isFinite(base) ? Math.round(base * scale) : 0;
}

export function decode(value: string): string {
  return value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export async function feed(session: TabController, channelId: string): Promise<Map<string, any>> {
  const map = new Map<string, any>();
  if (!channelId) {
    return map;
  }

  try {
    const response = await session.fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`);
    if (!response.ok) {
      return map;
    }

    const xml = response.body;
    for (const entry of [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((match) => match[1])) {
      const videoId = /<yt:videoId>([^<]+)<\/yt:videoId>/.exec(entry)?.[1] ?? '';
      if (videoId) {
        map.set(videoId, {
          published: /<published>([^<]+)<\/published>/.exec(entry)?.[1] ?? '',
          updated: /<updated>([^<]+)<\/updated>/.exec(entry)?.[1] ?? '',
          description: decode(/<media:description>([\s\S]*?)<\/media:description>/.exec(entry)?.[1] ?? ''),
          views: Number(/<media:statistics[^>]+views="(\d+)"/.exec(entry)?.[1] ?? 0),
          rating_count: Number(/<media:starRating[^>]+count="(\d+)"/.exec(entry)?.[1] ?? 0),
          rating_average: Number(/<media:starRating[^>]+average="([\d.]+)"/.exec(entry)?.[1] ?? 0),
          author: decode(/<author>[\s\S]*?<name>([^<]*)<\/name>/.exec(entry)?.[1] ?? ''),
        });
      }
    }
  }
  catch {
    return map;
  }
  return map;
}

export function video(type: 'videos' | 'streams', channel: string, channelId: string, lockup: any, extra: any): social_resource {
  const id = String(lockup.contentId ?? '');
  const parts = metaParts(lockup);
  const badges = collect(lockup, 'thumbnailBadgeViewModel').map((badge: any) => runs(badge?.text)).filter(Boolean);
  const duration = badges.find((badge: string) => /^\d+:\d+/.test(badge)) ?? '';
  const viewText = parts.find((part: string) => /view/i.test(part)) ?? '';
  const timeText = parts.find((part: string) => /ago|streamed|premier/i.test(part)) ?? '';
  const images = collect(lockup?.contentImage, 'sources').flat();
  return {
    type,
    resource_id: id,
    url: `https://www.youtube.com/watch?v=${id}`,
    parent_url: channel,
    title: runs(lockup?.metadata?.lockupMetadataViewModel?.title),
    caption: extra?.description ?? '',
    author: extra?.author ?? '',
    datetime: extra?.published ?? '',
    media_type: type === 'streams' ? 'stream' : 'video',
    media_url: `https://www.youtube.com/watch?v=${id}`,
    thumbnail_url: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    likes: String((extra?.rating_count ?? 0) || ''),
    shares: '',
    views: String((extra?.views ?? number(viewText)) || ''),
    video_id: id,
    channel_id: channelId,
    title_text: runs(lockup?.metadata?.lockupMetadataViewModel?.title),
    description: extra?.description ?? '',
    duration_text: duration,
    duration_seconds: duration.split(':').reverse().reduce((sum: number, unit: string, index: number) => sum + Number(unit) * Math.pow(60, index), 0),
    views_text: viewText,
    views_count: extra?.views ?? number(viewText),
    published_text: timeText,
    published_at: extra?.published ?? '',
    updated_at: extra?.updated ?? '',
    rating_count: extra?.rating_count ?? 0,
    rating_average: extra?.rating_average ?? 0,
    badges: badges.join(', '),
    is_live: badges.some((badge: string) => /live/i.test(badge)) || /live/i.test(timeText),
    is_members_only: badges.some((badge: string) => /member/i.test(badge)),
    is_premiere: /premier/i.test(timeText),
    content_type: lockup.contentType ?? '',
    thumbnail_default: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    thumbnail_max: widest(images) || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    thumbnail_source: widest(images),
    thumbnail_count: images.length,
    animated_preview: collect(lockup, 'animatedThumbnailOverlayViewModel').flatMap((overlay: any) => collect(overlay, 'sources').flat()).map((source: any) => source?.url ?? '').filter(Boolean)[0] ?? '',
    metadata_parts: parts.join(' | '),
    embed_url: `https://www.youtube.com/embed/${id}`,
    short_url: `https://youtu.be/${id}`,
  };
}

export async function watchPage(session: TabController, url: string): Promise<{ data: any; html: string }> {
  try {
    const response = await session.fetch(url);
    if (!response.ok) {
      return { data: null, html: '' };
    }
    const html = response.body;
    const raw = /var ytInitialData = (\{[\s\S]*?\});<\/script>/.exec(html)?.[1] ?? /ytInitialData"\]\s*=\s*(\{[\s\S]*?\});/.exec(html)?.[1] ?? '';
    return { data: raw ? JSON.parse(raw) : null, html };
  }
  catch {
    return { data: null, html: '' };
  }
}

export async function next(session: TabController, apiKey: string, clientVersion: string, token: string): Promise<any> {
  try {
    const response = await session.fetch(`https://www.youtube.com/youtubei/v1/next?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ context: { client: { clientName: 'WEB', clientVersion } }, continuation: token }),
    });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function commentInitialToken(data: any): string {
  for (const section of collect(data, 'itemSectionRenderer')) {
    if (String(section?.sectionIdentifier ?? '').includes('comment')) {
      const token = collect(section, 'token').find(Boolean);
      if (token) {
        return String(token);
      }
    }
  }
  return '';
}

export function commentNextToken(node: any): string {
  const groups = collect(node, 'appendContinuationItemsAction').concat(collect(node, 'reloadContinuationItemsCommand'));
  for (const group of groups) {
    const items = Array.isArray(group?.continuationItems) ? group.continuationItems : [];
    const last = items[items.length - 1];
    if (last?.continuationItemRenderer) {
      const token = collect(last.continuationItemRenderer, 'token').find(Boolean);
      if (token) {
        return String(token);
      }
    }
  }
  return '';
}

export function commentAuthors(node: any): { channelId: string; name: string; avatar: string; text: string; time: string }[] {
  return collect(node, 'commentEntityPayload')
    .filter((payload: any) => Number(payload?.properties?.replyLevel ?? 0) === 0 && payload?.author?.channelId)
    .map((payload: any) => ({
      channelId: String(payload.author.channelId),
      name: String(payload.author.displayName ?? ''),
      avatar: String(payload.author.avatarThumbnailUrl ?? ''),
      text: String(payload.properties?.content?.content ?? ''),
      time: String(payload.properties?.publishedTime ?? ''),
    }));
}

export async function browse(session: TabController, apiKey: string, clientVersion: string, token: string): Promise<any> {
  try {
    const response = await session.fetch(`https://www.youtube.com/youtubei/v1/browse?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ context: { client: { clientName: 'WEB', clientVersion } }, continuation: token }),
    });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function nextToken(node: any): string {
  for (const command of collect(node, 'continuationCommand')) {
    if (command?.token) {
      return String(command.token);
    }
  }
  return '';
}

export async function allLockups(session: TabController, html: string, data: any, contentType: string, want = 100): Promise<any[]> {
  const match = (lockup: any): boolean => String(lockup?.contentType ?? '').includes(contentType);
  const out: any[] = collect(data, 'lockupViewModel').filter(match);
  const apiKey = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(html)?.[1] ?? '';
  const clientVersion = /"clientVersion":"([0-9.]+)"/.exec(html)?.[1] ?? '';
  let token = nextToken(data);
  for (let guard = 0; out.length < want && token && apiKey && clientVersion && guard < 25; guard += 1) {
    const page = await browse(session, apiKey, clientVersion, token);
    if (!page) {
      break;
    }
    const more = collect(page, 'lockupViewModel').filter(match);
    if (!more.length) {
      break;
    }
    out.push(...more);
    token = nextToken(page);
  }
  return out;
}

export interface PageCursor {
  t: string;
  k: string;
  v: string;
  c: string;
}

export function encodeCursor(state: PageCursor): string {
  return btoa(unescape(encodeURIComponent(JSON.stringify(state)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function decodeCursor(cursor: string | undefined): PageCursor | null {
  if (!cursor) {
    return null;
  }
  try {
    const padded = cursor.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - cursor.length % 4) % 4);
    const parsed = JSON.parse(decodeURIComponent(escape(atob(padded))));
    return parsed && typeof parsed.t === 'string' && parsed.t ? { t: parsed.t, k: String(parsed.k ?? ''), v: String(parsed.v ?? ''), c: String(parsed.c ?? '') } : null;
  }
  catch {
    return null;
  }
}

export async function page(session: TabController, channel: string, name: string, cursor: string | undefined): Promise<{ data: any; html: string; channelId: string; next: string; first: boolean }> {
  const state = decodeCursor(cursor);
  if (state) {
    const data = await browse(session, state.k, state.v, state.t);
    const token = data ? nextToken(data) : '';
    return { data, html: '', channelId: state.c, next: token ? encodeCursor({ ...state, t: token }) : '', first: false };
  }
  const { data, html } = await tab(session, channel, name);
  const channelId = /"channelId":"(UC[^"]+)"/.exec(html)?.[1] ?? '';
  const apiKey = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(html)?.[1] ?? '';
  const clientVersion = /"clientVersion":"([0-9.]+)"/.exec(html)?.[1] ?? '';
  const token = data ? nextToken(data) : '';
  return { data, html, channelId, next: token && apiKey && clientVersion ? encodeCursor({ t: token, k: apiKey, v: clientVersion, c: channelId }) : '', first: true };
}
