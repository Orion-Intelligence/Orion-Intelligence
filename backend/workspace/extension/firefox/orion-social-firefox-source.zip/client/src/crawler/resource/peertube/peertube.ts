import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function parse(username: string): { account: string; host: string } | null {
  const trimmed = username.replace(/^@/, '').trim();
  const at = trimmed.indexOf('@');
  if (at < 1 || at === trimmed.length - 1) {
    return null;
  }
  return { account: trimmed.slice(0, at), host: trimmed.slice(at + 1).replace(/\/+$/, '') };
}

async function accountProfile(host: string, account: string): Promise<any> {
  const response = await fetch(`https://${host}/api/v1/accounts/${encodeURIComponent(account)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

async function accountVideos(host: string, account: string, start: number, count: number): Promise<any> {
  const response = await fetch(`https://${host}/api/v1/accounts/${encodeURIComponent(account)}/videos?start=${start}&count=${count}&sort=-publishedAt`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function details(username: string): Promise<social_profile_details[]> {
  const parsed = parse(username);
  if (!parsed) {
    return [];
  }

  const profile = await accountProfile(parsed.host, parsed.account);
  if (!profile?.name) {
    return [];
  }
  const videos = await accountVideos(parsed.host, parsed.account, 0, 1);
  const total = Number(videos?.total ?? 0);
  const avatar = Array.isArray(profile.avatars) && profile.avatars.length ? `https://${parsed.host}${profile.avatars[profile.avatars.length - 1].path}` : '';
  return [{
    real_name: clean(profile.displayName) || profile.name,
    bio: clean(profile.description),
    description: clean(profile.description),
    location: '',
    profile_url: profile.url ?? `https://${parsed.host}/a/${parsed.account}`,
    total_posts: String(total || ''),
    total_followers: String((profile.followersCount ?? 0) || ''),
    total_likes: '',
    avatar,
    banner: '',
    crawl_type: ['details', 'videos'],
    platform: 'peertube',
    username: `${parsed.account}@${parsed.host}`,
    video_count: total,
    following_count: profile.followingCount ?? 0,
    host: parsed.host,
  }];
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const parsed = parse(String(payload.username ?? ''));
  if (!parsed) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 100);
    const data = await accountVideos(parsed.host, parsed.account, offset, limit);
    const total = Number(data?.total ?? 0);
    const rows: any[] = Array.isArray(data?.data) ? data.data : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((video: any): social_resource => {
      const channel = video.channel ?? {};
      const thumb = video.thumbnailPath ? `https://${parsed.host}${video.thumbnailPath}` : '';
      return {
        type: 'videos',
        resource_id: String(video.uuid ?? video.id ?? ''),
        url: video.url ?? `https://${parsed.host}/w/${video.shortUUID ?? video.uuid ?? ''}`,
        parent_url: `https://${parsed.host}/a/${parsed.account}`,
        title: clean(video.name),
        caption: clean(video.truncatedDescription ?? video.description),
        author: parsed.account,
        datetime: video.publishedAt ?? video.createdAt ?? '',
        media_type: 'video',
        media_url: video.embedPath ? `https://${parsed.host}${video.embedPath}` : '',
        thumbnail_url: thumb,
        likes: String((video.likes ?? 0) || ''),
        shares: String((video.dislikes ?? 0) || ''),
        views: String((video.views ?? 0) || ''),
        name: clean(video.name),
        description: clean(video.truncatedDescription ?? video.description),
        channel: clean(channel.displayName) || channel.name || '',
        duration: video.duration ?? 0,
        views_count: video.views ?? 0,
        likes_count: video.likes ?? 0,
        dislikes_count: video.dislikes ?? 0,
        comments_count: video.comments ?? 0,
        language: video.language?.label ?? '',
        category: video.category?.label ?? '',
        is_live: Boolean(video.isLive),
        nsfw: Boolean(video.nsfw),
        published_at: video.publishedAt ?? '',
      };
    }).filter((item) => item.url);

    const next = offset + rows.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
