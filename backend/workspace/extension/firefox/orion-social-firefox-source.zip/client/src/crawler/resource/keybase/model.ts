export interface ListCursor {
  offset: number;
  uid: string;
}
