import { CrawlPage } from '../../../app/extension/model/extension.model';
import { Listing } from './model';

export const EMPTY: CrawlPage = { items: [] };

export const NO_LISTING: Listing = { items: [], after: '' };
