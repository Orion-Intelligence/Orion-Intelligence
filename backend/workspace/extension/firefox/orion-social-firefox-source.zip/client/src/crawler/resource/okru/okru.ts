import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { decode, profileUrl } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const profile = profileUrl(payload);
  const tab = profile ? await openSession('https://ok.ru/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const response = await tab.fetch(`${profile}/statuses`);
    if (!response.ok) {
      return { items: [] };
    }

    const html = response.body;
    const seen = new Set<string>();
    const items: social_resource[] = [];

    for (const match of html.matchAll(/data-l="t,(\d+)"[\s\S]{0,6000}?<\/div>/g)) {
      const id = match[1];
      if (seen.has(id)) {
        continue;
      }
      seen.add(id);
      const block = match[0];
      const text = decode(/<div[^>]+class="[^"]*media-text_cnt_tx[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? '');
      const image = /<img[^>]+src="([^"]+)"/i.exec(block)?.[1] ?? '';
      items.push({
        type: 'posts',
        resource_id: id,
        url: `https://ok.ru/profile/${/profile\/(\d+)/.exec(profile)?.[1] ?? ''}/statuses/${id}`,
        parent_url: profile,
        title: '',
        caption: text,
        author: decode(/<a[^>]+class="[^"]*ucard[^"]*"[^>]*>([\s\S]*?)<\/a>/i.exec(block)?.[1] ?? ''),
        datetime: decode(/<span[^>]+class="[^"]*feed_date[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(block)?.[1] ?? ''),
        media_type: image ? 'image' : 'text',
        media_url: image,
        thumbnail_url: image,
        likes: String(/data-count="(\d+)"/.exec(block)?.[1] ?? ''),
        shares: '',
        views: '',
        post_id: id,
        text,
        text_length: text.length,
        image_url: image,
        images_count: [...block.matchAll(/<img[^>]+src="([^"]+)"/g)].length,
        like_count: Number(/data-count="(\d+)"/.exec(block)?.[1] ?? 0),
        comment_count: Number(/comments-count[^>]*>(\d+)/.exec(block)?.[1] ?? 0),
        profile_url: profile,
        date_text: decode(/<span[^>]+class="[^"]*feed_date[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(block)?.[1] ?? ''),
        has_video: /video/i.test(block),
        has_link: /<a[^>]+href="http/i.test(block),
      });
    }

    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
