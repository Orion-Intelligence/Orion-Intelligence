export interface ApiPage { data: any[]; next: string }
