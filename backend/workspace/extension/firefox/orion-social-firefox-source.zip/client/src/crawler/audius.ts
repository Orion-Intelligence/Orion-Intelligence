import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { details, tracks } from './resource/audius/audius';

export class Audius implements Crawler {
  readonly platform = 'audius';
  readonly base = 'https://audius.co';
  readonly loginUrl = 'https://audius.co/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'tracks':
        return tracks(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const handle = String(payload.username ?? '');
    if (!handle) {
      return [];
    }

    try {
      return await details(handle);
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://audius.co/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
