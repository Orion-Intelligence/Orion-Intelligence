import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, comments, images, posts } from './resource/imgur/imgur';

export class Imgur implements Crawler {
  readonly platform = 'imgur';
  readonly base = 'https://imgur.com';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'images':
        return images(payload);
      case 'posts':
        return posts(payload);
      case 'albums':
        return albums(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.imgur.com/account/v1/accounts/${encodeURIComponent(username)}?client_id=546c25a59c58ad7`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload;
      if (!data?.id) {
        return [];
      }

      const trophies: any[] = Array.isArray(data.trophies) ? data.trophies : [];
      const medallions: any[] = Array.isArray(data.medallions) ? data.medallions : [];
      const roles: any[] = Array.isArray(data.roles) ? data.roles : [];

      return [{
        real_name: data.username ?? username,
        bio: data.bio ?? '',
        description: data.bio ?? '',
        location: '',
        profile_url: `https://imgur.com/user/${data.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.avatar_url ?? '',
        banner: data.cover_url ?? '',
        crawl_type: ['details', 'images', 'albums', 'comments', 'posts'],
        platform: this.platform,
        username: data.username ?? username,
        user_id: data.id ?? 0,
        reputation: Math.round(data.reputation_count ?? 0),
        reputation_name: data.reputation_name ?? '',
        avatar_id: data.avatar_id ?? '',
        cover_id: data.cover_id ?? '',
        trophies_count: trophies.length,
        trophies: trophies.map((t: any) => t.name ?? '').filter(Boolean).slice(0, 20).join(', '),
        medallions_count: medallions.length,
        roles: roles.map((r: any) => (typeof r === 'string' ? r : r?.name ?? '')).filter(Boolean).join(', '),
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://imgur.com/account/settings', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      return Boolean(true);
    }
    catch {
      return false;
    }
  }
}
