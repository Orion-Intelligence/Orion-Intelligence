import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function pageOf(payload: CrawlPayload): number {
  const page = Number.parseInt(String(payload.cursor ?? '').trim(), 10);
  return Number.isFinite(page) && page > 1 ? Math.min(page, 3) : 1;
}

export async function api(tab: TabController, username: string, collection: string, page = 1): Promise<any[]> {
  try {
    const response = await tab.fetch(`https://vimeo.com/api/v2/${encodeURIComponent(username)}/${collection}.json${page > 1 ? `?page=${page}` : ''}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return [];
    }
    const data = JSON.parse(response.body);
    return Array.isArray(data) ? data : [];
  }
  catch {
    return [];
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function iso(value: unknown): string {
  const text = String(value ?? '').trim();
  if (!text) {
    return '';
  }
  const parsed = new Date(text.replace(' ', 'T') + 'Z');
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString();
}
