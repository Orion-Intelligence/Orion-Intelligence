export interface PostsCursor {
  user_id: number;
  offset: string;
  owner?: Record<string, unknown>;
}
