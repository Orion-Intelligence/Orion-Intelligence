import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { reviews } from './resource/myanimelist/myanimelist';

export class MyAnimeList implements Crawler {
  readonly platform = 'myanimelist';
  readonly base = 'https://myanimelist.net';
  readonly loginUrl = 'https://myanimelist.net/login.php';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'reviews':
        return reviews(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.jikan.moe/v4/users/${encodeURIComponent(username)}/full`, { headers: { Accept: 'application/json' } });
      const payload = response.ok ? await response.json() : null;
      const data = payload?.data;
      if (!data?.username) {
        const page = await fetch(`https://myanimelist.net/profile/${encodeURIComponent(username)}`);
        if (!page.ok) {
          return [];
        }

        const html = await page.text();
        const meta = (key: string): string => (new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '').replace(/&#039;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
        const stat = (label: string): string => new RegExp(`${label}</span>\\s*<span[^>]*>([^<]+)<`, 'i').exec(html)?.[1]?.trim() ?? '';
        const title = meta('og:title');
        if (!title || /^MyAnimeList/i.test(title)) {
          return [];
        }

        return [{
          real_name: title.replace(/'s Profile.*$/i, ''),
          bio: meta('og:description'),
          description: meta('og:description'),
          location: stat('Location'),
          profile_url: `https://myanimelist.net/profile/${username}`,
          total_posts: '',
          total_followers: '',
          total_likes: '',
          avatar: meta('og:image'),
          banner: '',
          crawl_type: ['details', 'reviews'],
          platform: this.platform,
          username: username,
          lastOnline: stat('Last Online'),
          gender: stat('Gender'),
          birthday: stat('Birthday'),
          joined: stat('Joined'),
        }];
      }

      return [{
        real_name: data.username ?? username,
        bio: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        description: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        location: data.location ?? '',
        profile_url: data.url ?? `https://myanimelist.net/profile/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.images?.jpg?.image_url ?? '',
        banner: '',
        crawl_type: ['details', 'reviews'],
        platform: this.platform,
        username: data.username ?? username,
        gender: data.gender ?? '',
        birthday: data.birthday ?? '',
        animeCompleted: data.statistics?.anime?.completed ?? 0,
        animeMeanScore: data.statistics?.anime?.mean_score ?? 0,
        mangaCompleted: data.statistics?.manga?.completed ?? 0,
        joined: data.joined ?? '',
        lastOnline: data.last_online ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://myanimelist.net/editprofile.php', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login\.php/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
