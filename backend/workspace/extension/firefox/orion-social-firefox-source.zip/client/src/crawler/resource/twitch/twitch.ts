import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { clean, gql, page, thumb } from './helper';

export async function streams(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.twitch.tv/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const cursor = String(payload.cursor ?? '').trim();
    const data = await gql(tab, `query ($login: String!, $after: Cursor) { user(login: $login) { id login displayName createdAt followers { totalCount } videos(first: ${limitOf(payload, 25, 100)}, after: $after, sort: TIME) { edges { cursor node { id title description previewThumbnailURL animatedPreviewURL publishedAt createdAt recordedAt viewCount lengthSeconds broadcastType status language resourceRestriction { type } game { id name boxArtURL displayName } owner { id login displayName } contentTags { id localizedName } } } pageInfo { hasNextPage } } } }`, { login: username, after: cursor || null });
    const user = data?.user ?? {};
    const edges = (user.videos?.edges ?? []) as any[];

    const items = edges.map((edge: any) => edge?.node).filter((video: any) => video?.id).map((video: any): social_resource => ({
      type: 'streams',
      resource_id: String(video.id),
      url: `https://www.twitch.tv/videos/${video.id}`,
      parent_url: `https://www.twitch.tv/${username}`,
      title: clean(video.title),
      caption: clean(video.description ?? video.game?.name),
      author: video.owner?.login ?? username,
      datetime: video.publishedAt ?? video.createdAt ?? '',
      media_type: video.broadcastType ?? 'stream',
      media_url: thumb(video.animatedPreviewURL),
      thumbnail_url: thumb(video.previewThumbnailURL),
      likes: '',
      shares: '',
      views: String((video.viewCount ?? 0) || ''),
      video_id: video.id,
      title_text: clean(video.title),
      description: clean(video.description),
      view_count: video.viewCount ?? 0,
      duration_seconds: video.lengthSeconds ?? 0,
      broadcast_type: video.broadcastType ?? '',
      status: video.status ?? '',
      language: video.language ?? '',
      restriction: video.resourceRestriction?.type ?? '',
      game_id: video.game?.id ?? '',
      game_name: video.game?.name ?? '',
      game_display_name: video.game?.displayName ?? '',
      game_box_art: thumb(video.game?.boxArtURL, 285, 380),
      content_tags: Array.isArray(video.contentTags) ? video.contentTags.map((tag: any) => tag?.localizedName ?? '').filter(Boolean).join(', ') : '',
      content_tags_count: Array.isArray(video.contentTags) ? video.contentTags.length : 0,
      preview_thumbnail: thumb(video.previewThumbnailURL),
      animated_preview: thumb(video.animatedPreviewURL),
      owner_id: video.owner?.id ?? user.id ?? '',
      owner_login: video.owner?.login ?? username,
      owner_display_name: video.owner?.displayName ?? user.displayName ?? '',
      channel_followers: user.followers?.totalCount ?? 0,
      channel_created_at: user.createdAt ?? '',
      published_at: video.publishedAt ?? '',
      created_at: video.createdAt ?? '',
      recorded_at: video.recordedAt ?? '',
    }));

    return page(items, edges, user.videos, cursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.twitch.tv/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const cursor = String(payload.cursor ?? '').trim();
    const data = await gql(tab, `query ($login: String!, $after: Cursor) { user(login: $login) { id login displayName clips(first: ${limitOf(payload, 25, 100)}, after: $after, criteria: { sort: VIEWS_DESC, period: ALL_TIME }) { edges { cursor node { id slug title url embedURL viewCount createdAt durationSeconds thumbnailURL language isFeatured curator { id login displayName } broadcaster { id login displayName } game { id name displayName boxArtURL } video { id title lengthSeconds } videoOffsetSeconds } } pageInfo { hasNextPage } } } }`, { login: username, after: cursor || null });
    const user = data?.user ?? {};
    const edges = (user.clips?.edges ?? []) as any[];

    const items = edges.map((edge: any) => edge?.node).filter((clip: any) => clip?.id).map((clip: any): social_resource => ({
      type: 'videos',
      resource_id: String(clip.id),
      url: clip.url ?? `https://www.twitch.tv/${username}/clip/${clip.slug ?? ''}`,
      parent_url: `https://www.twitch.tv/${username}`,
      title: clean(clip.title),
      caption: clip.game?.name ?? '',
      author: clip.curator?.login ?? '',
      datetime: clip.createdAt ?? '',
      media_type: 'clip',
      media_url: clip.embedURL ?? '',
      thumbnail_url: clip.thumbnailURL ?? '',
      likes: '',
      shares: '',
      views: String((clip.viewCount ?? 0) || ''),
      clip_id: clip.id,
      slug: clip.slug ?? '',
      title_text: clean(clip.title),
      view_count: clip.viewCount ?? 0,
      duration_seconds: clip.durationSeconds ?? 0,
      language: clip.language ?? '',
      is_featured: clip.isFeatured ?? false,
      embed_url: clip.embedURL ?? '',
      thumbnail: clip.thumbnailURL ?? '',
      video_offset_seconds: clip.videoOffsetSeconds ?? 0,
      source_video_id: clip.video?.id ?? '',
      source_video_title: clean(clip.video?.title),
      source_video_length: clip.video?.lengthSeconds ?? 0,
      game_id: clip.game?.id ?? '',
      game_name: clip.game?.name ?? '',
      game_display_name: clip.game?.displayName ?? '',
      game_box_art: thumb(clip.game?.boxArtURL, 285, 380),
      curator_id: clip.curator?.id ?? '',
      curator_login: clip.curator?.login ?? '',
      curator_display_name: clip.curator?.displayName ?? '',
      broadcaster_id: clip.broadcaster?.id ?? user.id ?? '',
      broadcaster_login: clip.broadcaster?.login ?? username,
      broadcaster_display_name: clip.broadcaster?.displayName ?? user.displayName ?? '',
      created_at: clip.createdAt ?? '',
    }));

    return page(items, edges, user.clips, cursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
