import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { comments, connections, posts } from './resource/hackernews/hackernews';

export class HackerNews implements Crawler {
  readonly platform = 'hackernews';
  readonly base = 'https://news.ycombinator.com';
  readonly loginUrl = 'https://news.ycombinator.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://hacker-news.firebaseio.com/v0/user/${encodeURIComponent(username)}.json`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.id ?? username,
        bio: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/&#x2F;/g, '/').replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim(),
        description: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/&#x2F;/g, '/').replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim(),
        location: '',
        profile_url: `https://news.ycombinator.com/user?id=${data.id ?? username}`,
        total_posts: String((Array.isArray(data.submitted) ? data.submitted.length : 0) || ''),
        total_followers: '',
        total_likes: String((data.karma ?? 0) || ''),
        avatar: '',
        banner: '',
        crawl_type: ['details', 'posts', 'comments', 'connections'],
        platform: this.platform,
        username: data.id ?? username,
        id: data.id ?? '',
        karma: data.karma ?? 0,
        submitted_count: Array.isArray(data.submitted) ? data.submitted.length : 0,
        created_at: data.created ? new Date(data.created * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://news.ycombinator.com/threads', { credentials: 'include' });
      if (!response.ok) {
        return false;
      }

      const html = await response.text();
      return /logout\?auth=/i.test(html) || /user\?id=/i.test(html);
    }
    catch {
      return false;
    }
  }
}
