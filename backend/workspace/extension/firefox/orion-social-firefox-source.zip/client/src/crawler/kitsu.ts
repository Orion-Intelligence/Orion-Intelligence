import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { details, reviews } from './resource/kitsu/kitsu';

export class Kitsu implements Crawler {
  readonly platform = 'kitsu';
  readonly base = 'https://kitsu.io';
  readonly loginUrl = 'https://kitsu.io/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'reviews':
        return reviews(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const slug = String(payload.username ?? '');
    if (!slug) {
      return [];
    }

    try {
      return await details(slug);
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://kitsu.io/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
