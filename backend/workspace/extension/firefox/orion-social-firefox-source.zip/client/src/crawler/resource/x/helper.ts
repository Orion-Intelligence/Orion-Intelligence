import { TabController } from '../../tab_management/tab.controller';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export async function timeline(tab: TabController, username: string): Promise<any[]> {
  try {
    const response = await tab.fetch(`https://syndication.twitter.com/srv/timeline-profile/screen-name/${encodeURIComponent(username)}`);
    if (!response.ok) {
      return [];
    }

    const html = response.body;
    const raw = /<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/.exec(html)?.[1];
    if (!raw) {
      return [];
    }

    const data = JSON.parse(raw);
    const entries = collect(data?.props?.pageProps?.timeline ?? data, 'entries').flat();
    return entries.map((entry: any) => entry?.content?.tweet ?? entry?.tweet ?? entry).filter((tweet: any) => tweet?.id_str);
  }
  catch {
    return [];
  }
}
