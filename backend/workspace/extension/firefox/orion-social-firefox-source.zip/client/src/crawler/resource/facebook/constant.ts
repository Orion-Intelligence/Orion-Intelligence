import { CrawlPage } from '../../../app/extension/model/extension.model';
import { CollectionKind, CollectionSpec } from './model';

export const EMPTY: CrawlPage = { items: [] };

export const REFETCH_QUERY = 'ProfileCometTimelineFeedRefetchQuery';

export const MAX_HOPS = 4;

export const POSTS_MAX_HOPS = 12;

export const FEED_PAGINATION_QUERY = 'CometNewsFeedPaginationQuery';

export const MAX_FEED_HOPS = 8;

export const ADS_PASSES = 3;

export const ADS_PER_PASS = 50;

export const COMMENTS_QUERY = 'CommentsListComponentsPaginationQuery';

export const REEL_FEEDBACK_QUERY = 'FBUnifiedVideoFeedbackRightRailWithCommentPreloadingQuery';

export const REEL_COMMENT_PROVIDERS: Record<string, unknown> = {
  __relay_internal__pv__FBUnifiedVideoDescriptionWithEntities_comet_translations_revamp_sync_caption_with_audio_gkrelayprovider: false,
  __relay_internal__pv__CometUFICommentAutoTranslationTyperelayprovider: 'AUTO_TRANSLATE',
  __relay_internal__pv__CometUFICommentAvatarStickerAnimatedImagerelayprovider: false,
  __relay_internal__pv__CometUFICommentActionLinksRewriteEnabledrelayprovider: true,
  __relay_internal__pv__IsWorkUserrelayprovider: false,
};

export const MAX_COMMENT_HOPS = 6;

export const MAX_BUNDLES = 800;

const REELS_VARIABLES: Record<string, unknown> = {
  count: 10,
  renderLocation: null,
  scale: 1,
  useDefaultActor: false,
  __relay_internal__pv__FBReels_deprecate_short_form_video_context_gkrelayprovider: true,
  __relay_internal__pv__FBReelsMediaFooter_comet_enable_reels_ads_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoMediaContentContainer_comet_reels_video_footer_defer_loading_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoMediaContentContainer_comet_video_document_picture_in_picture_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoMediaContentContainer_enable_chapters_pill_gkrelayprovider: false,
  __relay_internal__pv__ShouldEnableBakedInTextUnifiedVideorelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoCometVideoMedia_comet_photosensitive_content_warning_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoMediaHeaderControls_enable_chapters_pill_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoMediaFooter_comet_enable_reels_ads_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoMediaFooter_organic_ad_cta_on_comet_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoMediaFooter_enable_meta_ai_pill_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoMediaFooter_enable_ai_embodiment_chat_pill_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoMediaFooter_enable_video_augment_pills_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoPlayerScrubber_fb_comet_vpv_heatmap_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoDescriptionWithEntities_comet_translations_revamp_sync_caption_with_audio_gkrelayprovider: false,
  __relay_internal__pv__FBUnifiedVideoFeedbackBar_comet_reels_save_button_gkrelayprovider: false,
  __relay_internal__pv__usePushPipEngagementCounts_comet_video_document_picture_in_picture_gkrelayprovider: false,
  __relay_internal__pv__FBReels_enable_view_dubbed_audio_type_gkrelayprovider: true,
  __relay_internal__pv__FBUnifiedVideoMenu_fb_reels_ranking_debug_tool_gkrelayprovider: false,
  __relay_internal__pv__CometAudioLanguageUtils_comet_translations_revamp_preferred_languages_gkrelayprovider: false,
};

const LIST_VARIABLES: Record<string, unknown> = {
  count: 8,
  scale: 1,
  search: null,
  __relay_internal__pv__FBProfile_enable_perf_improv_gkrelayprovider: true,
};

export const COLLECTIONS: Record<CollectionKind, CollectionSpec> = {
  reels: { path: 'reels_tab', renderer: 'TimelineAppCollectionReelsRenderer', query: 'ProfileCometAppCollectionReelsRendererPaginationQuery', connection: 'aggregated_fb_shorts', variables: REELS_VARIABLES },
  images: { path: 'photos', renderer: 'TimelineAppCollectionPhotosRenderer', query: 'ProfileCometAppCollectionPhotosRendererPaginationQuery', connection: 'pageItems', variables: { count: 8, created_time_end: null, created_time_start: null, scale: 1, tagged_user_ids: null } },
  followers: { path: 'followers', name: 'Followers', renderer: 'TimelineAppCollectionListRenderer', query: 'ProfileCometAppCollectionListRendererPaginationQuery', connection: 'pageItems', variables: LIST_VARIABLES },
  friends: { path: 'friends', name: 'Friends', renderer: 'TimelineAppCollectionListRenderer', query: 'ProfileCometAppCollectionListRendererPaginationQuery', connection: 'pageItems', variables: LIST_VARIABLES },
};
