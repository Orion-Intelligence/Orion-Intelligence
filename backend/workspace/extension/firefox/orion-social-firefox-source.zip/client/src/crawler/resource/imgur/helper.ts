import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { MAX_HOPS } from './constant';
import { Cursor } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://api.imgur.com/3${path}`, { headers: { Accept: 'application/json', Authorization: 'Client-ID 546c25a59c58ad7' } });
    return response.ok ? (JSON.parse(response.body))?.data ?? null : null;
  }
  catch {
    return null;
  }
}

export function natural(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : fallback;
}

export function parseCursor(payload: CrawlPayload): Cursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { page: 0, offset: 0 };
  }

  try {
    const parsed = JSON.parse(raw);
    return { page: natural(parsed?.page, 0), offset: natural(parsed?.offset, 0) };
  }
  catch {
    return { page: 0, offset: 0 };
  }
}

export async function walk(tab: TabController, path: (page: number) => string, payload: CrawlPayload, limit: number, keep: (entry: any) => boolean = () => true): Promise<{ entries: any[]; next?: string }> {
  let { page, offset } = parseCursor(payload);
  const entries: any[] = [];

  for (let hop = 0; hop < MAX_HOPS; hop++) {
    const list = await api(tab, path(page));
    const rows = (Array.isArray(list) ? list : []) as any[];
    if (!rows.length) {
      return { entries };
    }

    let index = offset;
    for (; index < rows.length && entries.length < limit; index++) {
      if (keep(rows[index])) {
        entries.push(rows[index]);
      }
    }

    if (index < rows.length) {
      return { entries, next: JSON.stringify({ page, offset: index }) };
    }

    page += 1;
    offset = 0;
    if (entries.length >= limit) {
      break;
    }
  }

  return { entries, next: JSON.stringify({ page, offset }) };
}

export function page(items: social_resource[], next: string | undefined): CrawlPage {
  return { items, next_cursor: items.length && next ? next : undefined };
}

export function submissionsPath(username: string): (page: number) => string {
  return (n: number) => `/account/${encodeURIComponent(username)}/submissions/${n}/newest`;
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function post(username: string, type: 'images' | 'albums' | 'posts', item: any): social_resource {
  const images: any[] = Array.isArray(item.images) ? item.images : [];
  const first: any = images[0] ?? item;
  return {
    type,
    resource_id: item.id ?? '',
    url: item.link ?? (item.id ? `https://imgur.com/${item.is_album ? 'a/' : ''}${item.id}` : ''),
    parent_url: `https://imgur.com/user/${username}`,
    title: clean(item.title),
    caption: clean(item.description),
    author: item.account_url ?? username,
    datetime: stamp(item.datetime),
    media_type: item.is_album ? 'album' : first.type ?? 'image',
    media_url: item.is_album ? (first.link ?? '') : (item.link ?? ''),
    thumbnail_url: item.cover ? `https://i.imgur.com/${item.cover}m.jpg` : (item.id ? `https://i.imgur.com/${item.id}m.jpg` : ''),
    likes: String((item.ups ?? 0) || ''),
    shares: '',
    views: String((item.views ?? 0) || ''),
    item_id: item.id ?? '',
    title_text: clean(item.title),
    description: clean(item.description),
    is_album: item.is_album ?? false,
    cover: item.cover ?? '',
    cover_width: item.cover_width ?? 0,
    cover_height: item.cover_height ?? 0,
    account_url: item.account_url ?? '',
    account_id: item.account_id ?? 0,
    privacy: item.privacy ?? '',
    layout: item.layout ?? '',
    views_count: item.views ?? 0,
    ups: item.ups ?? 0,
    downs: item.downs ?? 0,
    points: item.points ?? 0,
    score: item.score ?? 0,
    comment_count: item.comment_count ?? 0,
    favorite_count: item.favorite_count ?? 0,
    images_count: item.images_count ?? images.length,
    is_nsfw: item.nsfw ?? false,
    is_ad: item.is_ad ?? false,
    in_gallery: item.in_gallery ?? false,
    in_most_viral: item.in_most_viral ?? false,
    is_mature: item.mature ?? false,
    section: item.section ?? '',
    topic: item.topic ?? '',
    topic_id: item.topic_id ?? 0,
    tags: Array.isArray(item.tags) ? item.tags.map((tag: any) => tag?.name ?? tag?.display_name ?? '').filter(Boolean).join(', ') : '',
    image_links: images.map((image: any) => image?.link ?? '').filter(Boolean).slice(0, 50).join(', '),
    image_types: [...new Set(images.map((image: any) => image?.type ?? '').filter(Boolean))].join(', '),
    image_descriptions: images.map((image: any) => clean(image?.description)).filter(Boolean).slice(0, 20).join(' | '),
    total_size: images.reduce((sum: number, image: any) => sum + (image?.size ?? 0), 0),
    first_image_width: first.width ?? 0,
    first_image_height: first.height ?? 0,
    first_image_animated: first.animated ?? false,
    first_image_has_sound: first.has_sound ?? false,
    first_image_mp4: first.mp4 ?? '',
    ad_type: item.ad_type ?? 0,
    include_album_ads: item.include_album_ads ?? false,
    created_at: stamp(item.datetime),
  };
}
