import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, fetchPage, offsetOf, pagedPath, person } from './helper';

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://scratch.mit.edu/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    return await fetchPage(tab, `/users/${encodeURIComponent(username)}/projects`, payload, (project: any): social_resource => {
      const stats = project.stats ?? {};
      const history = project.history ?? {};
      const remix = project.remix ?? {};
      return {
        type: 'projects',
        resource_id: String(project.id ?? ''),
        url: project.id ? `https://scratch.mit.edu/projects/${project.id}/` : '',
        parent_url: `https://scratch.mit.edu/users/${username}/`,
        title: project.title ?? '',
        caption: clean(project.description),
        author: project.author?.username ?? username,
        datetime: history.shared ?? history.created ?? '',
        media_type: 'project',
        media_url: project.image ?? '',
        thumbnail_url: project.images?.['282x218'] ?? project.image ?? '',
        likes: String((stats.loves ?? 0) || ''),
        shares: String((stats.remixes ?? 0) || ''),
        views: String((stats.views ?? 0) || ''),
        project_id: project.id ?? 0,
        title_text: project.title ?? '',
        description: clean(project.description),
        instructions: clean(project.instructions),
        visibility: project.visibility ?? '',
        is_public: project.public ?? false,
        is_published: project.is_published ?? false,
        comments_allowed: project.comments_allowed ?? false,
        views_count: stats.views ?? 0,
        loves_count: stats.loves ?? 0,
        favorites_count: stats.favorites ?? 0,
        remixes_count: stats.remixes ?? 0,
        remix_parent: remix.parent ?? 0,
        remix_root: remix.root ?? 0,
        is_remix: Boolean(remix.parent ?? remix.root),
        image: project.image ?? '',
        image_282: project.images?.['282x218'] ?? '',
        image_216: project.images?.['216x163'] ?? '',
        image_200: project.images?.['200x200'] ?? '',
        image_144: project.images?.['144x108'] ?? '',
        author_id: project.author?.id ?? 0,
        author_username: project.author?.username ?? username,
        author_scratchteam: project.author?.scratchteam ?? false,
        author_joined: project.author?.history?.joined ?? '',
        author_avatar: project.author?.profile?.images?.['90x90'] ?? '',
        created_at: history.created ?? '',
        modified_at: history.modified ?? '',
        shared_at: history.shared ?? '',
      };
    });
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://scratch.mit.edu/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    return await fetchPage(tab, `/users/${encodeURIComponent(username)}/studios/curate`, payload, (studio: any): social_resource => {
      const stats = studio.stats ?? {};
      const history = studio.history ?? {};
      return {
        type: 'organizations',
        resource_id: String(studio.id ?? ''),
        url: studio.id ? `https://scratch.mit.edu/studios/${studio.id}/` : '',
        parent_url: `https://scratch.mit.edu/users/${username}/`,
        title: studio.title ?? '',
        caption: clean(studio.description),
        author: username,
        datetime: history.created ?? '',
        media_type: 'studio',
        media_url: studio.image ?? '',
        thumbnail_url: studio.image ?? '',
        likes: '',
        shares: '',
        views: '',
        studio_id: studio.id ?? 0,
        title_text: studio.title ?? '',
        description: clean(studio.description),
        host_id: studio.host ?? 0,
        visibility: studio.visibility ?? '',
        is_public: studio.public ?? false,
        open_to_all: studio.open_to_all ?? false,
        comments_allowed: studio.comments_allowed ?? false,
        followers_count: stats.followers ?? 0,
        managers_count: stats.managers ?? 0,
        projects_count: stats.projects ?? 0,
        comments_count: stats.comments ?? 0,
        image: studio.image ?? '',
        created_at: history.created ?? '',
        modified_at: history.modified ?? '',
      };
    });
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://scratch.mit.edu/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    return await fetchPage(tab, `/users/${encodeURIComponent(username)}/followers`, payload, (entry: any) => person(username, 'followers', entry));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://scratch.mit.edu/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    return await fetchPage(tab, `/users/${encodeURIComponent(username)}/following`, payload, (entry: any) => person(username, 'friends', entry));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

