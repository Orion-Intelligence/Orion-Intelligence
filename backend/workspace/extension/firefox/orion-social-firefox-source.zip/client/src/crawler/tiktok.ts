import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, tabJson } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { videos } from './resource/tiktok/tiktok';

export class TikTok implements Crawler {
  readonly platform = 'tiktok';
  readonly base = 'https://www.tiktok.com';
  readonly loginUrl = 'https://www.tiktok.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;
  readonly visibilityCrawling = true;

  readonly loginMarkers = {
    username: 'a[href^="/@"][data-e2e="nav-profile"], a[href^="/@"]',
    signedIn: ['[data-e2e="profile-icon"]', 'a[href^="/@"][data-e2e="nav-profile"]'],
    signedOut: ['[data-e2e="top-login-button"]', 'a[href*="/login"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.tiktok.com/@${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;

      let userInfo: any = null;
      try {
        const block = /<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/.exec(html);
        if (block) {
          userInfo = JSON.parse(block[1])?.__DEFAULT_SCOPE__?.['webapp.user-detail']?.userInfo ?? null;
        }
      }
      catch {
        userInfo = null;
      }

      const user: any = userInfo?.user ?? {};
      const stats: any = userInfo?.stats ?? userInfo?.statsV2 ?? {};
      const num = (value: any, key: string): number => Number(value ?? number(key)) || 0;

      const uniqueId = user.uniqueId || embedded('uniqueId');
      const nickname = user.nickname || embedded('nickname');
      if (!uniqueId && !nickname) {
        return [];
      }

      return [{
        real_name: nickname || uniqueId || username,
        bio: user.signature ?? embedded('signature'),
        description: user.signature ?? embedded('signature'),
        location: user.region ?? '',
        profile_url: `https://www.tiktok.com/@${uniqueId || username}`,
        total_posts: String(num(stats.videoCount, 'videoCount') || ''),
        total_followers: String(num(stats.followerCount, 'followerCount') || ''),
        total_likes: String(num(stats.heartCount ?? stats.heart, 'heartCount') || ''),
        avatar: user.avatarLarger || user.avatarMedium || embedded('avatarLarger') || meta('og:image'),
        banner: '',
        crawl_type: ['details', 'videos'],
        platform: this.platform,
        username: uniqueId || username,
        user_id: user.id ?? embedded('id'),
        sec_uid: user.secUid ?? '',
        nickname: nickname ?? '',
        follower_count: num(stats.followerCount, 'followerCount'),
        heart_count: num(stats.heartCount ?? stats.heart, 'heartCount'),
        video_count: num(stats.videoCount, 'videoCount'),
        digg_count: num(stats.diggCount, 'diggCount'),
        friend_count: num(stats.friendCount, 'friendCount'),
        bio_link: user.bioLink?.link ?? '',
        region: user.region ?? '',
        language: user.language ?? '',
        create_time: user.createTime ? new Date(user.createTime * 1000).toISOString() : '',
        nickname_modify_time: user.nickNameModifyTime ? new Date(user.nickNameModifyTime * 1000).toISOString() : '',
        verified: user.verified ?? /"verified"\s*:\s*true/.test(html),
        private: user.privateAccount ?? /"privateAccount"\s*:\s*true/.test(html),
        is_organization: user.isOrganization === 1 || user.isOrganization === true,
        tt_seller: user.ttSeller ?? false,
        commerce_category: user.commerceUserInfo?.category ?? '',
        open_favorite: user.openFavorite ?? false,
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const data = await tabJson(tab, 'https://www.tiktok.com/passport/web/account/info/', { Accept: 'application/json' });
    const user = data?.data || {};
    if (user.user_id_str || user.user_id || user.username || user.unique_id) {
      return { loggedIn: true, username: String(user.username || user.unique_id || user.screen_name || '') };
    }
    return NO_IDENTITY;
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.tiktok.com/passport/web/account/info/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.user_id_str || data?.data?.user_id);
    }
    catch {
      return false;
    }
  }
}
