import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { connections, members } from './resource/opencollective/opencollective';

export class OpenCollective implements Crawler {
  readonly platform = 'opencollective';
  readonly base = 'https://opencollective.com';
  readonly loginUrl = 'https://opencollective.com/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'connections':
        return connections(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const slug = String(payload.username ?? '');
    if (!slug) {
      return [];
    }

    try {
      const first = await members(slug, 0, 100);
      if (!first.length) {
        return [];
      }

      return [{
        real_name: slug,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://opencollective.com/${slug}`,
        total_posts: String(first.length >= 100 ? '100+' : first.length),
        total_followers: String(first.length >= 100 ? '100+' : first.length),
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'connections'],
        platform: this.platform,
        username: slug,
        members_sampled: first.length,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://opencollective.com/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
