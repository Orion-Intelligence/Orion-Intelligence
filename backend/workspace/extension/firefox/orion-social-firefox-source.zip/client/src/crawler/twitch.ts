import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { streams, videos } from './resource/twitch/twitch';

export class Twitch implements Crawler {
  readonly platform = 'twitch';
  readonly base = 'https://www.twitch.tv';
  readonly loginUrl = 'https://www.twitch.tv/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'streams':
        return streams(payload);
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch('https://gql.twitch.tv/gql', {
        method: 'POST',
        headers: { Accept: 'application/json', 'Content-Type': 'application/json', 'Client-Id': 'kimne78kx3ncx6brgo4mv6wki5h1ko' },
        body: JSON.stringify({
          query: 'query ($login: String!) { user(login: $login) { id login displayName description createdAt updatedAt primaryColorHex profileImageURL(width: 300) bannerImageURL followers { totalCount } roles { isPartner isAffiliate isStaff } lastBroadcast { startedAt title } stream { id viewersCount createdAt game { name } } } }',
          variables: { login: username },
        }),
      });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload?.data?.user;
      if (!data?.id) {
        return [];
      }

      const stream: any = data.stream ?? null;
      const last: any = data.lastBroadcast ?? {};

      return [{
        real_name: data.displayName ?? data.login ?? username,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: '',
        profile_url: `https://www.twitch.tv/${data.login ?? username}`,
        total_posts: '',
        total_followers: String((data.followers?.totalCount ?? 0) || ''),
        total_likes: '',
        avatar: data.profileImageURL ?? '',
        banner: data.bannerImageURL ?? '',
        crawl_type: ['details', 'streams', 'videos'],
        platform: this.platform,
        username: data.login ?? username,
        user_id: data.id ?? '',
        display_name: data.displayName ?? '',
        followers_count: data.followers?.totalCount ?? 0,
        partner: data.roles?.isPartner ?? false,
        affiliate: data.roles?.isAffiliate ?? false,
        staff: data.roles?.isStaff ?? false,
        primary_color: data.primaryColorHex ? `#${data.primaryColorHex}` : '',
        is_live: Boolean(stream?.id),
        stream_title: stream ? (last.title ?? '') : '',
        stream_game: stream?.game?.name ?? '',
        stream_viewers: stream?.viewersCount ?? 0,
        stream_started_at: stream?.createdAt ?? '',
        last_broadcast_title: last.title ?? '',
        last_broadcast_at: last.startedAt ?? '',
        created_at: data.createdAt ?? '',
        updated_at: data.updatedAt ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://gql.twitch.tv/gql', {
        method: 'POST',
        credentials: 'include',
        headers: { Accept: 'application/json', 'Content-Type': 'application/json', 'Client-Id': 'kimne78kx3ncx6brgo4mv6wki5h1ko' },
        body: JSON.stringify({ query: '{ currentUser { id login } }' }),
      });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.currentUser?.id);
    }
    catch {
      return false;
    }
  }
}
