import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, ORG_DISCOVERY_PAGES, PER_PAGE_MAX } from './constant';
import { OrgCursor } from './model';
import { api, articlesPage, clean, pageNumber, parseOrgCursor } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://dev.to/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const perPage = limitOf(payload, 25, PER_PAGE_MAX);
    const page = pageNumber(payload.cursor);
    const items = await articlesPage(tab, username, page, perPage);
    const fulls = await Promise.all(items.map((item: any) => api(tab, `articles/${item.id}`)));

    const resources = items.map((item: any, index: number): social_resource => {
      const full: any = fulls[index] ?? {};
      const user = item.user ?? full.user ?? {};
      const org = item.organization ?? full.organization ?? {};
      const tags: string[] = Array.isArray(item.tag_list) ? item.tag_list : String(item.tags ?? '').split(',').map((tag: string) => tag.trim()).filter(Boolean);
      return {
        type: 'posts',
        resource_id: String(item.id ?? ''),
        url: item.url ?? '',
        parent_url: `https://dev.to/${username}`,
        title: item.title ?? '',
        caption: clean(item.description),
        author: user.username ?? username,
        datetime: item.published_at ?? item.created_at ?? '',
        media_type: item.type_of ?? 'article',
        media_url: item.canonical_url ?? item.url ?? '',
        thumbnail_url: item.cover_image ?? item.social_image ?? '',
        likes: String((item.public_reactions_count ?? 0) || ''),
        shares: '',
        views: '',
        article_id: item.id ?? 0,
        slug: item.slug ?? '',
        path: item.path ?? '',
        description: clean(item.description),
        body_markdown: String(full.body_markdown ?? '').replace(/\s+/g, ' ').trim().slice(0, 4000),
        body_text: clean(full.body_html).slice(0, 4000),
        body_length: String(full.body_markdown ?? '').length,
        canonical_url: item.canonical_url ?? '',
        cover_image: item.cover_image ?? '',
        social_image: item.social_image ?? '',
        comments_count: item.comments_count ?? 0,
        public_reactions_count: item.public_reactions_count ?? 0,
        positive_reactions_count: item.positive_reactions_count ?? 0,
        reading_time_minutes: item.reading_time_minutes ?? 0,
        language: item.language ?? '',
        subforem_id: item.subforem_id ?? 0,
        collection_id: item.collection_id ?? 0,
        ai_disclosure_level: item.ai_disclosure_level ?? '',
        ai_disclosure_label: item.ai_disclosure_label ?? '',
        tags: tags.join(', '),
        tags_count: tags.length,
        flare_tag: item.flare_tag?.name ?? full.flare_tag?.name ?? '',
        readable_publish_date: item.readable_publish_date ?? '',
        published_at: item.published_at ?? '',
        published_timestamp: item.published_timestamp ?? '',
        created_at: item.created_at ?? '',
        edited_at: item.edited_at ?? '',
        crossposted_at: item.crossposted_at ?? '',
        last_comment_at: item.last_comment_at ?? '',
        author_name: user.name ?? '',
        author_username: user.username ?? '',
        author_twitter: user.twitter_username ?? '',
        author_github: user.github_username ?? '',
        author_website: user.website_url ?? '',
        author_avatar: user.profile_image ?? '',
        author_id: user.user_id ?? 0,
        org_id: org.id ?? 0,
        org_name: org.name ?? '',
        org_username: org.username ?? '',
        org_slug: org.slug ?? '',
        org_avatar: org.profile_image ?? '',
      };
    }).filter((item) => item.url);

    const hasMore = items.length >= perPage;
    return { items: resources, next_cursor: resources.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://dev.to/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, PER_PAGE_MAX);
    const cursor = parseOrgCursor(payload.cursor);
    const seen = new Set<string>(cursor?.seen ?? []);
    const handles: string[] = [];
    const take = (handle: unknown): void => {
      const value = String(handle ?? '');
      if (value && !seen.has(value)) {
        seen.add(value);
        handles.push(value);
      }
    };

    (cursor?.pending ?? []).forEach(take);
    if (!cursor) {
      const own = await api(tab, `organizations/${encodeURIComponent(username)}`);
      take(own?.username);
    }

    let page = cursor?.page ?? 1;
    let exhausted = false;
    const items: any[] = [];
    for (let scanned = 0; scanned < ORG_DISCOVERY_PAGES && handles.length < limit && !exhausted; scanned++) {
      const articles = await articlesPage(tab, username, page, limit);
      items.push(...articles);
      articles.forEach((item: any) => take(item.organization?.username));
      exhausted = articles.length < limit;
      page++;
    }

    const emit = handles.slice(0, limit);
    const pending = handles.slice(limit);
    const fulls = await Promise.all(emit.map((handle: string) => api(tab, `organizations/${encodeURIComponent(handle)}`)));
    const resources = fulls.map((org: any, index: number): social_resource => {
      const data: any = org ?? {};
      const handle = data.username ?? emit[index];
      return {
        type: 'organizations',
        resource_id: String(data.id ?? ''),
        url: handle ? `https://dev.to/${handle}` : '',
        parent_url: `https://dev.to/${username}`,
        title: data.name ?? handle ?? '',
        caption: clean(data.summary),
        author: handle ?? '',
        datetime: data.joined_at ?? '',
        media_type: data.type_of ?? 'organization',
        media_url: data.url ?? '',
        thumbnail_url: data.profile_image ?? '',
        likes: '',
        shares: '',
        views: '',
        org_id: data.id ?? 0,
        username: handle ?? '',
        name: data.name ?? '',
        summary: clean(data.summary),
        tag_line: clean(data.tag_line),
        slug: data.slug ?? '',
        story: clean(data.story).slice(0, 2000),
        location: data.location ?? '',
        tech_stack: clean(data.tech_stack),
        website_url: data.url ?? '',
        github_username: data.github_username ?? '',
        twitter_username: data.twitter_username ?? '',
        profile_image: data.profile_image ?? '',
        profile_image_90: data.profile_image_90 ?? '',
        joined_at: data.joined_at ?? '',
        email: data.email ?? '',
        cta_button_text: data.cta_button_text ?? '',
        cta_button_url: data.cta_button_url ?? '',
        articles_here: items.filter((item: any) => item.organization?.username === handle).length,
      };
    }).filter((item) => item.url);

    const hasMore = pending.length > 0 || !exhausted;
    const next: OrgCursor = { page, seen: [...seen], pending };
    return { items: resources, next_cursor: resources.length && hasMore ? JSON.stringify(next) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  const match = /dev\.to\/([^/]+)\/([^/?#]+)/.exec(postUrl);
  if (!match) {
    return EMPTY;
  }
  const tab = await openSession('https://dev.to/');
  if (!tab) {
    return EMPTY;
  }
  try {
    const article = await api(tab, `articles/${encodeURIComponent(match[1])}/${encodeURIComponent(match[2])}`);
    const id = article?.id;
    if (!id) {
      return EMPTY;
    }
    const list = await api(tab, `comments?a_id=${id}`);
    const comments: any[] = Array.isArray(list) ? list : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const comment of comments) {
      const user = comment?.user ?? {};
      const username = String(user.username ?? '');
      if (!username || seen.has(username)) {
        continue;
      }
      seen.add(username);
      items.push({
        type: 'connections',
        resource_id: username,
        url: `https://dev.to/${username}`,
        parent_url: postUrl,
        title: user.name ?? username,
        caption: clean(comment.body_html).slice(0, 600),
        author: username,
        datetime: comment.created_at ?? '',
        media_type: 'user',
        media_url: `https://dev.to/${username}`,
        thumbnail_url: user.profile_image_90 ?? user.profile_image ?? '',
        likes: '',
        shares: '',
        views: '',
        handle: username,
        comment_id: comment.id_code ?? '',
        comment_text: clean(comment.body_html),
        comment_url: postUrl,
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
