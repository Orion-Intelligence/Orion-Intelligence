import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';

export class Bilibili implements Crawler {
  readonly platform = 'bilibili';
  readonly base = 'https://www.bilibili.com';
  readonly loginUrl = 'https://passport.bilibili.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(_type: CrawlType, _payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    return { items: [] };
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const mid = /^\d+$/.test(username) ? username : (/space\.bilibili\.com\/(\d+)/.exec(url ?? '')?.[1] ?? '');
      if (!mid) {
        return [];
      }

      const response = await fetch(`https://api.bilibili.com/x/web-interface/card?mid=${mid}`, { headers: { Accept: 'application/json', Referer: 'https://space.bilibili.com/' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data: any = payload?.data ?? {};
      const card: any = data.card;
      if (!card?.mid) {
        return [];
      }

      return [{
        real_name: card.name ?? '',
        bio: card.sign ?? '',
        description: card.sign ?? '',
        location: card.place && card.place !== '' ? card.place : '',
        profile_url: `https://space.bilibili.com/${card.mid}`,
        total_posts: String((data.archive_count ?? 0) || ''),
        total_followers: String((data.follower ?? card.fans ?? 0) || ''),
        total_likes: String((data.like_num ?? 0) || ''),
        avatar: card.face ?? '',
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username: String(card.mid),
        mid: card.mid ?? '',
        sex: card.sex ?? '',
        level: card.level_info?.current_level ?? 0,
        rank: card.rank ?? '',
        fans: data.follower ?? card.fans ?? 0,
        friend: card.friend ?? 0,
        archive_count: data.archive_count ?? 0,
        like_num: data.like_num ?? 0,
        birthday: card.birthday && card.birthday !== '' ? card.birthday : '',
        place: card.place && card.place !== '' ? card.place : '',
        register_time: card.regtime ? new Date(card.regtime * 1000).toISOString() : '',
        vip: card.vip?.status === 1,
        vip_type: card.vip?.type ?? 0,
        vip_label: card.vip?.label?.text ?? '',
        official: card.official_verify?.desc ?? card.Official?.title ?? '',
        official_type: card.official_verify?.type ?? -1,
        is_senior_member: card.is_senior_member === 1,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://api.bilibili.com/x/web-interface/nav', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.isLogin === true);
    }
    catch {
      return false;
    }
  }
}
