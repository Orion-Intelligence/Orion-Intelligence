import { social_resource } from '../../../app/extension/model/extension.model';

export interface Cursor { o: number; last: string }

export interface Entry { url: string; lastmod: string; item?: social_resource }
