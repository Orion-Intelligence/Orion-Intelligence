import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, followers, videos } from './resource/dailymotion/dailymotion';

export class Dailymotion implements Crawler {
  readonly platform = 'dailymotion';
  readonly base = 'https://www.dailymotion.com';
  readonly loginUrl = 'https://www.dailymotion.com/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'videos':
        return videos(payload);
      case 'albums':
        return albums(payload);
      case 'followers':
        return followers(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.dailymotion.com/user/${encodeURIComponent(username)}?fields=id,username,screenname,description,followers_total,videos_total,avatar_240_url,cover_url,url,created_time`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.screenname ?? data.username ?? username,
        bio: String(data.description ?? '').replace(/\s+/g, ' ').trim(),
        description: String(data.description ?? '').replace(/\s+/g, ' ').trim(),
        location: data.country ?? '',
        profile_url: data.url ?? `https://www.dailymotion.com/${username}`,
        total_posts: String((data.videos_total ?? 0) || ''),
        total_followers: String((data.followers_total ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar_720_url ?? '',
        banner: data.cover_url ?? '',
        crawl_type: ['details', 'videos', 'albums', 'followers'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? '',
        videos_total: data.videos_total ?? 0,
        followers_total: data.followers_total ?? 0,
        fans_total: data.fans_total ?? 0,
        views_total: data.views_total ?? 0,
        verified: data.verified ?? false,
        country: data.country ?? '',
        language: data.language ?? '',
        created_at: data.created_time ? new Date(data.created_time * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://api.dailymotion.com/me?fields=id,username', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
