import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { games, projects } from './resource/lichess/lichess';

export class Lichess implements Crawler {
  readonly platform = 'lichess';
  readonly base = 'https://lichess.org';
  readonly loginUrl = 'https://lichess.org/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://lichess.org/api/user/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.profile?.realName || [data.profile?.firstName, data.profile?.lastName].filter(Boolean).join(' ') || data.username || username,
        bio: data.profile?.bio ?? '',
        description: data.profile?.bio ?? '',
        location: data.profile?.location ?? '',
        profile_url: data.url ?? `https://lichess.org/@/${data.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'games', 'projects'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? '',
        title: data.title ?? '',
        flair: data.flair ?? '',
        country: data.profile?.flag ?? '',
        fide_rating: data.profile?.fideRating ?? 0,
        website: data.profile?.links ?? '',
        games: data.count?.all ?? 0,
        rated_games: data.count?.rated ?? 0,
        wins: data.count?.win ?? 0,
        losses: data.count?.loss ?? 0,
        draws: data.count?.draw ?? 0,
        bookmarks: data.count?.bookmark ?? 0,
        imports: data.count?.import ?? 0,
        play_time_total: data.playTime?.total ?? 0,
        play_time_tv: data.playTime?.tv ?? 0,
        bullet_rating: data.perfs?.bullet?.rating ?? 0,
        blitz_rating: data.perfs?.blitz?.rating ?? 0,
        rapid_rating: data.perfs?.rapid?.rating ?? 0,
        classical_rating: data.perfs?.classical?.rating ?? 0,
        puzzle_rating: data.perfs?.puzzle?.rating ?? 0,
        patron: data.patron ?? false,
        streamer: Boolean(data.streamer),
        last_seen: data.seenAt ? new Date(data.seenAt).toISOString() : '',
        created_at: data.createdAt ? new Date(data.createdAt).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://lichess.org/api/account', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
