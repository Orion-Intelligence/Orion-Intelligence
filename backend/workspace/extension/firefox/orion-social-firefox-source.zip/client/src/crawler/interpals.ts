import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityHtml } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/interpals/interpals';

export class InterPals implements Crawler {
  readonly platform = 'interpals';
  readonly base = 'https://www.interpals.net';
  readonly loginUrl = 'https://www.interpals.net/app/auth/login';
  readonly authwall = ALL_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.interpals.net/${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');

      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const displayName = decode(/class="[^"]*profDataTopName[^"]*"[^>]*>([\s\S]*?)<\/(?:h1|div|span)>/i.exec(html)?.[1] ?? '') || title.replace(/\s*[|-]\s*InterPals.*$/i, '').trim();
      if (!displayName || /^InterPals$/i.test(displayName)) {
        return [];
      }

      const row = (label: string): string => decode(new RegExp(`${label}[\\s\\S]{0,80}?<(?:td|div|span)[^>]*>([\\s\\S]*?)</(?:td|div|span)>`, 'i').exec(html)?.[1] ?? '');
      return [{
        real_name: displayName,
        bio: decode(/class="[^"]*profDataAbout[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(html)?.[1] ?? '') || meta('og:description'),
        description: decode(/class="[^"]*profDataAbout[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(html)?.[1] ?? '') || meta('og:description'),
        location: row('(?:Living in|Location|From)'),
        profile_url: `https://www.interpals.net/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: /class="[^"]*profDataPhoto[^"]*"[\s\S]*?<img[^>]+src="([^"]+)"/i.exec(html)?.[1] ?? meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: username,
        age: row('Age'),
        gender: row('Sex'),
        languages: row('Speaks'),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityHtml(tab, 'https://www.interpals.net/', /type=["']password["']|name=["']passwd["']/i);
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.interpals.net/app/login', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      const html = await response.text();
      return !/type=["']password["']/i.test(html) && !/name=["']passwd["']/i.test(html);
    }
    catch {
      return false;
    }
  }
}
