import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function uploads(username: string, offset: number, limit: number): Promise<any[]> {
  const response = await fetch(`https://ccmixter.org/api/query?u=${encodeURIComponent(username.trim())}&f=json&limit=${limit}&offset=${offset}&sort=date`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return [];
  }
  const data = await response.json();
  return Array.isArray(data) ? data : [];
}

export async function details(username: string): Promise<social_profile_details[]> {
  const rows = await uploads(username, 0, 50);
  if (!rows.length) {
    return [];
  }

  const first = rows[0] ?? {};
  return [{
    real_name: clean(first.user_real_name) || username,
    bio: '',
    description: '',
    location: '',
    profile_url: first.artist_page_url ?? `https://ccmixter.org/people/${username}`,
    total_posts: String(rows.length >= 50 ? '50+' : rows.length),
    total_followers: '',
    total_likes: '',
    avatar: '',
    banner: '',
    crawl_type: ['details', 'tracks'],
    platform: 'ccmixter',
    username,
    uploads_sampled: rows.length,
    tracks_note: rows.length >= 50 ? 'first page' : 'all',
  }];
}

export async function tracks(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const rows = await uploads(username, offset, limit);
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((upload: any): social_resource => {
      const files = Array.isArray(upload.files) ? upload.files : [];
      const tags = String(upload.upload_tags ?? '').split(',').map((tag: string) => tag.trim()).filter(Boolean);
      return {
        type: 'tracks',
        resource_id: String(upload.upload_id ?? ''),
        url: upload.file_page_url ?? `https://ccmixter.org/files/${username}/${upload.upload_id ?? ''}`,
        parent_url: upload.artist_page_url ?? `https://ccmixter.org/people/${username}`,
        title: clean(upload.upload_name),
        caption: clean(upload.upload_description_plain),
        author: clean(upload.user_real_name) || username,
        datetime: upload.upload_date_format ?? '',
        media_type: 'track',
        media_url: files[0]?.download_url ?? '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((upload.upload_num_scores ?? 0) || ''),
        name: clean(upload.upload_name),
        description: clean(upload.upload_description_plain),
        license: clean(upload.license_name),
        license_url: upload.license_url ?? '',
        tags: tags.join(', '),
        num_scores: upload.upload_num_scores ?? 0,
        files_count: files.length,
      };
    }).filter((item) => item.url && item.resource_id);

    return { items, next_cursor: items.length && rows.length >= limit ? String(offset + rows.length) : undefined };
  }
  catch {
    return EMPTY;
  }
}
