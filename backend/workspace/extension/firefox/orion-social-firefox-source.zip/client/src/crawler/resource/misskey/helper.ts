import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { Cursor, Upstream } from './model';

export function origin(payload: CrawlPayload): string {
  return /^https?:\/\/[^/]+/.exec(payload.url ?? '')?.[0] ?? 'https://misskey.io';
}

export async function api(tab: TabController, base: string, path: string, body: Record<string, unknown>): Promise<any> {
  try {
    const response = await tab.fetch(`${base}/api/${path}`, {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export async function accountId(tab: TabController, base: string, username: string): Promise<string> {
  const handle = username.replace(/^@/, '');
  const [name, host] = handle.split('@');
  const user = await api(tab, base, 'users/show', host ? { username: name, host } : { username: name });
  return String(user?.id ?? '');
}

export function parseCursor(payload: CrawlPayload): Cursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { id: '', until: '' };
  }

  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return { id: String(parsed.id ?? ''), until: String(parsed.until ?? '') };
    }
  }
  catch {
  }
  return { id: '', until: raw };
}

export async function fetchPage(tab: TabController, base: string, path: string, payload: CrawlPayload, username: string, extra: Record<string, unknown> = {}): Promise<Upstream> {
  const cursor = parseCursor(payload);
  const id = cursor.id || await accountId(tab, base, username);
  if (!id) {
    return { raw: [] };
  }

  const limit = limitOf(payload, 25, 100);
  const body: Record<string, unknown> = { userId: id, limit, ...extra };
  if (cursor.until) {
    body['untilId'] = cursor.until;
  }

  const data = await api(tab, base, path, body);
  const raw = (Array.isArray(data) ? data : []) as any[];
  const last = String(raw[raw.length - 1]?.id ?? '');
  const next = raw.length >= limit && last && last !== cursor.until ? JSON.stringify({ id, until: last }) : undefined;
  return { raw, next };
}

export function page(items: social_resource[], upstream: Upstream): CrawlPage {
  return { items, next_cursor: items.length && upstream.next ? upstream.next : undefined };
}

export function person(base: string, username: string, type: 'followers' | 'friends', entry: any): social_resource {
  const user = entry.follower ?? entry.followee ?? entry;
  const roles: any[] = Array.isArray(user.badgeRoles) ? user.badgeRoles : [];
  const handle = user.host ? `${user.username}@${user.host}` : user.username ?? '';
  return {
    type,
    resource_id: user.id ?? '',
    url: handle ? `${base}/@${handle}` : '',
    parent_url: `${base}/@${username}`,
    title: user.name ?? user.username ?? '',
    caption: clean(user.description).slice(0, 600),
    author: handle,
    datetime: entry.createdAt ?? '',
    media_type: user.isBot ? 'bot' : 'user',
    media_url: handle ? `${base}/@${handle}` : '',
    thumbnail_url: user.avatarUrl ?? '',
    likes: '',
    shares: '',
    views: '',
    relation_id: entry.id ?? '',
    user_id: user.id ?? '',
    username: user.username ?? '',
    handle,
    name: user.name ?? '',
    host: user.host ?? '',
    description: clean(user.description),
    avatar: user.avatarUrl ?? '',
    avatar_blurhash: user.avatarBlurhash ?? '',
    banner: user.bannerUrl ?? '',
    is_bot: user.isBot ?? false,
    is_cat: user.isCat ?? false,
    is_admin: user.isAdmin ?? false,
    is_moderator: user.isModerator ?? false,
    is_locked: user.isLocked ?? false,
    is_silenced: user.isSilenced ?? false,
    is_suspended: user.isSuspended ?? false,
    online_status: user.onlineStatus ?? '',
    badge_roles: roles.map((role: any) => role?.name ?? '').filter(Boolean).join(', '),
    badge_roles_count: roles.length,
    emojis: user.emojis && typeof user.emojis === 'object' ? Object.keys(user.emojis).join(', ') : '',
    avatar_decorations: Array.isArray(user.avatarDecorations) ? user.avatarDecorations.length : 0,
    followee_id: entry.followeeId ?? '',
    follower_id: entry.followerId ?? '',
    created_at: entry.createdAt ?? '',
  };
}
