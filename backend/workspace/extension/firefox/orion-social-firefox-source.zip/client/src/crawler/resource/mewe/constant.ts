import { CrawlPage } from '../../../app/extension/model/extension.model';

export const ORIGIN = 'https://mewe.com';

export const EMPTY: CrawlPage = { items: [] };
