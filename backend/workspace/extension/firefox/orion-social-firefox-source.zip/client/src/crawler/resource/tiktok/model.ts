export interface ItemPage {
  list: any[];
  user: any;
  cursor: string;
  hasMore: boolean;
}
