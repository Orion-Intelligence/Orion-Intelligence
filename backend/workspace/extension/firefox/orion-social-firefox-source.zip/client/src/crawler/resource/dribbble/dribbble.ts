import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { blockEnd, decode, pageOf, widest } from './helper';

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://dribbble.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload.cursor);
    const perPage = limitOf(payload, 24, 28);
    const response = await tab.fetch(`https://dribbble.com/${encodeURIComponent(username)}?page=${page}&per_page=${perPage}`);
    if (!response.ok) {
      return EMPTY;
    }

    const html = response.body;
    const displayName = decode(/<h1[^>]*class="[^"]*profile-name[^"]*"[^>]*>([\s\S]*?)<\/h1>/i.exec(html)?.[1] ?? /<meta property="og:title" content="([^"]*)"/i.exec(html)?.[1] ?? '');
    const seen = new Set<string>();
    const items: social_resource[] = [];

    const starts = [...html.matchAll(/<li[^>]+id="screenshot-(\d+)"/g)];
    for (let index = 0; index < starts.length; index++) {
      const match = starts[index];
      const id = match[1];
      if (seen.has(id)) {
        continue;
      }
      seen.add(id);
      const block = html.slice(match.index ?? 0, blockEnd(html, match.index ?? 0, starts[index + 1]?.index));
      const href = /href="(\/shots\/\d+[^"?#]*)"/.exec(block)?.[1] ?? `/shots/${id}`;
      const srcset = /data-srcset="([^"]+)"|srcset="([^"]+)"/.exec(block);
      const image = widest(decode(srcset?.[1] ?? srcset?.[2] ?? ''));
      const title = decode(/<div class="shot-title">([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? /<span class="accessibility-text">View ([\s\S]*?)<\/span>/i.exec(block)?.[1] ?? href.split('/').pop()?.replace(/^\d+-/, '').replace(/-/g, ' ') ?? '');
      const likes = /(\d[\d,.km]*)\s*<\/span>\s*<\/drb-shot-like>|data-likes-count="(\d+)"/i.exec(block);
      const views = /data-views-count="(\d+)"|(\d[\d,.km]*)\s*views/i.exec(block);
      items.push({
        type: 'projects',
        resource_id: id,
        url: `https://dribbble.com${href}`,
        parent_url: `https://dribbble.com/${username}`,
        title,
        caption: '',
        author: username,
        datetime: '',
        media_type: /video|\.mp4/i.test(block) ? 'video' : 'shot',
        media_url: image,
        thumbnail_url: image || decode(/<img[^>]+data-src="([^"]+)"/i.exec(block)?.[1] ?? ''),
        likes: String(likes?.[1] ?? likes?.[2] ?? ''),
        shares: '',
        views: String(views?.[1] ?? views?.[2] ?? ''),
        shot_id: id,
        slug: href.split('/').pop() ?? '',
        shot_title: title,
        shot_url: `https://dribbble.com${href}`,
        image_url: image,
        image_thumbnail: decode(/<img[^>]+data-src="([^"]+)"/i.exec(block)?.[1] ?? ''),
        image_srcset_count: (decode(srcset?.[1] ?? srcset?.[2] ?? '').match(/,/g) ?? []).length + (srcset ? 1 : 0),
        is_video: /video|\.mp4/i.test(block),
        is_animated: /\.gif/i.test(block),
        has_multiple_shots: /shot-thumbnail-extras/.test(block),
        is_rebound: /rebound/i.test(block),
        is_pro: /badge-pro|is-pro/i.test(block),
        is_team_shot: /team-link/i.test(block),
        author_username: username,
        author_display_name: displayName,
        author_url: `https://dribbble.com/${username}`,
        message_recipient_id: /data-message-recipient="(\d+)"/.exec(block)?.[1] ?? '',
        tags: [...new Set([...block.matchAll(/href="\/tags\/([^"]+)"/g)].map((tag) => decode(tag[1]).replace(/-/g, ' ')))].join(', '),
      });
    }

    if (!items.length) {
      for (const match of html.matchAll(/href="(\/shots\/(\d+)[^"?#]*)"/g)) {
        const id = match[2];
        if (seen.has(id)) {
          continue;
        }
        seen.add(id);
        const block = html.slice(Math.max(0, (match.index ?? 0) - 3000), (match.index ?? 0) + 1200);
        const srcset = /data-srcset="([^"]+)"|srcset="([^"]+)"/.exec(block);
        const image = widest(decode(srcset?.[1] ?? srcset?.[2] ?? ''));
        const title = decode(/<div class="shot-title">([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? match[1].split('/').pop()?.replace(/^\d+-/, '').replace(/-/g, ' ') ?? '');
        items.push({
          type: 'projects',
          resource_id: id,
          url: `https://dribbble.com${match[1]}`,
          parent_url: `https://dribbble.com/${username}`,
          title,
          caption: '',
          author: username,
          datetime: '',
          media_type: 'shot',
          media_url: image,
          thumbnail_url: image || decode(/<img[^>]+data-src="([^"]+)"/i.exec(block)?.[1] ?? ''),
          likes: '',
          shares: '',
          views: '',
          shot_id: id,
          slug: match[1].split('/').pop() ?? '',
          shot_title: title,
          shot_url: `https://dribbble.com${match[1]}`,
          image_url: image,
          image_thumbnail: decode(/<img[^>]+data-src="([^"]+)"/i.exec(block)?.[1] ?? ''),
          image_srcset_count: (decode(srcset?.[1] ?? srcset?.[2] ?? '').match(/,/g) ?? []).length + (srcset ? 1 : 0),
          is_video: /video|\.mp4/i.test(block),
          is_animated: /\.gif/i.test(block),
          has_multiple_shots: /shot-thumbnail-extras/.test(block),
          is_rebound: /rebound/i.test(block),
          is_pro: /badge-pro|is-pro/i.test(block),
          is_team_shot: /team-link/i.test(block),
          author_username: username,
          author_display_name: displayName,
          author_url: `https://dribbble.com/${username}`,
          message_recipient_id: /data-message-recipient="(\d+)"/.exec(block)?.[1] ?? '',
          tags: '',
        });
      }
    }

    const hasNext = new RegExp(`[?&](?:amp;)?page=${page + 1}(?:&amp;|&|["'])`).test(html) || items.length >= perPage;
    return { items, next_cursor: items.length && hasNext ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
