import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { repositories } from './resource/dockerhub/dockerhub';

export class DockerHub implements Crawler {
  readonly platform = 'dockerhub';
  readonly base = 'https://hub.docker.com';
  readonly loginUrl = 'https://hub.docker.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://hub.docker.com/v2/users/${encodeURIComponent(username)}/`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.full_name || data.username || data.orgname || username,
        bio: '',
        description: '',
        location: data.location ?? '',
        profile_url: `https://hub.docker.com/u/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.gravatar_url ?? '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: data.username ?? data.orgname ?? username,
        id: data.id ?? '',
        uuid: data.uuid ?? '',
        full_name: data.full_name ?? '',
        company: data.company ?? '',
        email: data.gravatar_email ?? '',
        account_type: data.type ?? '',
        badge: data.badge ?? '',
        is_active: data.is_active ?? false,
        created_at: data.date_joined ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://hub.docker.com/v2/user/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.username);
    }
    catch {
      return false;
    }
  }
}
