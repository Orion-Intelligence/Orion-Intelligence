import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { CHARSET, EMPTY, MAX_SKIP, RELAYS, RELAY_TIMEOUT_MS } from './constant';
import { NostrCursor, NostrEvent } from './model';

export function parseCursor(payload: CrawlPayload): NostrCursor | null {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return null;
  }

  try {
    const parsed = /^\d+$/.test(raw) ? { until: Number(raw) } : JSON.parse(raw);
    const until = Math.floor(Number(parsed?.until));
    if (!Number.isFinite(until) || until <= 0) {
      return null;
    }
    const skip = Array.isArray(parsed?.skip) ? parsed.skip.map((id: unknown) => String(id ?? '')).filter(Boolean).slice(0, MAX_SKIP) : [];
    return { until, skip };
  }
  catch {
    return null;
  }
}

export async function relayNotes(pubkey: string, limit: number, cursor: NostrCursor | null): Promise<NostrEvent[]> {
  if (typeof WebSocket === 'undefined') {
    return [];
  }

  const filter: Record<string, unknown> = { kinds: [1], authors: [pubkey], limit: Math.min(limit + (cursor?.skip.length ?? 0), 500) };
  if (cursor) {
    filter['until'] = cursor.until;
  }

  const results = await Promise.all(RELAYS.map((relay) => relayQuery(relay, filter)));
  const skip = new Set(cursor?.skip ?? []);
  const merged = new Map<string, NostrEvent>();
  for (const event of results.flat()) {
    if (!event?.id || skip.has(event.id) || event.pubkey !== pubkey || (cursor && event.created_at > cursor.until)) {
      continue;
    }
    merged.set(event.id, event);
  }
  return [...merged.values()].sort((a, b) => b.created_at - a.created_at || a.id.localeCompare(b.id));
}

export function relayQuery(relay: string, filter: Record<string, unknown>): Promise<NostrEvent[]> {
  return new Promise((resolve) => {
    const events: NostrEvent[] = [];
    let done = false;
    let socket: WebSocket | null = null;
    const finish = (): void => {
      if (done) {
        return;
      }
      done = true;
      clearTimeout(timer);
      try {
        socket?.close();
      }
      catch {
      }
      resolve(events);
    };
    const timer = setTimeout(finish, RELAY_TIMEOUT_MS);

    try {
      socket = new WebSocket(relay);
      socket.onopen = (): void => socket?.send(JSON.stringify(['REQ', `orion-${Date.now().toString(36)}`, filter]));
      socket.onmessage = (message: MessageEvent): void => {
        try {
          const data = JSON.parse(String(message.data));
          if (data?.[0] === 'EVENT' && data[2]?.id) {
            events.push(data[2] as NostrEvent);
          }
          else if (data?.[0] === 'EOSE' || data?.[0] === 'CLOSED') {
            finish();
          }
        }
        catch {
        }
      };
      socket.onerror = finish;
      socket.onclose = finish;
    }
    catch {
      finish();
    }
  });
}

export async function scrapeLastNotes(npub: string): Promise<CrawlPage> {
  const tab = await openSession('https://njump.me/');
  if (!tab) {
    return EMPTY;
  }
  try {
    const response = await tab.fetch(`https://njump.me/${encodeURIComponent(npub)}`);
    if (!response.ok) {
      return EMPTY;
    }

    const html = response.body;
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const match of html.matchAll(/href="\/(nevent1[a-z0-9]+)"/gi)) {
      const eventId = match[1];
      if (seen.has(eventId)) {
        continue;
      }
      seen.add(eventId);
      const block = html.slice(match.index ?? 0, (match.index ?? 0) + 4000);
      items.push({
        type: 'posts',
        resource_id: eventId,
        url: `https://njump.me/${eventId}`,
        parent_url: `https://njump.me/${npub}`,
        title: '',
        caption: decode(/itemprop="articleBody"[^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? /<div[^>]+class="[^"]*note-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? ''),
        author: npub,
        datetime: /datetime="([^"]+)"/i.exec(block)?.[1] ?? '',
        media_type: 'note',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export function pubkeyOf(value: string): string {
  if (/^[0-9a-f]{64}$/i.test(value)) {
    return value.toLowerCase();
  }
  const decoded = bech32Decode(value);
  return decoded?.prefix === 'npub' && decoded.bytes.length === 32 ? hex(decoded.bytes) : '';
}

export function nevent(event: NostrEvent): string {
  const id = bytes(event.id);
  const author = bytes(event.pubkey);
  const tlv = [0, id.length, ...id];
  if (author.length === 32) {
    tlv.push(2, author.length, ...author);
  }
  return bech32Encode('nevent', tlv);
}

export function bech32Decode(value: string): { prefix: string; bytes: number[] } | null {
  const lower = String(value ?? '').toLowerCase();
  const split = lower.lastIndexOf('1');
  if (split < 1 || lower.length - split - 1 < 6) {
    return null;
  }

  const prefix = lower.slice(0, split);
  const words: number[] = [];
  for (const char of lower.slice(split + 1)) {
    const word = CHARSET.indexOf(char);
    if (word < 0) {
      return null;
    }
    words.push(word);
  }
  if (polymod([...expandPrefix(prefix), ...words]) !== 1) {
    return null;
  }
  return { prefix, bytes: convertBits(words.slice(0, -6), 5, 8, false) };
}

export function bech32Encode(prefix: string, data: number[]): string {
  const words = convertBits(data, 8, 5, true);
  const values = [...expandPrefix(prefix), ...words];
  const mod = polymod([...values, 0, 0, 0, 0, 0, 0]) ^ 1;
  const checksum = Array.from({ length: 6 }, (_, i) => (mod >> (5 * (5 - i))) & 31);
  return `${prefix}1${[...words, ...checksum].map((word) => CHARSET[word]).join('')}`;
}

export function expandPrefix(prefix: string): number[] {
  const codes = [...prefix].map((char) => char.charCodeAt(0));
  return [...codes.map((code) => code >> 5), 0, ...codes.map((code) => code & 31)];
}

export function polymod(values: number[]): number {
  const generator = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let checksum = 1;
  for (const value of values) {
    const top = checksum >>> 25;
    checksum = ((checksum & 0x1ffffff) << 5) ^ value;
    for (let i = 0; i < 5; i++) {
      if ((top >> i) & 1) {
        checksum ^= generator[i];
      }
    }
  }
  return checksum >>> 0;
}

export function convertBits(data: number[], from: number, to: number, pad: boolean): number[] {
  let acc = 0;
  let bits = 0;
  const out: number[] = [];
  const max = (1 << to) - 1;
  for (const value of data) {
    acc = (acc << from) | value;
    bits += from;
    while (bits >= to) {
      bits -= to;
      out.push((acc >> bits) & max);
    }
  }
  if (pad && bits > 0) {
    out.push((acc << (to - bits)) & max);
  }
  return out;
}

export function bytes(value: string): number[] {
  const clean = String(value ?? '').toLowerCase();
  return /^[0-9a-f]+$/.test(clean) && clean.length % 2 === 0 ? (clean.match(/.{2}/g) ?? []).map((pair) => parseInt(pair, 16)) : [];
}

export function hex(data: number[]): string {
  return data.map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

export function text(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}
