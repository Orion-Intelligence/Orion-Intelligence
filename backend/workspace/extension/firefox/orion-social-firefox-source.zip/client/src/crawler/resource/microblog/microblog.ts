import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_COUNT } from './constant';
import { clean, cursorOf, entry, feed } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  const tab = username ? await openSession('https://micro.blog/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, 100);
    const { offset, last } = cursorOf(payload);

    const requested = Math.min(Math.max(offset + limit, limit), MAX_COUNT);
    const query = `count=${requested}${last ? `&before_id=${encodeURIComponent(last)}` : ''}`;
    const data = await feed(tab, `https://micro.blog/posts/${encodeURIComponent(username)}?${query}`);
    const raw = (Array.isArray(data?.items) ? data.items : []) as any[];

    const anchor = last ? raw.findIndex((item: any) => String(item?.id ?? '') === last) : -1;
    const honored = Boolean(last) && raw.length > 0 && Number(raw[0]?.id) < Number(last);
    const start = anchor >= 0 ? anchor + 1 : honored ? 0 : offset;
    const slice = raw.slice(start, start + limit);
    const items = slice.map((item: any) => entry(username, 'posts', item)).filter((item) => item.url);

    const consumed = start + slice.length;
    const hasMore = consumed < raw.length || raw.length >= requested;
    if (!items.length || !hasMore || consumed >= MAX_COUNT * 2) {
      return { items };
    }

    return { items, next_cursor: JSON.stringify({ offset: consumed, last: String(slice[slice.length - 1]?.id ?? '') }) };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
