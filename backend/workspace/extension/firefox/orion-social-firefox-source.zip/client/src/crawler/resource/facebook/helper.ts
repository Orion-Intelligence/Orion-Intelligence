import { CrawlPayload, CrawlType, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { MAX_BUNDLES, REFETCH_QUERY } from './constant';
import { CollectionKind, CollectionSpec, TimelineCursor, Tokens } from './model';

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function countOf(text: string): number {
  const found = /([\d.,]+)\s*([KMB]?)/i.exec(text ?? '');
  const scale: Record<string, number> = { K: 1e3, M: 1e6, B: 1e9 };
  return found ? Math.round(Number(found[1].replace(/,/g, '')) * (scale[found[2].toUpperCase()] ?? 1)) : 0;
}

export function decodeEntities(value: string): string {
  return value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function metaOf(html: string, key: string): string {
  return decodeEntities(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
}

export function isNumericProfile(username: string): boolean {
  return /^\d+$/.test(username) || /profile\.php\?id=/.test(username);
}

export function profileBase(username: string): string {
  if (isNumericProfile(username)) {
    const id = username.replace(/^.*profile\.php\?id=/, '').replace(/&.*$/, '');
    return `https://www.facebook.com/profile.php?id=${id}`;
  }
  return `https://www.facebook.com/${encodeURIComponent(username)}`;
}

export function profileUrl(username: string, sk: string = ''): string {
  const base = profileBase(username);
  if (!sk) {
    return base;
  }
  return isNumericProfile(username) ? `${base}&sk=${sk}` : `${base}/${sk}`;
}

export function sectionsOf(html: string): CrawlType[] {
  const names = new Map<string, string>();
  for (const match of html.matchAll(/"name":"([^"]{1,40})","section_type":"([A-Z_]+)"/g)) {
    names.set(match[2], match[1]);
  }
  for (const match of html.matchAll(/"section_type":"([A-Z_]+)"[^}]{0,120}?"name":"([^"]{1,40})"/g)) {
    if (!names.has(match[1])) {
      names.set(match[1], match[2]);
    }
  }
  const out: CrawlType[] = ['details', 'posts'];
  if (names.has('REELS')) {
    out.push('reels');
  }
  if (names.has('PHOTOS')) {
    out.push('images');
  }
  if (names.has('FRIENDS')) {
    if (/follow/i.test(names.get('FRIENDS') ?? '')) {
      out.push('followers');
    }
    else {
      out.push('friends');
    }
  }
  return out;
}

export function detailsOf(username: string, html: string): social_profile_details | null {
  const parsed = jsonBlocks(html);
  const header = parsed.flatMap((block: any) => collect(block, 'profile_header_renderer')).map((renderer: any) => renderer?.user).find((user: any) => user && typeof user === 'object' && user.name) ?? null;
  const socialTexts: string[] = parsed.flatMap((block: any) => collect(block, 'profile_social_context')).flatMap((context: any) => Array.isArray(context?.content) ? context.content : []).map((entry: any) => clean(entry?.text?.text)).filter(Boolean);
  const status = parsed.flatMap((block: any) => collect(block, 'profile_status_text')).map((entry: any) => clean(entry?.text)).find(Boolean) ?? '';
  const intro = parsed.flatMap((block: any) => collect(block, 'profile_intro_card')).flatMap((card: any) => Array.isArray(card?.context_items?.edges) ? card.context_items.edges : []).map((edge: any) => ({ type: String(edge?.node?.profile_field_type ?? '').toLowerCase(), text: clean(edge?.node?.short_title?.text) })).filter((entry: { text: string }) => entry.text);
  const introText = (type: string): string => intro.find((entry: { type: string }) => entry.type === type)?.text ?? '';
  const socialText = (label: string): string => socialTexts.find((text) => new RegExp(`\\b${label}\\b`, 'i').test(text)) ?? '';
  const title = decodeEntities(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
  const ogName = (metaOf(html, 'og:title') || title).replace(/\s*[|-]\s*Facebook$/i, '').trim();
  const name = clean(header?.name) || ogName;
  if (!name || /^(Facebook|Log in|Log into Facebook|Error)$/i.test(name)) {
    return null;
  }
  const ogDescription = metaOf(html, 'og:description') || metaOf(html, 'description');
  const strip = (text: string): string => text.replace(/^[\d.,]+[KMB]?\s*likes\s*·\s*[\d.,]+[KMB]?\s*(?:talking about this|were here|followers)\.?\s*/i, '').trim();
  const bio = status || strip(ogDescription);
  const likes = socialText('likes') || (/([\d.,]+[KMB]?)\s*likes/i.exec(ogDescription)?.[0] ?? '');
  const followers = socialText('followers') || (/([\d.,]+[KMB]?)\s*followers/i.exec(ogDescription)?.[0] ?? '');
  const profileId = String(header?.id ?? header?.delegate_page?.id ?? (/"userID"\s*:\s*"(\d+)"/.exec(html)?.[1] ?? /"pageID"\s*:\s*"(\d+)"/.exec(html)?.[1] ?? ''));
  const ownedPic = profileId ? parsed.flatMap((block: any) => [...collect(block, 'user'), ...collect(block, 'page'), ...collect(block, 'actor'), ...collect(block, 'owner')]).find((entity: any) => entity && String(entity.id ?? '') === profileId && (entity.profilePicLarge?.uri || entity.profile_picture?.uri || entity.profilePicMedium?.uri)) : null;
  const avatar = collect(header ?? {}, 'profilePicLarge').find((entry: any) => entry?.uri)?.uri ?? header?.profile_picture_for_sticky_bar?.uri ?? header?.profile_picture?.uri ?? ownedPic?.profilePicLarge?.uri ?? ownedPic?.profile_picture?.uri ?? ownedPic?.profilePicMedium?.uri ?? (metaOf(html, 'og:image') || parsed.flatMap((block: any) => collect(block, 'profilePicLarge')).find((entry: any) => entry?.uri)?.uri || '');
  const banner = parsed.flatMap((block: any) => collect(block, 'cover_photo')).find((entry: any) => entry?.photo?.image?.uri)?.photo?.image?.uri ?? '';
  const details = {
    real_name: name,
    bio,
    description: bio,
    location: introText('address') || introText('location') || introText('current_city'),
    profile_url: clean(header?.url) || profileBase(username),
    total_posts: '',
    total_followers: String(countOf(followers) || ''),
    total_likes: String(countOf(likes) || ''),
    avatar: String(avatar ?? ''),
    banner: String(banner ?? ''),
    crawl_type: sectionsOf(html),
    platform: 'facebook',
    username,
    userId: profileId,
    category: introText('category'),
    website: introText('website'),
    page_id: String(header?.delegate_page?.id ?? ''),
    is_verified: Boolean(header?.is_verified),
  };
  return details as social_profile_details;
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export function timelinePageInfo(node: any, context: string[] = [], out: { info: any; context: string }[] = []): any | null {
  if (Array.isArray(node)) {
    node.forEach((entry) => timelinePageInfo(entry, context, out));
  }
  else if (node && typeof node === 'object') {
    const local = [...context];
    if (Array.isArray(node.path)) {
      local.push(...node.path.map((part: unknown) => String(part)));
    }
    if (typeof node.label === 'string') {
      local.push(node.label);
    }
    for (const [name, value] of Object.entries(node)) {
      if (name === 'page_info' && value && typeof value === 'object' && 'has_next_page' in (value as object)) {
        out.push({ info: value, context: [...local, name].join('/') });
      }
      timelinePageInfo(value, [...local, name], out);
    }
  }
  if (context.length) {
    return null;
  }
  return out.find((entry) => /timeline_(list_)?feed_units/.test(entry.context))?.info
    ?? out.find((entry) => /(^|\/)data\/page_info$/.test(entry.context) && typeof entry.info?.end_cursor === 'string' && entry.info.end_cursor.length > 20)?.info
    ?? null;
}

export function decodeCursor(payload: CrawlPayload): Partial<TimelineCursor> {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return {};
  }
  try {
    const value = JSON.parse(raw);
    return value && typeof value === 'object' ? { c: String(value.c ?? ''), id: String(value.id ?? ''), d: String(value.d ?? '') } : { c: raw };
  }
  catch {
    return { c: raw };
  }
}

export function encodeCursor(state: TimelineCursor): string {
  return JSON.stringify(state);
}

export function jsonBlocks(html: string): any[] {
  const parsed: any[] = [];
  for (const match of html.matchAll(/<script type="application\/json"[^>]*>([\s\S]*?)<\/script>/g)) {
    try {
      parsed.push(JSON.parse(match[1]));
    }
    catch {
    }
  }
  return parsed;
}

export function jsonLines(text: string): any[] {
  const parsed: any[] = [];
  for (const line of text.replace(/^for \(;;\);/, '').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) {
      continue;
    }
    try {
      parsed.push(JSON.parse(trimmed));
    }
    catch {
    }
  }
  return parsed;
}

export function stories(parsed: any[]): any[] {
  const nested = parsed.flatMap((block: any) => collect(block, 'story')).filter((story: any) => story && (story.post_id || story.id));
  const edges = parsed.flatMap((block: any) => collect(block, 'node')).filter((node: any) => node && node.__typename === 'Story' && (node.post_id || node.id));
  const attached = new Set(parsed.flatMap((block: any) => collect(block, 'attached_story')).filter((story: any) => story && (story.post_id || story.id)).flatMap((story: any) => [String(story.post_id ?? ''), String(story.id ?? '')]).filter(Boolean));
  const merged = new Map<string, any>();
  [...nested, ...edges].forEach((story: any) => {
    const id = String(story.post_id ?? story.id);
    merged.set(id, { ...(merged.get(id) ?? {}), ...story });
  });
  return [...merged.values()].filter((story: any) => !attached.has(String(story.post_id ?? '')) && !attached.has(String(story.id ?? '')));
}

export function isStoryFragment(item: social_resource): boolean {
  return !item.caption && !item.datetime && !item.thumbnail_url && !item['image_url'] && !item['video_url'] && !Number(item['attachments_count']) && !item['link_url'];
}

export function tokensOf(html: string): Tokens {
  const dtsg = /"DTSGInitialData",\[\],\{"token":"([^"]+)"/.exec(html)?.[1] ?? /"fb_dtsg"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"/.exec(html)?.[1] ?? /name="fb_dtsg" value="([^"]+)"/.exec(html)?.[1] ?? '';
  const lsd = /"LSD",\[\],\{"token":"([^"]+)"/.exec(html)?.[1] ?? '';
  const user = /"USER_ID":"(\d+)"/.exec(html)?.[1] ?? /"ACCOUNT_ID":"(\d+)"/.exec(html)?.[1] ?? '0';
  const jazoest = `2${[...dtsg].reduce((sum, char) => sum + char.charCodeAt(0), 0)}`;
  return { dtsg, lsd, user, jazoest };
}

export function profileIdOf(parsed: any[], html: string): string {
  const owner = parsed.flatMap((block: any) => collect(block, 'user')).find((user: any) => user && typeof user === 'object' && user.timeline_list_feed_units && user.id)?.id;
  return String(owner ?? '') || (/"userID"\s*:\s*"(\d+)"/.exec(html)?.[1] ?? /"pageID"\s*:\s*"(\d+)"/.exec(html)?.[1] ?? /"entity_id"\s*:\s*"(\d+)"/.exec(html)?.[1] ?? /"profile_id"\s*:\s*"?(\d+)/.exec(html)?.[1] ?? '');
}

export function docIdOf(source: string, query: string = REFETCH_QUERY): string {
  return new RegExp(`${query}_facebookRelayOperation"[\\s\\S]{0,300}?exports\\s*=\\s*"(\\d+)"`).exec(source)?.[1] ?? '';
}

export function bundleUrls(html: string): string[] {
  return [...new Set([...html.replace(/\\\//g, '/').matchAll(/https:\/\/static\.xx\.fbcdn\.net\/rsrc\.php\/[^"'\s<>]+?\.js(?:\?[^"'\s<>]*)?/g)].map((match) => match[0]))];
}

export async function docIdFromBundles(tab: TabController, html: string, skip: string[] = [], query: string = REFETCH_QUERY): Promise<string> {
  const urls = bundleUrls(html).filter((url) => !skip.includes(url)).slice(0, MAX_BUNDLES);
  for (let index = 0; index < urls.length; index += 16) {
    const found = await Promise.all(urls.slice(index, index + 16).map(async (url) => {
      try {
        const response = await tab.fetch(url);
        return response.ok ? docIdOf(response.body, query) : '';
      }
      catch {
        return '';
      }
    }));
    const hit = found.find(Boolean);
    if (hit) {
      return hit;
    }
  }
  return '';
}

export async function profileHtml(tab: TabController, username: string, path: string = '', marker: RegExp = /timeline_(list_)?feed_units|"__typename":"Story"/): Promise<string> {
  const url = profileUrl(username, path);
  try {
    const landed = await tab.navigate(url);
    if (landed && !/\/login|checkpoint/i.test(landed)) {
      await new Promise((resolve) => setTimeout(resolve, 2500));
      const rendered = await tab.html();
      if (rendered && marker.test(rendered)) {
        return rendered;
      }
    }
    const response = await tab.fetch(url);
    return response.ok ? response.body : '';
  }
  catch {
    return '';
  }
}

export async function docIdAfterScroll(tab: TabController, html: string, query: string = REFETCH_QUERY): Promise<string> {
  const known = bundleUrls(html);
  await tab.scrollLoad(3);
  await new Promise((resolve) => setTimeout(resolve, 2000));
  const rendered = await tab.html();
  return rendered ? await docIdFromBundles(tab, rendered, known, query) : '';
}

export function variablesOf(html: string): Record<string, unknown> {
  const balanced = (source: string, start: number): string => {
    let depth = 0;
    for (let index = start; index < source.length; index += 1) {
      if (source[index] === '{') {
        depth += 1;
      }
      else if (source[index] === '}') {
        depth -= 1;
        if (!depth) {
          return source.slice(start, index + 1);
        }
      }
    }
    return '';
  };
  for (const match of html.matchAll(/ProfileCometTimelineFeedQueryRelayPreloader[^"]*"/g)) {
    const index = html.indexOf('"variables":{', match.index ?? 0);
    if (index > 0 && index - (match.index ?? 0) < 4000) {
      try {
        const parsed = JSON.parse(balanced(html, index + 12).replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
        if (parsed && typeof parsed === 'object') {
          return parsed;
        }
      }
      catch {
      }
    }
  }
  return { afterTime: null, beforeTime: null, feedLocation: 'TIMELINE', feedbackSource: 0, focusCommentID: null, memorializedSplitTimeFilter: null, omitPinnedPost: true, postedBy: null, privacy: null, privacySelectorRenderLocation: 'COMET_STREAM', renderLocation: 'timeline', scale: 1, stream_count: 1, taggedInOnly: null, trackingCode: null, useDefaultActor: false };
}

export async function graphql(tab: TabController, tokens: Tokens, query: string, docId: string, variables: Record<string, unknown>): Promise<any[] | null> {
  try {
    const body = new URLSearchParams({
      av: tokens.user,
      __user: tokens.user,
      __a: '1',
      __comet_req: '15',
      fb_dtsg: tokens.dtsg,
      jazoest: tokens.jazoest,
      lsd: tokens.lsd,
      fb_api_caller_class: 'RelayModern',
      fb_api_req_friendly_name: query,
      variables: JSON.stringify(variables),
      server_timestamps: 'true',
      doc_id: docId,
    });
    const response = await tab.fetch('https://www.facebook.com/api/graphql/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-FB-LSD': tokens.lsd, 'X-FB-Friendly-Name': query },
      body: body.toString(),
    });
    if (!response.ok) {
      return null;
    }
    const lines = jsonLines(response.body);
    return lines.length ? lines : null;
  }
  catch {
    return null;
  }
}

export function refetch(tab: TabController, tokens: Tokens, docId: string, profileId: string, cursor: string | null, count: number, base: Record<string, unknown>): Promise<any[] | null> {
  return graphql(tab, tokens, REFETCH_QUERY, docId, { ...base, count, cursor, id: profileId });
}

export function collectionOf(parsed: any[], spec: CollectionSpec): any | null {
  const renderers = parsed.flatMap((block: any) => collect(block, 'style_renderer')).filter((renderer: any) => renderer && renderer.__typename === spec.renderer && renderer.collection);
  const named = spec.name ? renderers.find((renderer: any) => String(renderer.collection.name ?? '').toLowerCase() === spec.name!.toLowerCase()) : null;
  return (named ?? renderers[0])?.collection ?? null;
}

export function connectionOf(node: any, spec: CollectionSpec): { edges: any[]; pageInfo: any | null } {
  const connection = node && typeof node === 'object' ? node[spec.connection] : null;
  return { edges: Array.isArray(connection?.edges) ? connection.edges : [], pageInfo: connection?.page_info && typeof connection.page_info === 'object' ? connection.page_info : null };
}

export function collectionNodes(edges: any[]): any[] {
  return edges.map((edge: any) => edge?.profile_reel_node?.node ?? edge?.node).filter((node: any) => node && typeof node === 'object');
}

export function duration(seconds: number): string {
  const total = Math.round(seconds);
  if (!Number.isFinite(total) || total <= 0) {
    return '';
  }
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const rest = total % 60;
  return hours ? `${hours}:${String(minutes).padStart(2, '0')}:${String(rest).padStart(2, '0')}` : `${minutes}:${String(rest).padStart(2, '0')}`;
}

export function toCollectionItem(kind: CollectionKind, username: string, node: any): social_resource {
  if (kind === 'reels') {
    return toReel(username, node);
  }
  if (kind === 'images') {
    return toPhoto(username, node);
  }
  return toPerson(username, kind, node);
}

export function toReel(username: string, story: any): social_resource {
  const media = story.attachments?.[0]?.media ?? story.video ?? {};
  const actor = (Array.isArray(story.actors) ? story.actors[0] : null) ?? media.owner ?? {};
  const message = clean(story.message?.text);
  const thumbnail = media.thumbnailImage?.uri ?? media.image?.uri ?? media.preferred_thumbnail?.image?.uri ?? media.first_frame_thumbnail ?? '';
  const seconds = Number(media.length_in_second) || Number(media.playable_duration_in_ms) / 1000 || 0;
  const ranges: any[] = Array.isArray(story.message?.ranges) ? story.message.ranges : [];
  return {
    type: 'reels',
    resource_id: String(media.id ?? story.post_id ?? story.id ?? ''),
    url: media.permalink_url ?? media.shareable_url ?? (media.id ? `https://www.facebook.com/reel/${media.id}/` : ''),
    parent_url: `${profileBase(username)}/reels_tab`,
    title: '',
    caption: message,
    author: actor.name ?? username,
    datetime: stamp(story.creation_time ?? media.created_time),
    media_type: 'reel',
    media_url: media.playable_url ?? media.browser_native_hd_url ?? media.browser_native_sd_url ?? thumbnail,
    thumbnail_url: thumbnail,
    likes: '',
    shares: '',
    views: clean(media.play_count_reduced ?? media.play_count ?? ''),
    post_id: story.post_id ?? '',
    video_id: media.id ?? '',
    duration_text: duration(seconds),
    duration_seconds: Math.round(seconds),
    width: media.width ?? 0,
    height: media.height ?? 0,
    aspect_ratio: media.aspect_ratio ?? 0,
    hashtags: ranges.map((range: any) => String(range?.entity?.url ?? '')).filter((url: string) => /\/hashtag\//.test(url)).map((url: string) => url.replace(/[?#].*$/, '').split('/').filter(Boolean).pop() ?? '').filter(Boolean),
    track_title: clean(media.track_title),
    actor_id: actor.id ?? '',
    actor_url: actor.url ?? '',
    privacy: story.privacy_scope?.description ?? '',
    feedback_id: story.feedback?.id ?? '',
  };
}

export function toPhoto(username: string, item: any): social_resource {
  const photo = item.node ?? {};
  const full = photo.viewer_image?.uri ?? item.image?.uri ?? '';
  const caption = clean(photo.accessibility_caption);
  return {
    type: 'images',
    resource_id: String(photo.id ?? item.id ?? ''),
    url: item.url ?? (photo.id ? `https://www.facebook.com/photo.php?fbid=${photo.id}` : ''),
    parent_url: `${profileBase(username)}/photos`,
    title: '',
    caption: /^no photo description/i.test(caption) ? '' : caption,
    author: username,
    datetime: stamp(photo.created_time),
    media_type: 'photo',
    media_url: full,
    thumbnail_url: item.image?.uri ?? full,
    likes: '',
    shares: '',
    views: '',
    photo_id: photo.id ?? '',
    width: photo.viewer_image?.width ?? 0,
    height: photo.viewer_image?.height ?? 0,
  };
}

export function toPerson(username: string, kind: 'followers' | 'friends', item: any): social_resource {
  const entity = item.node ?? {};
  const name = clean(item.title?.text);
  const url = String(item.url ?? entity.url ?? '');
  const handle = /profile\.php/.test(url) ? '' : url.replace(/[?#].*$/, '').replace(/\/+$/, '').split('/').pop() ?? '';
  return {
    type: kind,
    resource_id: String(entity.id ?? item.id ?? ''),
    url,
    parent_url: `${profileBase(username)}/${kind}`,
    title: name,
    caption: clean(item.subtitle_text?.text),
    author: name,
    datetime: '',
    media_type: String(entity.__typename ?? 'user').toLowerCase(),
    media_url: url,
    thumbnail_url: item.image_v2?.uri ?? item.image?.uri ?? '',
    likes: '',
    shares: '',
    views: '',
    username: handle,
    user_id: entity.id ?? '',
    is_verified: Boolean(entity.is_verified),
  };
}

export function toItem(username: string, story: any): social_resource {
  const id = String(story.post_id ?? story.id ?? '');
  const deep = (key: string): any[] => collect(story, key);
  const ownerId = String(story.owner?.id ?? story.comet_sections?.content?.story?.owner?.id ?? '');
  const actors: any[] = (Array.isArray(story.actors) ? story.actors : story.actors ? [story.actors] : []).filter((entry: any) => entry && entry.name);
  const actor = actors.find((entry: any) => ownerId && String(entry.id ?? '') === ownerId) ?? actors[0] ?? deep('actors').flat().find((entry: any) => entry && entry.name) ?? {};
  const message = story.message?.text ?? story.comet_sections?.content?.story?.message?.text ?? deep('message').find((entry: any) => entry && typeof entry.text === 'string' && entry.text)?.text ?? '';
  const attachments: any[] = Array.isArray(story.attachments) && story.attachments.length ? story.attachments : deep('attachments').find((entry: any) => Array.isArray(entry) && entry.length) ?? [];
  const media = attachments[0]?.media ?? attachments[0]?.styles?.attachment?.media ?? deep('media').find((entry: any) => entry && entry.__typename && (entry.image || entry.photo_image || entry.playable_url || entry.preferred_thumbnail)) ?? {};
  const feedback = story.feedback_context?.feedback_target_with_context ?? deep('feedback_target_with_context').find(Boolean) ?? {};
  const creationTime = story.creation_time ?? media.created_time ?? deep('creation_time').find((value: any) => Number(value) > 0);
  const reactionCount = feedback.reaction_count?.count ?? story.feedback?.reaction_count?.count ?? deep('reaction_count').find((entry: any) => entry && typeof entry.count === 'number')?.count ?? deep('i18n_reaction_count').find((value: any) => typeof value === 'string') ?? 0;
  const commentCount = feedback.comment_rendering_instance?.comments?.total_count ?? feedback.comment_count?.total_count ?? deep('comment_rendering_instance').map((entry: any) => entry?.comments?.total_count).find((value: any) => typeof value === 'number') ?? deep('total_comment_count').find((value: any) => typeof value === 'number') ?? 0;
  const shareCount = feedback.share_count?.count ?? deep('share_count').find((entry: any) => entry && typeof entry.count === 'number')?.count ?? 0;
  const authorAvatar = actor.profile_picture?.uri ?? actor.profilePicture?.uri ?? '';
  const permalink = story.wwwURL ?? story.permalink_url ?? story.url ?? deep('wwwURL').find((value: any) => typeof value === 'string' && value) ?? deep('permalink_url').find((value: any) => typeof value === 'string' && value) ?? deep('url').find((value: any) => typeof value === 'string' && /facebook\.com\/.*(\/posts\/|\/reel\/|\/videos\/|\/photos\/|story_fbid=)/.test(value)) ?? '';
  const thumbnail = media.preferred_thumbnail?.image?.uri ?? media.image?.uri ?? media.photo_image?.uri ?? deep('preferred_thumbnail').find((entry: any) => entry?.image?.uri)?.image?.uri ?? deep('photo_image').find((entry: any) => entry?.uri)?.uri ?? deep('image').find((entry: any) => entry && typeof entry.uri === 'string' && /fbcdn/.test(entry.uri) && entry.uri !== authorAvatar)?.uri ?? '';
  const videoUrl = media.playable_url ?? media.browser_native_hd_url ?? media.browser_native_sd_url ?? deep('playable_url').find((value: any) => typeof value === 'string' && value) ?? '';
  const imageUrl = media.photo_image?.uri ?? media.image?.uri ?? (videoUrl ? '' : thumbnail);
  const mediaType = media.__typename ? String(media.__typename).toLowerCase() : (videoUrl ? 'video' : thumbnail ? 'photo' : attachments.length ? 'attachment' : 'text');
  const reactionTotal = Number(reactionCount) || deep('top_reactions').flatMap((entry: any) => Array.isArray(entry?.edges) ? entry.edges : []).reduce((sum: number, edge: any) => sum + (Number(edge?.reaction_count) || 0), 0);
  return {
    type: 'posts',
    resource_id: id,
    url: permalink || (story.post_id ? `https://www.facebook.com/${username}/posts/${story.post_id}` : ''),
    parent_url: `https://www.facebook.com/${username}`,
    title: '',
    caption: clean(message),
    author: actor.name ?? username,
    author_avatar: authorAvatar,
    datetime: stamp(creationTime),
    media_type: mediaType,
    media_url: imageUrl || videoUrl || thumbnail,
    thumbnail_url: thumbnail,
    likes: String(reactionTotal || ''),
    shares: String(Number(shareCount) || ''),
    views: String((media.video_view_count ?? 0) || ''),
    post_id: story.post_id ?? '',
    story_id: story.id ?? '',
    message: clean(message),
    message_length: clean(message).length,
    creation_time: stamp(creationTime),
    attachments_count: attachments.length,
    attachment_types: [...new Set(attachments.map((entry: any) => entry?.media?.__typename ?? entry?.styles?.__typename ?? '').filter(Boolean))].join(', '),
    attachment_urls: attachments.map((entry: any) => entry?.url ?? entry?.media?.photo_image?.uri ?? '').filter(Boolean).join(', '),
    media_id: media.id ?? '',
    media_type_name: media.__typename ?? '',
    image_url: imageUrl,
    image_width: media.photo_image?.width ?? media.image?.width ?? 0,
    image_height: media.photo_image?.height ?? media.image?.height ?? 0,
    video_url: videoUrl,
    is_video: !!videoUrl || /video|reel/.test(mediaType),
    video_duration: media.playable_duration_in_ms ?? 0,
    video_views: media.video_view_count ?? 0,
    link_url: attachments[0]?.url ?? '',
    link_title: clean(attachments[0]?.title_with_entities?.text),
    link_description: clean(attachments[0]?.description?.text),
    reaction_count: reactionTotal || 0,
    comment_count: Number(commentCount) || 0,
    share_count: Number(shareCount) || 0,
    actor_id: actor.id ?? '',
    actor_name: actor.name ?? '',
    actor_url: actor.url ?? '',
    actor_avatar: authorAvatar,
    actor_is_verified: actor.is_verified ?? false,
    privacy: story.privacy_scope?.description ?? '',
    feedback_id: story.feedback?.id ?? '',
  };
}

export function balancedObject(source: string, start: number): string {
  let depth = 0;
  for (let index = start; index < source.length; index += 1) {
    if (source[index] === '{') {
      depth += 1;
    }
    else if (source[index] === '}') {
      depth -= 1;
      if (!depth) {
        return source.slice(start, index + 1);
      }
    }
  }
  return '';
}

export function feedVariablesOf(html: string): Record<string, unknown> {
  for (const match of html.matchAll(/CometModernHomeFeedQuery[^"]*"/g)) {
    const index = html.indexOf('"variables":{', match.index ?? 0);
    if (index > 0 && index - (match.index ?? 0) < 6000) {
      try {
        const parsed = JSON.parse(balancedObject(html, index + 12).replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
        if (parsed && typeof parsed === 'object') {
          return parsed as Record<string, unknown>;
        }
      }
      catch {
      }
    }
  }
  return { feedLocation: 'NEWSFEED', feedStyle: 'CANONICAL', scale: 1, renderLocation: 'homepage_stream', useDefaultActor: false };
}

function isFeedCursor(cursor: string): boolean {
  try {
    return /^\d+:\d+:\d{9,}:/.test(atob(cursor));
  }
  catch {
    return false;
  }
}

export function feedCursorOf(html: string): string {
  const cursors = [...html.matchAll(/"end_cursor":"([^"]+)"/g)].map((match) => match[1]);
  return cursors.find((cursor) => isFeedCursor(cursor)) ?? cursors[0] ?? '';
}

export function feedPageInfo(parsed: any[]): { end_cursor: string; has_next_page: boolean } | null {
  const infos = collect(parsed, 'page_info').filter((info: any) => info && typeof info === 'object' && 'has_next_page' in info);
  const feedInfo = infos.find((info: any) => typeof info.end_cursor === 'string' && isFeedCursor(info.end_cursor));
  const info = feedInfo ?? infos.find((entry: any) => typeof entry.end_cursor === 'string' && entry.end_cursor.length > 20);
  return info ? { end_cursor: String(info.end_cursor ?? ''), has_next_page: Boolean(info.has_next_page) } : null;
}

export function countStories(parsed: any[]): number {
  return collect(parsed, '__typename').filter((value: any) => value === 'Story').length;
}

function hasSponsored(node: any): boolean {
  return collect(node, '__typename').includes('SponsoredData') || collect(node, 'ad_id').some((value: any) => Boolean(value));
}

export function sponsoredStories(parsed: any[]): any[] {
  const out: any[] = [];
  const visit = (node: any): void => {
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (!node || typeof node !== 'object') {
      return;
    }
    const looksStory = ('comet_sections' in node) || ('actors' in node) || node.__typename === 'Story';
    if (looksStory && hasSponsored(node)) {
      out.push(node);
    }
    for (const value of Object.values(node)) {
      visit(value);
    }
  };
  parsed.forEach(visit);
  return out;
}

export function feedbackIdOf(html: string): string {
  const ids = [...html.matchAll(/"feedback":\{"id":"([^"]+)"/g)].map((match) => match[1]);
  return ids.find((id) => {
    try {
      return /^feedback:\d+$/.test(atob(id));
    }
    catch {
      return false;
    }
  }) ?? ids[0] ?? '';
}

export function commentProviderFlags(html: string): Record<string, boolean> {
  const flags: Record<string, boolean> = {};
  for (const match of html.matchAll(/"(__relay_internal__pv__[A-Za-z0-9]+)":(true|false)/g)) {
    flags[match[1]] = match[2] === 'true';
  }
  return flags;
}

export function commentAuthors(parsed: any[]): { id: string; name: string; url: string; avatar: string; text: string; reactions: string }[] {
  const nodes: any[] = [];
  const visit = (node: any): void => {
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (!node || typeof node !== 'object') {
      return;
    }
    if (node.__typename === 'Comment' && node.author && (node.depth === 0 || node.depth === undefined)) {
      nodes.push(node);
    }
    for (const value of Object.values(node)) {
      visit(value);
    }
  };
  parsed.forEach(visit);
  return nodes.map((comment: any) => {
    const author = comment.author ?? {};
    return {
      id: String(author.id ?? ''),
      name: clean(author.name ?? ''),
      url: String(author.url ?? ''),
      avatar: String(author.profile_picture_depth_0?.uri ?? author.profile_picture?.uri ?? ''),
      text: clean(comment.body?.text ?? ''),
      reactions: String(comment.feedback?.reactors?.count_reduced ?? comment.feedback?.reaction_count?.count ?? ''),
    };
  }).filter((entry) => entry.id && entry.name);
}

export function reelCommentSeed(parsed: any[]): { feedbackId: string; cursor: string } {
  let feedbackId = '';
  let cursor = '';
  const visit = (node: any): void => {
    if (feedbackId || !node) {
      return;
    }
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (typeof node !== 'object') {
      return;
    }
    if (node.comment_rendering_instance_for_feed_location && typeof node.id === 'string') {
      feedbackId = node.id;
      cursor = String(node.comment_rendering_instance_for_feed_location.comments?.page_info?.end_cursor ?? '');
      return;
    }
    for (const value of Object.values(node)) {
      visit(value);
    }
  };
  parsed.forEach(visit);
  return { feedbackId, cursor };
}

export function commentCursor(parsed: any[]): { next: string; has_next_page: boolean } {
  let best: { info: any; edges: number } | null = null;
  const visit = (node: any): void => {
    if (Array.isArray(node)) {
      node.forEach(visit);
      return;
    }
    if (!node || typeof node !== 'object') {
      return;
    }
    const info = node.page_info;
    if (info && typeof info === 'object' && 'has_next_page' in info && Array.isArray(node.edges) && node.edges.length > 0) {
      if (!best || node.edges.length > best.edges) {
        best = { info, edges: node.edges.length };
      }
    }
    for (const value of Object.values(node)) {
      visit(value);
    }
  };
  parsed.forEach(visit);
  const info = (best as { info: any } | null)?.info;
  return info ? { next: String(info.end_cursor ?? ''), has_next_page: Boolean(info.has_next_page) } : { next: '', has_next_page: false };
}

export function toAd(story: any): social_resource {
  const deep = (key: string): any[] => collect(story, key);
  const adId = String(deep('ad_id').find(Boolean) ?? '');
  const advertiserId = String(deep('lbl_adv_iden').find(Boolean) ?? '');
  const actor = deep('actors').flat().find((entry: any) => entry && entry.name) ?? {};
  const name = actor.name ?? deep('name').find((value: any) => typeof value === 'string' && value) ?? '';
  const message = clean(deep('message').find((entry: any) => entry && typeof entry.text === 'string' && entry.text)?.text ?? '');
  const attachments: any[] = deep('attachments').find((entry: any) => Array.isArray(entry) && entry.length) ?? [];
  const media = attachments[0]?.media ?? attachments[0]?.styles?.attachment?.media ?? deep('media').find((entry: any) => entry && (entry.image || entry.photo_image || entry.playable_url || entry.preferred_thumbnail)) ?? {};
  const image = media.photo_image?.uri ?? media.image?.uri ?? deep('photo_image').find((entry: any) => entry?.uri)?.uri ?? '';
  const video = media.playable_url ?? media.browser_native_hd_url ?? media.browser_native_sd_url ?? deep('playable_url').find((value: any) => typeof value === 'string' && value) ?? '';
  const permalink = deep('wwwURL').find((value: any) => typeof value === 'string' && value) ?? deep('url').find((value: any) => typeof value === 'string' && /facebook\.com\/(permalink|reel|watch|[^/]+\/(posts|videos|photos))/.test(value)) ?? '';
  const destination = attachments[0]?.url ?? deep('url').find((value: any) => typeof value === 'string' && /^https?:/.test(value) && !/facebook\.com\/(login|privacy|help|policies|ads\/about)/.test(value)) ?? '';
  const cta = clean(attachments[0]?.style_infos?.[0]?.__typename ?? deep('cta_type').find(Boolean) ?? '');
  const clientToken = String(deep('client_token').find(Boolean) ?? '');
  const creation = deep('creation_time').find((value: any) => Number(value) > 0);
  const feedback = deep('feedback_target_with_context').find(Boolean) ?? {};
  const reactions = feedback.reaction_count?.count ?? deep('reaction_count').find((entry: any) => entry && typeof entry.count === 'number')?.count ?? 0;
  const comments = feedback.comment_rendering_instance?.comments?.total_count ?? deep('total_comment_count').find((value: any) => typeof value === 'number') ?? 0;
  const shares = feedback.share_count?.count ?? deep('share_count').find((entry: any) => entry && typeof entry.count === 'number')?.count ?? 0;
  const linkTitle = clean(attachments[0]?.title_with_entities?.text ?? deep('title_with_entities').find((entry: any) => entry && entry.text)?.text ?? '');
  const linkDesc = clean(attachments[0]?.description?.text ?? '');
  const linkCaption = clean(attachments[0]?.source?.text ?? '');
  return {
    type: 'advertisements',
    resource_id: adId || String(permalink),
    url: String(permalink || destination),
    parent_url: 'https://www.facebook.com/',
    title: linkTitle,
    caption: message,
    author: clean(name),
    datetime: stamp(creation),
    media_type: video ? 'video' : image ? 'photo' : (attachments.length ? 'attachment' : 'text'),
    media_url: image || video,
    thumbnail_url: image,
    likes: String(Number(reactions) || ''),
    shares: String(Number(shares) || ''),
    views: '',
    ad_id: adId,
    advertiser: clean(name),
    advertiser_id: advertiserId,
    cta_type: cta,
    destination_url: destination,
    permalink: String(permalink),
    image_url: image,
    video_url: video,
    link_title: linkTitle,
    link_description: linkDesc,
    link_caption: linkCaption,
    message,
    reaction_count: Number(reactions) || 0,
    comment_count: Number(comments) || 0,
    share_count: Number(shares) || 0,
    client_token: clientToken,
  };
}
