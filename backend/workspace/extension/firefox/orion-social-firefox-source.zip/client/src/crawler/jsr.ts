import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { repositories, scopeTotal } from './resource/jsr/jsr';

export class Jsr implements Crawler {
  readonly platform = 'jsr';
  readonly base = 'https://jsr.io';
  readonly loginUrl = 'https://jsr.io/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const scope = String(payload.username ?? '').replace(/^@/, '').trim();
    if (!scope) {
      return [];
    }

    try {
      const count = await scopeTotal(scope);
      if (!count) {
        return [];
      }

      return [{
        real_name: `@${scope}`,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://jsr.io/@${scope}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: scope,
        package_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://jsr.io/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
