import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, FILL_PAGES, HEADERS, MAX_FIRST } from './constant';
import { Cursor, Owner, Timeline } from './model';
import { clean, continuation, feed, firstPage, fromFeedItem, graphql, media, nextPage, nodesOf, ownerOf, page, parseCursor, profile, stamp, timeline, userOf } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return page(username, 'posts', await timeline(tab, payload, username, () => true));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return page(username, 'images', await timeline(tab, payload, username, (node: any) => !node.is_video));
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.instagram.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await timeline(tab, payload, username, (node: any) => Boolean(node?.is_video));
    const seen = new Set(result.nodes.map((node: any) => String(node.id)));
    result.nodes.push(...nodesOf(result.user?.edge_felix_video_timeline).filter((node: any) => node?.is_video && !seen.has(String(node.id))));
    return page(username, 'videos', result);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
