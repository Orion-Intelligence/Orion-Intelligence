import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

export async function profile(username: string): Promise<any> {
  const response = await fetch(`https://api.discogs.com/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  return data && data.username ? data : null;
}

export async function details(username: string): Promise<social_profile_details[]> {
  const user = await profile(username);
  if (!user) {
    return [];
  }

  return [{
    real_name: clean(user.name) || user.username,
    bio: clean(user.profile),
    description: clean(user.profile),
    location: clean(user.location),
    profile_url: user.uri ?? `https://www.discogs.com/user/${username}`,
    total_posts: String((user.num_collection ?? 0) || ''),
    total_followers: '',
    total_likes: String((user.num_wantlist ?? 0) || ''),
    avatar: user.avatar_url ?? '',
    banner: user.banner_url ?? '',
    crawl_type: ['details', 'albums'],
    platform: 'discogs',
    username: user.username,
    collection_count: user.num_collection ?? 0,
    wantlist_count: user.num_wantlist ?? 0,
    lists_count: user.num_lists ?? 0,
    registered: user.registered ?? '',
    home_page: user.home_page ?? '',
  }];
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const limit = limitOf(payload, 50, 100);
    const response = await fetch(`https://api.discogs.com/users/${encodeURIComponent(username)}/collection/folders/0/releases?page=${page}&per_page=${limit}&sort=added&sort_order=desc`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }
    const data = await response.json();
    const releases: any[] = Array.isArray(data?.releases) ? data.releases : [];
    if (!releases.length) {
      return EMPTY;
    }
    const pages = Number(data?.pagination?.pages ?? 1);

    const items = releases.map((release: any): social_resource => {
      const info = release.basic_information ?? {};
      const id = String(info.id ?? release.id ?? '');
      const artists = Array.isArray(info.artists) ? info.artists.map((artist: any) => clean(artist?.name)).filter(Boolean) : [];
      const labels = Array.isArray(info.labels) ? info.labels.map((label: any) => clean(label?.name)).filter(Boolean) : [];
      const formats = Array.isArray(info.formats) ? info.formats.map((format: any) => clean(format?.name)).filter(Boolean) : [];
      const genres = Array.isArray(info.genres) ? info.genres : [];
      const styles = Array.isArray(info.styles) ? info.styles : [];
      return {
        type: 'albums',
        resource_id: id,
        url: id ? `https://www.discogs.com/release/${id}` : '',
        parent_url: `https://www.discogs.com/user/${username}/collection`,
        title: clean(info.title),
        caption: artists.join(', '),
        author: artists.join(', ') || username,
        datetime: release.date_added ?? '',
        media_type: 'release',
        media_url: '',
        thumbnail_url: info.cover_image ?? info.thumb ?? '',
        likes: '',
        shares: '',
        views: '',
        name: clean(info.title),
        artists: artists.join(', '),
        labels: labels.join(', '),
        formats: formats.join(', '),
        genres: genres.join(', '),
        styles: styles.join(', '),
        year: info.year ?? '',
        rating: release.rating ?? 0,
        date_added: release.date_added ?? '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && page < pages ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
