import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

function host(username: string): string {
  const trimmed = username.replace(/^https?:\/\//, '').replace(/\/+$/, '').trim();
  return trimmed.includes('.') ? trimmed : `${trimmed}.blogspot.com`;
}

function startOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function feed(username: string, start: number, limit: number): Promise<any> {
  const response = await fetch(`https://${host(username)}/feeds/posts/default?alt=json&max-results=${limit}&start-index=${start}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

function altLink(entry: any): string {
  const links = Array.isArray(entry?.link) ? entry.link : [];
  return links.find((link: any) => link?.rel === 'alternate')?.href ?? '';
}

export async function details(username: string): Promise<social_profile_details[]> {
  const data = await feed(username, 1, 1);
  const blog = data?.feed;
  if (!blog) {
    return [];
  }

  const total = Number(blog['openSearch$totalResults']?.$t ?? 0);
  const authors = Array.isArray(blog.author) ? blog.author.map((author: any) => author?.name?.$t).filter(Boolean) : [];
  return [{
    real_name: clean(blog.title?.$t) || host(username),
    bio: clean(blog.subtitle?.$t),
    description: clean(blog.subtitle?.$t),
    location: '',
    profile_url: `https://${host(username)}/`,
    total_posts: String(total || ''),
    total_followers: '',
    total_likes: '',
    avatar: '',
    banner: '',
    crawl_type: ['details', 'posts'],
    platform: 'blogger',
    username: host(username),
    posts_count: total,
    blog_authors: authors.join(', '),
  }];
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const start = startOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await feed(username, start, limit);
    const blog = data?.feed;
    const rows: any[] = Array.isArray(blog?.entry) ? blog.entry : [];
    if (!rows.length) {
      return EMPTY;
    }
    const total = Number(blog['openSearch$totalResults']?.$t ?? 0);

    const items = rows.map((entry: any): social_resource => {
      const url = altLink(entry);
      const categories = Array.isArray(entry.category) ? entry.category.map((category: any) => category?.term).filter(Boolean) : [];
      const authors = Array.isArray(entry.author) ? entry.author.map((author: any) => author?.name?.$t).filter(Boolean) : [];
      const thumb = entry['media$thumbnail']?.url ?? '';
      const body = clean(entry.content?.$t ?? entry.summary?.$t);
      return {
        type: 'posts',
        resource_id: entry.id?.$t ?? url,
        url,
        parent_url: `https://${host(username)}/`,
        title: clean(entry.title?.$t) || 'Untitled',
        caption: body.slice(0, 300),
        author: authors.join(', '),
        datetime: entry.published?.$t ?? '',
        media_type: 'post',
        media_url: '',
        thumbnail_url: thumb,
        likes: '',
        shares: '',
        views: String((entry['thr$total']?.$t ?? '') || ''),
        content: body,
        categories: categories.join(', '),
        published: entry.published?.$t ?? '',
        updated: entry.updated?.$t ?? '',
        comments: entry['thr$total']?.$t ?? '',
      };
    }).filter((item) => item.url);

    const next = start + rows.length;
    return { items, next_cursor: items.length && (total ? next <= total : rows.length >= limit) ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
