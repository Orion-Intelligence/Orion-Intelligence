import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };
const HOST = 'https://lemmy.world';

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function userData(username: string, page: number, limit: number): Promise<any> {
  const response = await fetch(`${HOST}/api/v3/user?username=${encodeURIComponent(username)}&page=${page}&limit=${limit}&sort=New`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function details(username: string): Promise<social_profile_details[]> {
  const data = await userData(username, 1, 1);
  const view = data?.person_view;
  if (!view?.person) {
    return [];
  }

  const person = view.person;
  const counts = view.counts ?? {};
  return [{
    real_name: clean(person.display_name) || person.name,
    bio: clean(person.bio),
    description: clean(person.bio),
    location: '',
    profile_url: person.actor_id ?? `${HOST}/u/${username}`,
    total_posts: String((counts.post_count ?? 0) || ''),
    total_followers: '',
    total_likes: '',
    avatar: person.avatar ?? '',
    banner: person.banner ?? '',
    crawl_type: ['details', 'posts', 'comments'],
    platform: 'lemmy',
    username: person.name ?? username,
    post_count: counts.post_count ?? 0,
    comment_count: counts.comment_count ?? 0,
    matrix_user_id: person.matrix_user_id ?? '',
    bot_account: Boolean(person.bot_account),
    account_created: person.published ?? '',
  }];
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await userData(username, page, limit);
    const rows: any[] = Array.isArray(data?.posts) ? data.posts : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((view: any): social_resource => {
      const post = view.post ?? {};
      const counts = view.counts ?? {};
      const community = view.community ?? {};
      return {
        type: 'posts',
        resource_id: String(post.id ?? ''),
        url: post.ap_id ?? `${HOST}/post/${post.id ?? ''}`,
        parent_url: `${HOST}/u/${username}`,
        title: clean(post.name),
        caption: clean(post.body),
        author: username,
        datetime: post.published ?? '',
        media_type: 'post',
        media_url: post.url ?? '',
        thumbnail_url: post.thumbnail_url ?? '',
        likes: String((counts.score ?? 0) || ''),
        shares: '',
        views: String((counts.comments ?? 0) || ''),
        content: clean(post.body),
        community: clean(community.title) || community.name || '',
        link_url: post.url ?? '',
        score: counts.score ?? 0,
        upvotes: counts.upvotes ?? 0,
        downvotes: counts.downvotes ?? 0,
        comments_count: counts.comments ?? 0,
        nsfw: Boolean(post.nsfw),
        published: post.published ?? '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && rows.length >= limit ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await userData(username, page, limit);
    const rows: any[] = Array.isArray(data?.comments) ? data.comments : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((view: any): social_resource => {
      const comment = view.comment ?? {};
      const counts = view.counts ?? {};
      const post = view.post ?? {};
      const community = view.community ?? {};
      return {
        type: 'comments',
        resource_id: String(comment.id ?? ''),
        url: comment.ap_id ?? `${HOST}/comment/${comment.id ?? ''}`,
        parent_url: `${HOST}/u/${username}`,
        title: clean(post.name),
        caption: clean(comment.content),
        author: username,
        datetime: comment.published ?? '',
        media_type: 'comment',
        media_url: '',
        thumbnail_url: '',
        likes: String((counts.score ?? 0) || ''),
        shares: '',
        views: '',
        content: clean(comment.content),
        on_post: clean(post.name),
        community: clean(community.title) || community.name || '',
        score: counts.score ?? 0,
        published: comment.published ?? '',
      };
    }).filter((item) => item.url);

    return { items, next_cursor: items.length && rows.length >= limit ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
