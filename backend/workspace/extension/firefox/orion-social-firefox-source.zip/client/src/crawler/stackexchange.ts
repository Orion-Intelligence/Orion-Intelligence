import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, comments, connections, posts } from './resource/stackexchange/stackexchange';

export class StackExchange implements Crawler {
  readonly platform = 'stackexchange';
  readonly base = 'https://stackexchange.com';
  readonly loginUrl = 'https://stackexchange.com/users/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.stackexchange.com/2.3/users/${username}/associated`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const sites: any[] = Array.isArray(payload?.items) ? payload.items : [];
      if (!sites.length) {
        return [];
      }

      const primary = sites.reduce((best, site) => ((site.reputation ?? 0) > (best.reputation ?? 0) ? site : best), sites[0]);
      const ranked = [...sites].sort((a, b) => (b.reputation ?? 0) - (a.reputation ?? 0));
      return [{
        real_name: primary.site_name ?? '',
        bio: '',
        description: '',
        location: '',
        profile_url: `https://stackexchange.com/users/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'answers', 'posts', 'comments', 'connections'],
        platform: this.platform,
        username: String(username),
        account_id: primary.account_id ?? 0,
        sites: sites.length,
        site_names: ranked.map((s: any) => s.site_name ?? '').filter(Boolean).join(', '),
        total_reputation: sites.reduce((sum, site) => sum + (site.reputation ?? 0), 0),
        primary_site: primary.site_name ?? '',
        primary_site_url: primary.site_url ?? '',
        primary_reputation: primary.reputation ?? 0,
        primary_user_id: primary.user_id ?? 0,
        primary_gold: primary.badge_counts?.gold ?? 0,
        primary_silver: primary.badge_counts?.silver ?? 0,
        primary_bronze: primary.badge_counts?.bronze ?? 0,
        answers: sites.reduce((sum, site) => sum + (site.answer_count ?? 0), 0),
        questions: sites.reduce((sum, site) => sum + (site.question_count ?? 0), 0),
        gold_badges: sites.reduce((sum, site) => sum + (site.badge_counts?.gold ?? 0), 0),
        silver_badges: sites.reduce((sum, site) => sum + (site.badge_counts?.silver ?? 0), 0),
        bronze_badges: sites.reduce((sum, site) => sum + (site.badge_counts?.bronze ?? 0), 0),
        last_access_at: primary.last_access_date ? new Date(primary.last_access_date * 1000).toISOString() : '',
        created_at: primary.creation_date ? new Date(primary.creation_date * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://stackexchange.com/users/current', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return /\/users\/\d+\//.test(response.url);
    }
    catch {
      return false;
    }
  }
}
