import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { ApiPage, Cursor } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://gitlab.com/api/v4${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function cursorOf(payload: CrawlPayload): Cursor {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return { page: 1, id: 0 };
  }

  try {
    const parsed = JSON.parse(raw);
    const page = Math.floor(Number(parsed?.page));
    const id = Math.floor(Number(parsed?.id));
    return { page: Number.isFinite(page) && page > 0 ? page : 1, id: Number.isFinite(id) && id > 0 ? id : 0 };
  }
  catch {
    return { page: 1, id: 0 };
  }
}

export async function userId(tab: TabController, username: string, cursor: Cursor): Promise<number> {
  if (cursor.id) {
    return cursor.id;
  }

  const list = await api(tab, `/users?username=${encodeURIComponent(username)}`);
  return Number((Array.isArray(list) ? list[0]?.id : 0) ?? 0);
}

export async function apiPage(tab: TabController, path: string, payload: CrawlPayload, cursor: Cursor, id: number): Promise<ApiPage> {
  const perPage = limitOf(payload, 25, 100);
  const separator = path.includes('?') ? '&' : '?';
  try {
    const response = await tab.fetch(`https://gitlab.com/api/v4${path}${separator}per_page=${perPage}&page=${cursor.page}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return { list: [] };
    }

    const body = JSON.parse(response.body);
    const list = (Array.isArray(body) ? body : []) as any[];
    const nextPage = list.length >= perPage ? cursor.page + 1 : 0;

    return { list, next: nextPage ? JSON.stringify({ page: nextPage, id } as Cursor) : undefined };
  }
  catch {
    return { list: [] };
  }
}

export function page(items: social_resource[], data: ApiPage): CrawlPage {
  return { items, next_cursor: items.length && data.next ? data.next : undefined };
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function project(username: string, type: 'repositories' | 'projects', data: any): social_resource {
  const namespace = data.namespace ?? {};
  const links = data._links ?? {};
  const statistics = data.statistics ?? {};
  const owner = data.owner ?? {};
  return {
    type,
    resource_id: String(data.id ?? ''),
    url: data.web_url ?? '',
    parent_url: `https://gitlab.com/${username}`,
    title: data.name ?? '',
    caption: clean(data.description),
    author: namespace.path ?? owner.username ?? username,
    datetime: data.last_activity_at ?? data.created_at ?? '',
    media_type: 'repository',
    media_url: data.http_url_to_repo ?? '',
    thumbnail_url: data.avatar_url ?? namespace.avatar_url ?? '',
    likes: String((data.star_count ?? 0) || ''),
    shares: String((data.forks_count ?? 0) || ''),
    views: '',
    project_id: data.id ?? 0,
    name: data.name ?? '',
    name_with_namespace: data.name_with_namespace ?? '',
    path: data.path ?? '',
    path_with_namespace: data.path_with_namespace ?? '',
    description: clean(data.description),
    default_branch: data.default_branch ?? '',
    visibility: data.visibility ?? '',
    star_count: data.star_count ?? 0,
    forks_count: data.forks_count ?? 0,
    open_issues_count: data.open_issues_count ?? 0,
    topics: Array.isArray(data.topics) ? data.topics.join(', ') : '',
    tag_list: Array.isArray(data.tag_list) ? data.tag_list.join(', ') : '',
    ssh_url: data.ssh_url_to_repo ?? '',
    http_url: data.http_url_to_repo ?? '',
    web_url: data.web_url ?? '',
    readme_url: data.readme_url ?? '',
    avatar_url: data.avatar_url ?? '',
    archived: data.archived ?? false,
    empty_repo: data.empty_repo ?? false,
    is_fork: Boolean(data.forked_from_project),
    forked_from: data.forked_from_project?.path_with_namespace ?? '',
    namespace_id: namespace.id ?? 0,
    namespace_name: namespace.name ?? '',
    namespace_path: namespace.path ?? '',
    namespace_kind: namespace.kind ?? '',
    namespace_full_path: namespace.full_path ?? '',
    namespace_web_url: namespace.web_url ?? '',
    owner_id: owner.id ?? 0,
    owner_username: owner.username ?? '',
    owner_name: owner.name ?? '',
    owner_web_url: owner.web_url ?? '',
    issues_enabled: data.issues_enabled ?? false,
    merge_requests_enabled: data.merge_requests_enabled ?? false,
    wiki_enabled: data.wiki_enabled ?? false,
    jobs_enabled: data.jobs_enabled ?? false,
    snippets_enabled: data.snippets_enabled ?? false,
    container_registry_enabled: data.container_registry_enabled ?? false,
    lfs_enabled: data.lfs_enabled ?? false,
    request_access_enabled: data.request_access_enabled ?? false,
    can_create_merge_request_in: data.can_create_merge_request_in ?? false,
    issues_access_level: data.issues_access_level ?? '',
    repository_access_level: data.repository_access_level ?? '',
    merge_requests_access_level: data.merge_requests_access_level ?? '',
    wiki_access_level: data.wiki_access_level ?? '',
    pages_access_level: data.pages_access_level ?? '',
    analytics_access_level: data.analytics_access_level ?? '',
    merge_method: data.merge_method ?? '',
    squash_option: data.squash_option ?? '',
    license_key: data.license?.key ?? '',
    license_name: data.license?.name ?? '',
    license_url: data.license_url ?? '',
    repository_size: statistics.repository_size ?? 0,
    storage_size: statistics.storage_size ?? 0,
    lfs_objects_size: statistics.lfs_objects_size ?? 0,
    commit_count: statistics.commit_count ?? 0,
    job_artifacts_size: statistics.job_artifacts_size ?? 0,
    api_url: links.self ?? '',
    issues_api: links.issues ?? '',
    merge_requests_api: links.merge_requests ?? '',
    members_api: links.members ?? '',
    created_at: data.created_at ?? '',
    updated_at: data.updated_at ?? '',
    last_activity_at: data.last_activity_at ?? '',
  };
}
