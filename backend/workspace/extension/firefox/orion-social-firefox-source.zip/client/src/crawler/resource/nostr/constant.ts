import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const RELAYS = ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.nostr.band', 'wss://relay.primal.net', 'wss://relay.snort.social', 'wss://nostr.wine'];
export const RELAY_TIMEOUT_MS = 6000;
export const MAX_SKIP = 200;
export const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
