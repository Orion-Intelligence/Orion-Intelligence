import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts } from './resource/microblog/microblog';

export class MicroBlog implements Crawler {
  readonly platform = 'microblog';
  readonly base = 'https://micro.blog';
  readonly loginUrl = 'https://micro.blog/account/sign-in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://micro.blog/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');

      const handle = title.replace(/^Micro\.blog\s*-\s*/i, '').replace(/^@/, '').trim();
      const heading = decode(/class="[^"]*profile_name[^"]*"[^>]*>([\s\S]*?)<\/(?:h1|h2|h3|span|div)>/i.exec(html)?.[1] ?? '') || meta('og:title').replace(/^Micro\.blog\s*-\s*/i, '');
      if (!handle) {
        return [];
      }

      return [{
        real_name: heading || handle,
        bio: meta('og:description') || decode(/class="profile_bio"[^>]*>([\s\S]*?)<\/(?:p|div)>/i.exec(html)?.[1] ?? ''),
        description: meta('og:description') || decode(/class="profile_bio"[^>]*>([\s\S]*?)<\/(?:p|div)>/i.exec(html)?.[1] ?? ''),
        location: '',
        profile_url: `https://micro.blog/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image') || (/<img[^>]+class="[^"]*avatar[^"]*"[^>]+src="([^"]+)"/i.exec(html)?.[1] ?? ''),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: handle || username,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://micro.blog/account', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/account\/sign-in|\/signin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
