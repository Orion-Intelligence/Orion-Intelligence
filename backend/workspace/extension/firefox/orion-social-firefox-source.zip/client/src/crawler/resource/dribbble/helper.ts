export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function pageOf(cursor: unknown): number {
  const parsed = Number.parseInt(String(cursor ?? '').trim(), 10);
  return Number.isFinite(parsed) && parsed > 1 ? parsed : 1;
}

export function blockEnd(html: string, begin: number, next: number | undefined): number {
  const cap = Math.min(html.length, begin + 20000);
  if (next !== undefined) {
    return Math.min(next, cap);
  }
  const actions = html.indexOf('</ul>', begin);
  const close = actions >= 0 ? html.indexOf('</li>', actions) : -1;
  return close >= 0 ? Math.min(close + 5, cap) : cap;
}

export function widest(srcset: string): string {
  let best = '';
  let width = 0;
  for (const entry of srcset.split(',')) {
    const parts = entry.trim().split(/\s+/);
    const size = Number(/(\d+)w/.exec(parts[1] ?? '')?.[1] ?? 0);
    if (parts[0] && size >= width) {
      width = size;
      best = decode(parts[0]);
    }
  }
  return best;
}
