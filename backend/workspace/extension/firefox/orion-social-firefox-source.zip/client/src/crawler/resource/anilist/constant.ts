import { CrawlPage } from '../../../app/extension/model/extension.model';

export const ACTIVITY_FIELDS = `... on TextActivity { id userId type replyCount text(asHtml: false) siteUrl isLocked isSubscribed likeCount isLiked createdAt user { id name siteUrl avatar { large } } }
    ... on ListActivity { id userId type status progress replyCount likeCount isLiked isLocked isSubscribed siteUrl createdAt user { id name siteUrl avatar { large } } media { id idMal title { romaji english native } siteUrl format status episodes chapters volumes averageScore meanScore popularity favourites genres seasonYear countryOfOrigin isAdult coverImage { large } bannerImage } }
    ... on MessageActivity { id recipientId messengerId type replyCount message(asHtml: false) isPrivate isLocked isSubscribed likeCount isLiked siteUrl createdAt messenger { id name siteUrl avatar { large } } }`;

export const REVIEW_FIELDS = `id userId mediaId mediaType summary body(asHtml: false) rating ratingAmount score private siteUrl createdAt updatedAt user { id name siteUrl avatar { large } } media { id idMal title { romaji english native } siteUrl format status episodes chapters volumes averageScore meanScore popularity favourites genres seasonYear countryOfOrigin isAdult coverImage { large } bannerImage }`;

export const USER_FIELDS = `id name about(asHtml: false) siteUrl donatorTier donatorBadge moderatorRoles createdAt updatedAt isFollower isBlocked unreadNotificationCount avatar { large medium } bannerImage options { titleLanguage displayAdultContent airingNotifications profileColor timezone activityMergeTime staffNameLanguage } statistics { anime { count meanScore standardDeviation minutesWatched episodesWatched } manga { count meanScore standardDeviation chaptersRead volumesRead } }`;

export const EMPTY: CrawlPage = { items: [] };
