import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const RECENT_CHALLENGES_UPSTREAM_MAX = 20;
export const RECENT_CHALLENGES_MAX_REQUESTS = 5;
