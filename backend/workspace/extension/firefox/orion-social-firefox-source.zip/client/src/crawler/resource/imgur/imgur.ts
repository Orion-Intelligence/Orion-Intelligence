import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_HOPS } from './constant';
import { Cursor } from './model';
import { api, clean, natural, page, parseCursor, post, stamp, submissionsPath, walk } from './helper';

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://imgur.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { entries: submissions, next } = await walk(tab, submissionsPath(username), payload, limitOf(payload, 25, 100));
    const fulls = await Promise.all(submissions.map((item: any) => (item.is_album ? api(tab, `/album/${encodeURIComponent(item.id ?? '')}`) : null)));

    const items: social_resource[] = [];
    submissions.forEach((submission: any, index: number) => {
      const full: any = fulls[index] ?? submission;
      const children: any[] = Array.isArray(full.images) ? full.images : [submission];
      children.forEach((image: any) => {
        items.push({
          type: 'images',
          resource_id: image.id ?? '',
          url: image.link ?? (image.id ? `https://i.imgur.com/${image.id}.jpg` : ''),
          parent_url: submission.link ?? `https://imgur.com/user/${username}`,
          title: clean(image.title ?? submission.title),
          caption: clean(image.description ?? submission.description),
          author: submission.account_url ?? username,
          datetime: stamp(image.datetime ?? submission.datetime),
          media_type: image.type ?? 'image/jpeg',
          media_url: image.mp4 ?? image.link ?? '',
          thumbnail_url: image.id ? `https://i.imgur.com/${image.id}m.jpg` : '',
          likes: String((submission.ups ?? 0) || ''),
          shares: '',
          views: String((image.views ?? submission.views ?? 0) || ''),
          image_id: image.id ?? '',
          title_text: clean(image.title),
          description: clean(image.description),
          mime_type: image.type ?? '',
          width: image.width ?? 0,
          height: image.height ?? 0,
          size_bytes: image.size ?? 0,
          bandwidth: image.bandwidth ?? 0,
          is_animated: image.animated ?? false,
          has_sound: image.has_sound ?? false,
          is_looping: image.looping ?? false,
          mp4_url: image.mp4 ?? '',
          gifv_url: image.gifv ?? '',
          hls_url: image.hls ?? '',
          mp4_size: image.mp4_size ?? 0,
          is_nsfw: image.nsfw ?? submission.nsfw ?? false,
          section: image.section ?? '',
          vote: image.vote ?? '',
          edited: image.edited ?? '',
          in_gallery: image.in_gallery ?? submission.in_gallery ?? false,
          in_most_viral: image.in_most_viral ?? false,
          is_ad: image.is_ad ?? false,
          ad_type: image.ad_type ?? 0,
          tags: Array.isArray(image.tags) ? image.tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', ') : '',
          album_id: submission.is_album ? submission.id ?? '' : '',
          album_title: submission.is_album ? clean(submission.title) : '',
          album_url: submission.is_album ? submission.link ?? '' : '',
          album_views: submission.views ?? 0,
          album_ups: submission.ups ?? 0,
          album_downs: submission.downs ?? 0,
          album_points: submission.points ?? 0,
          album_comment_count: submission.comment_count ?? 0,
          album_favorite_count: submission.favorite_count ?? 0,
          account_id: submission.account_id ?? 0,
          created_at: stamp(image.datetime ?? submission.datetime),
        });
      });
    });
    return page(items.filter((item) => item.url), next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://imgur.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { entries: albumsOnly, next } = await walk(tab, submissionsPath(username), payload, limitOf(payload, 25, 100), (item: any) => Boolean(item?.is_album));
    const fulls = await Promise.all(albumsOnly.map((item: any) => api(tab, `/album/${encodeURIComponent(item.id ?? '')}`)));
    return page(albumsOnly.map((item: any, index: number) => post(username, 'albums', { ...item, ...(fulls[index] ?? {}) })).filter((item) => item.url), next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://imgur.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { entries, next } = await walk(tab, (n: number) => `/account/${encodeURIComponent(username)}/comments/newest/${n}`, payload, limitOf(payload, 25, 100));
    return page(entries.map((comment: any): social_resource => ({
      type: 'comments',
      resource_id: String(comment.id ?? ''),
      url: comment.image_id ? `https://imgur.com/gallery/${comment.image_id}/comment/${comment.id}` : '',
      parent_url: `https://imgur.com/user/${username}`,
      title: '',
      caption: clean(comment.comment),
      author: comment.author ?? username,
      datetime: stamp(comment.datetime),
      media_type: 'comment',
      media_url: comment.image_id ? `https://imgur.com/${comment.image_id}` : '',
      thumbnail_url: comment.album_cover ? `https://i.imgur.com/${comment.album_cover}m.jpg` : '',
      likes: String((comment.ups ?? 0) || ''),
      shares: '',
      views: '',
      comment_id: comment.id ?? 0,
      comment_text: clean(comment.comment),
      comment_length: String(comment.comment ?? '').length,
      image_id: comment.image_id ?? '',
      image_url: comment.image_id ? `https://imgur.com/${comment.image_id}` : '',
      album_cover: comment.album_cover ?? '',
      on_album: comment.on_album ?? false,
      author_name: comment.author ?? '',
      author_id: comment.author_id ?? 0,
      ups: comment.ups ?? 0,
      downs: comment.downs ?? 0,
      points: comment.points ?? 0,
      parent_id: comment.parent_id ?? 0,
      is_reply: Boolean(comment.parent_id),
      deleted: comment.deleted ?? false,
      platform: comment.platform ?? '',
      has_admin_badge: comment.has_admin_badge ?? false,
      children_count: Array.isArray(comment.children) ? comment.children.length : 0,
      created_at: stamp(comment.datetime),
    })).filter((item) => item.url), next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://imgur.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { entries, next } = await walk(tab, submissionsPath(username), payload, limitOf(payload, 25, 100));
    const items = entries.map((entry: any) => post(username, 'posts', entry)).filter((item) => item.url);
    return page(items, next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
