import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, tracks } from './resource/bandcamp/bandcamp';

export class Bandcamp implements Crawler {
  readonly platform = 'bandcamp';
  readonly base = 'https://bandcamp.com';
  readonly loginUrl = 'https://bandcamp.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'albums':
        return albums(payload);
      case 'tracks':
        return tracks(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://${username}.bandcamp.com`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '');
      const bandName = decode(/id="band-name-location"[\s\S]*?class="title"[^>]*>([\s\S]*?)<\/span>/i.exec(html)?.[1] ?? '') || meta('og:site_name');
      if (!bandName) {
        return [];
      }

      return [{
        real_name: bandName,
        bio: decode(/id="bio-text"[^>]*>([\s\S]*?)<\/(?:p|div)>/i.exec(html)?.[1] ?? ''),
        description: decode(/id="bio-text"[^>]*>([\s\S]*?)<\/(?:p|div)>/i.exec(html)?.[1] ?? ''),
        location: decode(/id="band-name-location"[\s\S]*?class="location[^"]*"[^>]*>([\s\S]*?)<\/span>/i.exec(html)?.[1] ?? ''),
        profile_url: `https://${username}.bandcamp.com`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: /class="band-photo"[^>]+src="([^"]+)"/i.exec(html)?.[1] ?? meta('og:image'),
        banner: '',
        crawl_type: ['details', 'albums', 'tracks'],
        platform: this.platform,
        username: username,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://bandcamp.com/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
