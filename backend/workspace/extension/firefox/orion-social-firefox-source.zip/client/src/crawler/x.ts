import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { openSession, TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, pollQuery } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/x/x';

export class X implements Crawler {
  readonly platform = 'x';
  readonly base = 'https://x.com';
  readonly loginUrl = 'https://x.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    signedIn: ['a[data-testid="AppTabBar_Profile_Link"]', '[data-testid="SideNav_AccountSwitcher_Button"]'],
    signedOut: ['[data-testid="loginButton"]', 'a[href="/i/flow/login"]'],
    username: 'a[data-testid="AppTabBar_Profile_Link"]',
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '').replace(/^@/, '');
    if (!username) {
      return [];
    }

    const tab = await openSession('https://x.com/');
    if (!tab) {
      return [];
    }

    try {
      await tab.navigate(`https://x.com/${encodeURIComponent(username)}`);
      await tab.scrollLoad(4);
      const html = await tab.html();
      if (!html) {
        return [];
      }
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const handle = username;
      const nameIdx = html.indexOf('data-testid="UserName"');
      const open = nameIdx >= 0 ? html.indexOf('>', nameIdx) : -1;
      const block = open >= 0 ? decode(html.slice(open + 1, open + 4000).replace(/<[^>]*>/g, ' ').replace(/<[^>]*$/, '')) : '';
      const displayName = block.split('@')[0].trim() || decode(meta('og:title')).replace(/\s*\/\s*X$/i, '').replace(/\s*\(@[^)]+\)\s*$/, '').trim() || handle;
      if (!displayName) {
        return [];
      }

      const description = meta('og:description');
      const rendered = decode(html.replace(/<[^>]+>/g, ' '));
      const scaled = (raw: string): string => {
        const found = new RegExp(`([\\d.,]+)\\s*([KMB]?)\\s+${raw}`, 'i').exec(rendered);
        if (!found) {
          return '';
        }
        const scale: Record<string, number> = { K: 1e3, M: 1e6, B: 1e9 };
        return String(Math.round(Number(found[1].replace(/,/g, '')) * (scale[found[2].toUpperCase()] ?? 1)) || '');
      };
      return [{
        real_name: displayName,
        bio: /^what'?s happening\?!$/i.test(description) ? '' : description,
        description: /^what'?s happening\?!$/i.test(description) ? '' : description,
        location: '',
        profile_url: `https://x.com/${handle}`,
        total_posts: scaled('posts'),
        total_followers: scaled('Followers'),
        total_likes: '',
        avatar: meta('og:image'),
        banner: /https:\/\/pbs\.twimg\.com\/profile_banners\/\d+\/\d+/.exec(html)?.[0] ?? '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: handle,
        following: scaled('Following'),
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const reserved = /^(home|explore|notifications|messages|i|settings|search|compose|hashtag|following|followers)$/i;
    const dom = await pollQuery(tab, 'a[data-testid="AppTabBar_Profile_Link"], [data-testid="SideNav_AccountSwitcher_Button"]', (items) => {
      for (const item of items) {
        if (item.testid === 'AppTabBar_Profile_Link') {
          const handle = String(item.href || '').replace(/^\//, '').split(/[/?#]/)[0];
          if (handle && !reserved.test(handle)) {
            return { loggedIn: true, username: handle };
          }
        }
      }
      if (items.some((item) => item.testid === 'SideNav_AccountSwitcher_Button')) {
        return { loggedIn: true, username: '' };
      }
      return null;
    });
    return dom || NO_IDENTITY;
  }

  async verifyLogin(): Promise<boolean> {
    const tab = await openSession('https://x.com/');
    if (!tab) {
      return false;
    }
    try {
      const cookie = await tab.cookies();
      return /(?:^|;\s*)twid=/.test(cookie);
    }
    catch {
      return false;
    }
    finally {
      await tab.close();
    }
  }
}
