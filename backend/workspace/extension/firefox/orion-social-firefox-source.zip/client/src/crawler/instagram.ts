import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, pollQuery, tabJson } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { images, posts, videos } from './resource/instagram/instagram';

export class Instagram implements Crawler {
  readonly platform = 'instagram';
  readonly base = 'https://www.instagram.com';
  readonly loginUrl = 'https://www.instagram.com/accounts/login/';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    cookie: 'ds_user_id',
    usernameCookie: 'ds_user_id',
    signedIn: ['a[href^="/direct/"]', 'a[href="/explore/"]', 'svg[aria-label="Home"]'],
    signedOut: ['input[name="password"]', 'form[id*="login"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'images':
        return images(payload);
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const api = await fetch(`https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`, {
        headers: { Accept: 'application/json', 'X-IG-App-ID': '936619743392459', 'X-Requested-With': 'XMLHttpRequest' },
        credentials: 'include',
      });
      if (api.ok) {
        const payload = await api.json();
        const user = payload?.data?.user;
        if (user?.id) {
          const bioLinks: any[] = Array.isArray(user.bio_links) ? user.bio_links : [];
          return [{
            real_name: user.full_name || user.username || username,
            bio: user.biography ?? '',
            description: user.biography ?? '',
            location: '',
            profile_url: `https://www.instagram.com/${user.username ?? username}/`,
            total_posts: String((user.edge_owner_to_timeline_media?.count ?? 0) || ''),
            total_followers: String((user.edge_followed_by?.count ?? 0) || ''),
            total_likes: '',
            avatar: user.profile_pic_url_hd ?? user.profile_pic_url ?? '',
            banner: '',
            crawl_type: ['details', 'posts', 'images', 'videos'],
            platform: this.platform,
            username: user.username ?? username,
            user_id: user.id ?? '',
            fbid: user.fbid ?? '',
            full_name: user.full_name ?? '',
            posts_count: user.edge_owner_to_timeline_media?.count ?? 0,
            followers_count: user.edge_followed_by?.count ?? 0,
            highlight_reel_count: user.highlight_reel_count ?? 0,
            website: user.external_url ?? '',
            bio_links: bioLinks.map((l: any) => l.url ?? '').filter(Boolean).join(', '),
            fb_profile_biolink: user.fb_profile_biolink?.url ?? '',
            category: user.category_name ?? user.category_enum ?? '',
            business_email: user.business_email ?? '',
            business_phone: user.business_phone_number ?? '',
            business_category: user.business_category_name ?? '',
            business_address: (() => { try { const a = JSON.parse(user.business_address_json ?? '{}'); return [a.city_name, a.street_address, a.zip_code].filter(Boolean).join(', '); } catch { return ''; } })(),
            ai_agent_owner: user.ai_agent_owner_username ?? '',
            verified: user.is_verified ?? false,
            private: user.is_private ?? false,
            business: user.is_business_account ?? false,
            professional: user.is_professional_account ?? false,
            joined_recently: user.is_joined_recently ?? false,
            has_channel: user.has_channel ?? false,
            has_clips: user.has_clips ?? false,
            hide_like_counts: user.hide_like_and_view_counts ?? false,
            pronouns: Array.isArray(user.pronouns) ? user.pronouns.join(', ') : '',
          }];
        }
      }

      const response = await fetch(`https://www.instagram.com/${encodeURIComponent(username)}/`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const count = (text: string): number => {
        const found = /([\d.,]+)\s*([KMB]?)/i.exec(text ?? '');
        const scale: Record<string, number> = { K: 1e3, M: 1e6, B: 1e9 };
        return found ? Math.round(Number(found[1].replace(/,/g, '')) * (scale[found[2].toUpperCase()] ?? 1)) : 0;
      };

      const description = meta('og:description') || meta('description');
      const stats = /([\d.,]+[KMB]?)\s*Followers,\s*([\d.,]+[KMB]?)\s*Following,\s*([\d.,]+[KMB]?)\s*Posts/i.exec(description);
      const displayName = meta('og:title').replace(/\s*\(@[^)]+\).*$/, '').replace(/\s*•\s*Instagram.*$/i, '').trim();
      if (!stats && !displayName) {
        return [];
      }

      return [{
        real_name: displayName || username,
        bio: description.replace(/^.*?Posts\s*-\s*/i, '').replace(/^See Instagram photos and videos from\s*/i, '').trim(),
        description: description.replace(/^.*?Posts\s*-\s*/i, '').replace(/^See Instagram photos and videos from\s*/i, '').trim(),
        location: '',
        profile_url: `https://www.instagram.com/${username}/`,
        total_posts: String((stats ? count(stats[3]) : 0) || ''),
        total_followers: String((stats ? count(stats[1]) : 0) || ''),
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts', 'images', 'videos'],
        platform: this.platform,
        username: /\(@([^)]+)\)/.exec(meta('og:title'))?.[1] ?? username,
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const cookie = await tab.cookies();
    const id = (cookie.match(/(?:^|;\s*)ds_user_id=([^;]+)/) || [])[1] || '';
    if (!id) {
      return NO_IDENTITY;
    }
    const data = await tabJson(tab, 'https://www.instagram.com/api/v1/accounts/current_user/', { Accept: 'application/json', 'X-IG-App-ID': '936619743392459' });
    let username = data?.user?.username ? String(data.user.username) : '';
    if (!username) {
      const dom = await pollQuery(tab, 'a[href^="/"] img[alt]', (items) => {
        for (const item of items) {
          const alt = item.alt.toLowerCase();
          if (/profile photo|profile picture/.test(alt) && /^\/[^/]+\/$/.test(item.href)) {
            return { loggedIn: true, username: item.href.replace(/\//g, '') };
          }
        }
        return null;
      }, 6);
      if (dom) {
        username = dom.username;
      }
    }
    return { loggedIn: true, username };
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.instagram.com/api/v1/accounts/current_user/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.pk);
    }
    catch {
      return false;
    }
  }
}
