import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_ARCHIVE_HOPS } from './constant';
import { GamesCursor } from './model';
import { api, game_resource, json, offsetOf, parseGamesCursor, stamp, tag } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').toLowerCase();
  const tab = username ? await openSession('https://www.chess.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, 100);
    const archives = await api(tab, `/player/${encodeURIComponent(username)}/games/archives`);
    const list: string[] = (Array.isArray(archives?.archives) ? archives.archives : []).map((entry: unknown) => String(entry ?? '').trim()).filter(Boolean);
    if (!list.length) {
      return EMPTY;
    }

    const cursor = parseGamesCursor(payload.cursor);
    let index = cursor ? list.indexOf(cursor.archive) : list.length - 1;
    let offset = cursor?.offset ?? 0;
    if (index < 0) {
      return EMPTY;
    }

    const items: social_resource[] = [];
    let next: GamesCursor | undefined;
    for (let hops = 0; hops < MAX_ARCHIVE_HOPS && index >= 0 && items.length < limit; hops++) {
      const archive = list[index];
      const month = await json(tab, archive);
      const newestFirst = ((Array.isArray(month?.games) ? month.games : []) as any[]).slice().reverse();
      const slice = newestFirst.slice(offset, offset + (limit - items.length));
      items.push(...slice.map((game: any) => game_resource(game, username, archive)).filter((item) => item.url));

      const consumed = offset + slice.length;
      if (consumed < newestFirst.length) {
        next = { archive, offset: consumed };
        break;
      }

      index -= 1;
      offset = 0;
      next = index >= 0 ? { archive: list[index], offset: 0 } : undefined;
    }

    return { items, next_cursor: items.length && next ? JSON.stringify(next) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').toLowerCase();
  const tab = username ? await openSession('https://www.chess.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const limit = limitOf(payload, 25, 100);
    const offset = offsetOf(payload.cursor);
    const data = await api(tab, `/player/${encodeURIComponent(username)}/clubs`);
    const clubs = (Array.isArray(data?.clubs) ? data.clubs : []) as any[];
    const slice = clubs.slice(offset, offset + limit);
    const fulls = await Promise.all(slice.map((club: any) => api(tab, `/club/${String(club.url ?? '').split('/').pop() ?? ''}`)));

    const items = slice.map((club: any, index: number): social_resource => {
      const full: any = fulls[index] ?? {};
      return {
        type: 'organizations',
        resource_id: String(full.club_id ?? club['@id'] ?? ''),
        url: club.url ?? '',
        parent_url: `https://www.chess.com/member/${username}`,
        title: club.name ?? full.name ?? '',
        caption: String(full.description ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 1000),
        author: username,
        datetime: stamp(club.joined),
        media_type: 'club',
        media_url: club.url ?? '',
        thumbnail_url: club.icon ?? full.icon ?? '',
        likes: '',
        shares: String((full.members_count ?? 0) || ''),
        views: '',
        club_id: full.club_id ?? 0,
        name: club.name ?? full.name ?? '',
        api_url: club['@id'] ?? '',
        icon: club.icon ?? '',
        joined: stamp(club.joined),
        last_activity: stamp(club.last_activity),
        members_count: full.members_count ?? 0,
        country: String(full.country ?? '').split('/').pop() ?? '',
        average_daily_rating: full.average_daily_rating ?? 0,
        description: String(full.description ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        club_created: stamp(full.created),
        admins_count: Array.isArray(full.admin) ? full.admin.length : 0,
        admins: Array.isArray(full.admin) ? full.admin.map((entry: string) => String(entry).split('/').pop()).join(', ') : '',
        visibility: full.visibility ?? '',
        join_request: full.join_request ?? '',
        club_url: full.url ?? club.url ?? '',
      };
    }).filter((item) => item.url);

    const consumed = offset + slice.length;
    return { items, next_cursor: items.length && consumed < clubs.length ? String(consumed) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
