import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function pageOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 1 ? n : 1;
}

async function collection(developer: string, page: number, perPage: number): Promise<any> {
  const response = await fetch(`https://flathub.org/api/v2/collection/developer/${encodeURIComponent(developer)}?page=${page}&per_page=${perPage}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function developerTotal(developer: string): Promise<number> {
  const data = await collection(developer, 1, 1);
  return Number(data?.totalHits ?? 0);
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const developer = String(payload.username ?? '');
  if (!developer) {
    return EMPTY;
  }

  try {
    const page = pageOf(payload);
    const perPage = limitOf(payload, 25, 50);
    const data = await collection(developer, page, perPage);
    const total = Number(data?.totalHits ?? 0);
    const totalPages = Number(data?.totalPages ?? 0);
    const rows: any[] = Array.isArray(data?.hits) ? data.hits : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((app: any): social_resource => {
      const appId = String(app.app_id ?? app.id ?? '');
      const categories = [...(Array.isArray(app.main_categories) ? app.main_categories : []), ...(Array.isArray(app.sub_categories) ? app.sub_categories : [])];
      return {
        type: 'projects',
        resource_id: appId,
        url: `https://flathub.org/apps/${appId}`,
        parent_url: `https://flathub.org/apps/collection/developer/${encodeURIComponent(developer)}`,
        title: clean(app.name) || appId,
        caption: clean(app.summary),
        author: app.developer_name ?? developer,
        datetime: app.updated_at ?? app.added_at ?? '',
        media_type: 'application',
        media_url: '',
        thumbnail_url: app.icon ?? '',
        likes: String((app.favorites_count ?? 0) || ''),
        shares: '',
        views: String((app.installs_last_month ?? 0) || ''),
        name: clean(app.name),
        app_id: appId,
        description: clean(app.summary),
        developer_name: app.developer_name ?? '',
        license: app.project_license ?? '',
        is_free_license: Boolean(app.is_free_license),
        categories: categories.join(', '),
        keywords: Array.isArray(app.keywords) ? app.keywords.join(', ') : '',
        installs_last_month: app.installs_last_month ?? 0,
        favorites_count: app.favorites_count ?? 0,
        verified: Boolean(app.verification_verified),
        verification_method: app.verification_method ?? '',
        added_at: app.added_at ?? '',
        updated_at: app.updated_at ?? '',
      };
    }).filter((item) => item.url && item['app_id']);

    const hasMore = totalPages ? page < totalPages : (total ? page * perPage < total : rows.length >= perPage);
    return { items, next_cursor: items.length && hasMore ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
}
