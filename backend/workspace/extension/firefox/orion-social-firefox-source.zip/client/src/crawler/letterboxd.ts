import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, friends, posts, reviews } from './resource/letterboxd/letterboxd';

export class Letterboxd implements Crawler {
  readonly platform = 'letterboxd';
  readonly base = 'https://letterboxd.com';
  readonly loginUrl = 'https://letterboxd.com/sign-in/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'reviews':
        return reviews(payload);
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://letterboxd.com/${encodeURIComponent(username)}/`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const count = (text: string): number => {
        const found = /([\d.,]+)\s*([KMB]?)/i.exec(text ?? '');
        const scale: Record<string, number> = { K: 1e3, M: 1e6, B: 1e9 };
        return found ? Math.round(Number(found[1].replace(/,/g, '')) * (scale[found[2].toUpperCase()] ?? 1)) : 0;
      };

      const displayName = (meta('og:title') || decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '')).replace(/[’']s profile.*$/i, '').replace(/\s*•\s*Letterboxd$/i, '').trim();
      if (!displayName || /^Letterboxd$/i.test(displayName)) {
        return [];
      }

      const stat = (label: string): number => count(new RegExp(`<span class="value">([\\d.,]+[KMB]?)</span>\\s*<span class="definition">${label}`, 'i').exec(html)?.[1] ?? '0');
      return [{
        real_name: displayName,
        bio: meta('og:description') || decode(/class="[^"]*bio[^"]*"[^>]*>([\s\S]*?)<\/(?:div|section)>/i.exec(html)?.[1] ?? ''),
        description: meta('og:description') || decode(/class="[^"]*bio[^"]*"[^>]*>([\s\S]*?)<\/(?:div|section)>/i.exec(html)?.[1] ?? ''),
        location: decode(/class="[^"]*metadatum[^"]*"[^>]*>\s*<span class="label">Location<\/span>[\s\S]*?<span[^>]*>([\s\S]*?)<\/span>/i.exec(html)?.[1] ?? ''),
        profile_url: `https://letterboxd.com/${username}/`,
        total_posts: '',
        total_followers: String((stat('Followers')) || ''),
        total_likes: '',
        avatar: /class="[^"]*profile-avatar[^"]*"[\s\S]*?<img[^>]+src="([^"]+)"/i.exec(html)?.[1] ?? meta('og:image'),
        banner: /data-backdrop="([^"]+)"/i.exec(html)?.[1] ?? '',
        crawl_type: ['details', 'reviews', 'posts', 'followers', 'friends'],
        platform: this.platform,
        username: username,
        films: stat('Films'),
        thisYear: stat('This year'),
        lists: stat('Lists'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://letterboxd.com/settings/', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      const html = await response.text();
      return !/type=["']password["']/i.test(html);
    }
    catch {
      return false;
    }
  }
}
