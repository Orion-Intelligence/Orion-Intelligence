import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, END, MAX_PAGE_SIZE, MAX_UPSTREAM_PAGES, PAGE_SIZE } from './constant';
import { PinBatch } from './model';
import { batch, bookmarkFromState, clean, collect, cursorOf, image, nextBookmark, page, resource, store, toResource } from './helper';

export async function pins(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    return await collect(payload, () => true);
  }
  catch {
    return EMPTY;
  }
}

export async function images(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const result = await collect(payload, (item) => !item['is_video']);
    return { ...result, items: result.items.map((item) => ({ ...item, type: 'images' as const })) };
  }
  catch {
    return EMPTY;
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const result = await collect(payload, (item) => Boolean(item['is_video']));
    return { ...result, items: result.items.map((item) => ({ ...item, type: 'videos' as const })) };
  }
  catch {
    return EMPTY;
  }
}
