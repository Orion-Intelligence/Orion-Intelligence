import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { projects, userProjects } from './resource/modrinth/modrinth';

export class Modrinth implements Crawler {
  readonly platform = 'modrinth';
  readonly base = 'https://modrinth.com';
  readonly loginUrl = 'https://modrinth.com/auth/sign-in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const all = await userProjects(username);
      if (!all.length) {
        return [];
      }

      const downloads = all.reduce((sum: number, project: any) => sum + Number(project?.downloads ?? 0), 0);
      const followers = all.reduce((sum: number, project: any) => sum + Number(project?.followers ?? 0), 0);
      return [{
        real_name: username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://modrinth.com/user/${username}`,
        total_posts: String(all.length || ''),
        total_followers: String(followers || ''),
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username: username,
        project_count: all.length,
        total_downloads: downloads,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://modrinth.com/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
