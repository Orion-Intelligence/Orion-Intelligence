import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const PAGE_SIZE = 12;
export const MAX_PAGES_PER_CALL = 5;

export const REVIEW_BLOCK = /<(?:li|article)[^>]+class="[^"]*(?:film-detail|production-viewing)[^"]*"/g;
export const LIST_BLOCK = /<article[^>]+class="[^"]*list-summary[^"]*"/g;

export const PERSON_BLOCK = /<div[^>]+class="[^"]*person-summary[^"]*"/g;
