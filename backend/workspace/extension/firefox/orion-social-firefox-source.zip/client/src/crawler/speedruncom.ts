import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { games } from './resource/speedruncom/speedruncom';

export class SpeedrunCom implements Crawler {
  readonly platform = 'speedruncom';
  readonly base = 'https://www.speedrun.com';
  readonly loginUrl = 'https://www.speedrun.com/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.speedrun.com/api/v1/users?lookup=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = Array.isArray(payload?.data) ? payload.data[0] : null;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.names?.international ?? username,
        bio: data.pronouns ?? '',
        description: data.pronouns ?? '',
        location: data.location?.country?.names?.international ?? '',
        profile_url: data.weblink ?? `https://www.speedrun.com/users/${data.names?.international ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.assets?.image?.uri ?? '',
        banner: '',
        crawl_type: ['details', 'games'],
        platform: this.platform,
        username: data.names?.international ?? username,
        user_id: data.id ?? '',
        name_international: data.names?.international ?? '',
        name_japanese: data.names?.japanese ?? '',
        pronouns: data.pronouns ?? '',
        role: data.role ?? '',
        country: data.location?.country?.names?.international ?? '',
        country_code: data.location?.country?.code ?? '',
        region: data.location?.region?.names?.international ?? '',
        region_code: data.location?.region?.code ?? '',
        weblink: data.weblink ?? '',
        twitch: data.twitch?.uri ?? '',
        youtube: data.youtube?.uri ?? '',
        twitter: data.twitter?.uri ?? '',
        hitbox: data.hitbox?.uri ?? '',
        speedrunslive: data.speedrunslive?.uri ?? '',
        signup: data.signup ?? '',
        created_at: data.signup ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.speedrun.com/api/v2/GetSession', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.session?.signedIn === true);
    }
    catch {
      return false;
    }
  }
}
