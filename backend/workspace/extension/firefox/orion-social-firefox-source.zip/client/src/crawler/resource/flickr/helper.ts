import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { Context, Cursor } from './model';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}

export function isoFromEpoch(value: unknown): string {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) {
    return '';
  }
  try {
    return new Date(seconds * 1000).toISOString();
  }
  catch {
    return '';
  }
}

export function parseCursor(payload: CrawlPayload): Cursor | null {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    const page = Number(parsed?.page);
    if (!Number.isFinite(page) || page < 2) {
      return null;
    }
    return {
      page: Math.floor(page),
      nsid: typeof parsed?.nsid === 'string' ? parsed.nsid : '',
      key: typeof parsed?.key === 'string' ? parsed.key : '',
      alias: typeof parsed?.alias === 'string' ? parsed.alias : '',
    };
  }
  catch {
    return null;
  }
}

export function nextCursor(items: social_resource[], page: number, pages: unknown, context: Context): string | undefined {
  const total = Number(pages);
  if (!items.length || !Number.isFinite(total) || page >= total) {
    return undefined;
  }
  const cursor: Cursor = { page: page + 1, nsid: context.nsid, key: context.key, alias: context.alias };
  return JSON.stringify(cursor);
}

export async function resolve(tab: TabController, username: string): Promise<Context | null> {
  try {
    const response = await tab.fetch(`https://www.flickr.com/photos/${encodeURIComponent(username)}/`);
    if (!response.ok) {
      return null;
    }
    const html = response.body;
    const nsid = /^\d+@N\d+$/.test(username)
      ? username
      : (/"nsid":"(\d+@N\d+)"/.exec(html)?.[1] ?? /"id":"(\d+@N\d+)"/.exec(html)?.[1] ?? /photos\/(\d+@N\d+)\//.exec(html)?.[1] ?? '');
    if (!nsid) {
      return null;
    }
    const key = /site_key\s*=\s*["']([a-f0-9]{32})["']/i.exec(html)?.[1] ?? /"site_key"\s*:\s*"([a-f0-9]{32})"/i.exec(html)?.[1] ?? '';
    const alias = /"pathAlias":"([^"\\]+)"/.exec(html)?.[1] ?? (/^\d+@N\d+$/.test(username) ? '' : username);
    return { nsid, key, alias };
  }
  catch {
    return null;
  }
}

export async function rest(tab: TabController, method: string, key: string, params: Record<string, string | number>): Promise<any> {
  if (!key) {
    return null;
  }
  try {
    const query = Object.entries({ method, api_key: key, format: 'json', nojsoncallback: 1, ...params })
      .map(([name, value]) => `${encodeURIComponent(name)}=${encodeURIComponent(String(value))}`)
      .join('&');
    const response = await tab.fetch(`https://api.flickr.com/services/rest?${query}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return null;
    }
    const data = JSON.parse(response.body);
    return data?.stat === 'ok' ? data : null;
  }
  catch {
    return null;
  }
}

export async function paged(tab: TabController, username: string, cursor: Cursor | null, request: (context: Context, page: number) => Promise<any>): Promise<{ data: any; context: Context; page: number } | null> {
  const page = cursor?.page ?? 1;
  let context: Context | null = cursor?.nsid && cursor?.key ? { nsid: cursor.nsid, key: cursor.key, alias: cursor.alias ?? '' } : null;
  const fromCursor = Boolean(context);
  if (!context) {
    context = await resolve(tab, username);
  }
  if (!context) {
    return null;
  }

  let data = await request(context, page);
  if (!data && fromCursor) {
    const fresh = await resolve(tab, username);
    if (fresh && fresh.key !== context.key) {
      context = fresh;
      data = await request(context, page);
    }
  }
  return data ? { data, context, page } : null;
}

export async function feed(tab: TabController, id: string): Promise<any[]> {
  try {
    const response = await tab.fetch(`https://www.flickr.com/services/feeds/photos_public.gne?id=${encodeURIComponent(id)}&format=json&nojsoncallback=1`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return [];
    }
    const data = JSON.parse(response.body);
    return Array.isArray(data?.items) ? data.items : [];
  }
  catch {
    return [];
  }
}

export function imageFromFeed(username: string, id: string, item: any): social_resource {
  const photoId = /\/(\d+)\/?$/.exec(String(item.link ?? ''))?.[1] ?? '';
  const medium = String(item.media?.m ?? '');
  const tags = String(item.tags ?? '').split(/\s+/).filter(Boolean);
  return {
    type: 'images',
    resource_id: photoId,
    url: item.link ?? '',
    parent_url: `https://www.flickr.com/photos/${username}/`,
    title: decode(String(item.title ?? '')),
    caption: decode(String(item.description ?? '')).slice(0, 1500),
    author: /\("([^"]+)"\)/.exec(String(item.author ?? ''))?.[1] ?? username,
    datetime: item.published ?? '',
    media_type: 'photo',
    media_url: medium.replace(/_m\.jpg$/, '_b.jpg'),
    thumbnail_url: medium,
    likes: '',
    shares: '',
    views: '',
    photo_id: photoId,
    title_text: decode(String(item.title ?? '')),
    description: decode(String(item.description ?? '')),
    photo_page: item.link ?? '',
    image_medium: medium,
    image_small: medium.replace(/_m\.jpg$/, '_s.jpg'),
    image_thumbnail: medium.replace(/_m\.jpg$/, '_t.jpg'),
    image_large: medium.replace(/_m\.jpg$/, '_b.jpg'),
    image_original: medium.replace(/_m\.jpg$/, '_o.jpg'),
    tags: tags.join(', '),
    tags_count: tags.length,
    author_raw: item.author ?? '',
    author_name: /\("([^"]+)"\)/.exec(String(item.author ?? ''))?.[1] ?? '',
    author_id: item.author_id ?? id,
    nsid: id,
    date_taken: item.date_taken ?? '',
    published: item.published ?? '',
    license: item.license ?? '',
    owner_url: `https://www.flickr.com/photos/${id}/`,
  };
}

export function imageFromApi(username: string, context: Context, photo: any): social_resource {
  const photoId = String(photo.id ?? '');
  const owner = String(photo.pathalias || context.alias || photo.owner || context.nsid || username);
  const link = photoId ? `https://www.flickr.com/photos/${owner}/${photoId}/` : '';
  const base = photoId && photo.secret ? `https://live.staticflickr.com/${photo.server ?? ''}/${photoId}_${photo.secret}` : '';
  const medium = String(photo.url_s ?? (base ? `${base}_m.jpg` : ''));
  const large = String(photo.url_b ?? (base ? `${base}_b.jpg` : medium.replace(/_m\.jpg$/, '_b.jpg')));
  const original = String(photo.url_o ?? (base ? `${base}_o.jpg` : medium.replace(/_m\.jpg$/, '_o.jpg')));
  const title = decode(String(photo.title ?? ''));
  const description = decode(String(photo.description?._content ?? photo.description ?? ''));
  const ownerName = String(photo.ownername ?? '');
  const published = isoFromEpoch(photo.dateupload);
  const tags = String(photo.tags ?? '').split(/\s+/).filter(Boolean);
  return {
    type: 'images',
    resource_id: photoId,
    url: link,
    parent_url: `https://www.flickr.com/photos/${username}/`,
    title,
    caption: description.slice(0, 1500),
    author: ownerName || username,
    datetime: published,
    media_type: String(photo.media ?? '') || 'photo',
    media_url: large,
    thumbnail_url: medium,
    likes: '',
    shares: '',
    views: String(photo.views ?? ''),
    photo_id: photoId,
    title_text: title,
    description,
    photo_page: link,
    image_medium: medium,
    image_small: medium.replace(/_m\.jpg$/, '_s.jpg'),
    image_thumbnail: String(photo.url_t ?? medium.replace(/_m\.jpg$/, '_t.jpg')),
    image_large: large,
    image_original: original,
    tags: tags.join(', '),
    tags_count: tags.length,
    author_raw: ownerName ? `nobody@flickr.com ("${ownerName}")` : '',
    author_name: ownerName,
    author_id: photo.owner ?? context.nsid,
    nsid: context.nsid,
    date_taken: photo.datetaken ?? '',
    published,
    license: String(photo.license ?? ''),
    owner_url: `https://www.flickr.com/photos/${context.nsid}/`,
  };
}

export function albumFromApi(username: string, context: Context, set: any): social_resource {
  const id = String(set.id ?? '');
  const owner = String(context.alias || set.owner || context.nsid || username);
  const url = id ? `https://www.flickr.com/photos/${owner}/albums/${id}` : '';
  const extras = set.primary_photo_extras ?? {};
  const cover = set.primary && set.secret ? `https://live.staticflickr.com/${set.server ?? ''}/${set.primary}_${set.secret}_m.jpg` : '';
  return {
    type: 'albums',
    resource_id: id,
    url,
    parent_url: `https://www.flickr.com/photos/${username}/`,
    title: decode(String(set.title?._content ?? set.title ?? '')),
    caption: decode(String(set.description?._content ?? set.description ?? '')),
    author: owner,
    datetime: isoFromEpoch(set.date_create),
    media_type: 'album',
    media_url: url,
    thumbnail_url: String(extras.url_m ?? extras.url_s ?? cover),
    likes: '',
    shares: '',
    views: String(set.count_views ?? ''),
    album_id: id,
    owner_path: owner,
    photo_count: Number(set.count_photos ?? set.photos ?? 0),
    video_count: Number(set.count_videos ?? set.videos ?? 0),
    view_count: Number(set.count_views ?? 0),
    comment_count: Number(set.count_comments ?? 0),
    album_url: url,
  };
}

export async function albumsFromHtml(tab: TabController, username: string): Promise<CrawlPage> {
  const response = await tab.fetch(`https://www.flickr.com/photos/${encodeURIComponent(username)}/albums`);
  if (!response.ok) {
    return EMPTY;
  }

  const html = response.body;
  const seen = new Set<string>();
  const items: social_resource[] = [];
  for (const match of html.matchAll(/\/photos\/([^/"]+)\/albums\/(\d+)/g)) {
    const id = match[2];
    if (seen.has(id)) {
      continue;
    }
    seen.add(id);
    const block = html.slice(Math.max(0, (match.index ?? 0) - 1500), (match.index ?? 0) + 1500);
    items.push({
      type: 'albums',
      resource_id: id,
      url: `https://www.flickr.com/photos/${match[1]}/albums/${id}`,
      parent_url: `https://www.flickr.com/photos/${username}/`,
      title: decode(/"title":"((?:[^"\\]|\\.)*)"/.exec(block)?.[1] ?? ''),
      caption: decode(/"description":"((?:[^"\\]|\\.)*)"/.exec(block)?.[1] ?? ''),
      author: match[1],
      datetime: '',
      media_type: 'album',
      media_url: `https://www.flickr.com/photos/${match[1]}/albums/${id}`,
      thumbnail_url: (/"(https:\/\/live\.staticflickr\.com\/[^"]+)"/.exec(block)?.[1] ?? '').replace(/\\\//g, '/'),
      likes: '',
      shares: '',
      views: String(/"count_views":"?(\d+)"?/.exec(block)?.[1] ?? ''),
      album_id: id,
      owner_path: match[1],
      photo_count: Number(/"count_photos":"?(\d+)"?/.exec(block)?.[1] ?? 0),
      video_count: Number(/"count_videos":"?(\d+)"?/.exec(block)?.[1] ?? 0),
      view_count: Number(/"count_views":"?(\d+)"?/.exec(block)?.[1] ?? 0),
      comment_count: Number(/"count_comments":"?(\d+)"?/.exec(block)?.[1] ?? 0),
      album_url: `https://www.flickr.com/photos/${match[1]}/albums/${id}`,
    });
  }
  return { items };
}
