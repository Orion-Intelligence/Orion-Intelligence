import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { friends, posts } from './resource/livejournal/livejournal';

export class LiveJournal implements Crawler {
  readonly platform = 'livejournal';
  readonly base = 'https://www.livejournal.com';
  readonly loginUrl = 'https://www.livejournal.com/login.bml';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const host = `${username}.livejournal.com`;
      const response = await fetch(`https://${host}/profile`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? '');
      const cell = (label: string): string => decode(new RegExp(`${label}[\\s\\S]{0,120}?<(?:dd|td|span)[^>]*>([\\s\\S]*?)</(?:dd|td|span)>`, 'i').exec(html)?.[1] ?? '');
      const pageTitle = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const displayName = decode(/<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html)?.[1] ?? '') || pageTitle.replace(/\s*[—-]\s*Profile\s*$/i, '').trim();
      if (!displayName || !/Profile/i.test(pageTitle)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: cell('Bio') || cell('About') || (/^Your life is the best story/i.test(meta('og:description')) ? '' : meta('og:description')),
        description: cell('Bio') || cell('About') || (/^Your life is the best story/i.test(meta('og:description')) ? '' : meta('og:description')),
        location: cell('Location'),
        profile_url: `https://${host}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts', 'friends'],
        platform: this.platform,
        username: username,
        birthdate: cell('Birthdate'),
        created: cell('Created on'),
        journalEntries: Number(cell('Journal entries').replace(/\D/g, '')) || 0,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.livejournal.com/manage/settings/', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
