export function nextCursor(doc: Document, base: string): string | undefined {
  const next = doc.querySelector('a[rel="next"][href]')
    ?? Array.from(doc.querySelectorAll('.paginate-container a[href]')).find((link) => /\b(next|older)\b/i.test(link.textContent ?? ''));
  const href = next?.getAttribute('href');
  return href ? new URL(href, base).toString() : undefined;
}
