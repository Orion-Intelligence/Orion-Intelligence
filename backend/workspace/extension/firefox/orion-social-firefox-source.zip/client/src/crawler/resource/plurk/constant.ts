import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const UPSTREAM_PAGE_SIZE = 20;
export const MAX_UPSTREAM_CALLS = 5;

export const OWNER_FIELDS = ['nick_name', 'display_name', 'full_name', 'location', 'timezone', 'karma', 'verified_account', 'gender', 'relationship'] as const;
