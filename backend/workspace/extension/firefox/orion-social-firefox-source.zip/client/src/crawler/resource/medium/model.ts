export interface MediumPage {
  posts: any[];
  from: string | null;
}
