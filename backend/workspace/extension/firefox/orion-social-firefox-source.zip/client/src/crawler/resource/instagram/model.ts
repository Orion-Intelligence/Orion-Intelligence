export interface Cursor { id: string; after: string; last: string; src: 'graphql' | 'v1'; owner: Owner }
export interface Owner { id: string; name: string; verified: boolean; followers: number }
export interface Timeline { user: any; nodes: any[]; next?: Cursor }
