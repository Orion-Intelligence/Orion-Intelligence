import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const COMMENTS_PER_PAGE = 20;
export const COMMENTS_MAX_FETCHES = 5;
