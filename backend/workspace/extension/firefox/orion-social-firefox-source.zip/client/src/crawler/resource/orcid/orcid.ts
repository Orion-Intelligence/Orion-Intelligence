import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function idDate(summary: any): string {
  const date = summary?.['publication-date'] ?? {};
  const year = date?.year?.value ?? '';
  const month = date?.month?.value ?? '';
  const day = date?.day?.value ?? '';
  return [year, month, day].filter(Boolean).join('-');
}

async function json(orcid: string, path: string): Promise<any> {
  const response = await fetch(`https://pub.orcid.org/v3.0/${encodeURIComponent(orcid)}/${path}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function works(orcid: string): Promise<any[]> {
  const data = await json(orcid, 'works');
  return Array.isArray(data?.group) ? data.group : [];
}

export async function details(orcid: string): Promise<social_profile_details[]> {
  const groups = await works(orcid);
  if (!groups.length) {
    return [];
  }

  const person = await json(orcid, 'person') ?? {};
  const name = person.name ?? {};
  const given = name['given-names']?.value ?? '';
  const family = name['family-name']?.value ?? '';
  const fullName = clean(`${given} ${family}`) || orcid;
  const biography = person.biography?.content ?? '';
  return [{
    real_name: fullName,
    bio: clean(biography),
    description: clean(biography),
    location: '',
    profile_url: `https://orcid.org/${orcid}`,
    total_posts: String(groups.length || ''),
    total_followers: '',
    total_likes: '',
    avatar: '',
    banner: '',
    crawl_type: ['details', 'papers'],
    platform: 'orcid',
    username: orcid,
    works_count: groups.length,
    orcid_id: orcid,
  }];
}

export async function papers(payload: CrawlPayload): Promise<CrawlPage> {
  const orcid = String(payload.username ?? '');
  if (!orcid) {
    return EMPTY;
  }

  try {
    const groups = await works(orcid);
    if (!groups.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = groups.slice(offset, offset + limit);

    const items = slice.map((group: any): social_resource => {
      const summary = (group['work-summary'] ?? [])[0] ?? {};
      const ids = summary['external-ids']?.['external-id'] ?? [];
      const doi = ids.find((id: any) => id?.['external-id-type'] === 'doi')?.['external-id-value'] ?? '';
      const putCode = String(summary['put-code'] ?? '');
      const url = doi ? `https://doi.org/${doi}` : (summary.url?.value ?? `https://orcid.org/${orcid}`);
      return {
        type: 'papers',
        resource_id: putCode || doi,
        url,
        parent_url: `https://orcid.org/${orcid}`,
        title: clean(summary.title?.title?.value) || 'Untitled work',
        caption: clean(summary['journal-title']?.value),
        author: orcid,
        datetime: idDate(summary),
        media_type: 'paper',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        name: clean(summary.title?.title?.value),
        work_type: summary.type ?? '',
        journal: clean(summary['journal-title']?.value),
        publication_year: summary['publication-date']?.year?.value ?? '',
        doi,
        external_ids: ids.map((id: any) => `${id?.['external-id-type']}: ${id?.['external-id-value']}`).join(', '),
        put_code: putCode,
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < groups.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
