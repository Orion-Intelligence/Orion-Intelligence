import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, offsetOf, page } from './helper';

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://rubygems.org/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 100);
    const list = await api(tab, `/owners/${encodeURIComponent(username)}/gems.json`);
    const all = (Array.isArray(list) ? list : []) as any[];
    const gems = all.slice(offset, offset + limit);
    const owners = await Promise.all(gems.map((gem: any) => api(tab, `/gems/${encodeURIComponent(gem.name ?? '')}/owners.json`)));

    return page(gems.map((gem: any, index: number): social_resource => {
      const metadata = gem.metadata ?? {};
      const dependencies = gem.dependencies ?? {};
      const runtime: any[] = Array.isArray(dependencies.runtime) ? dependencies.runtime : [];
      const development: any[] = Array.isArray(dependencies.development) ? dependencies.development : [];
      const maintainers: any[] = Array.isArray(owners[index]) ? owners[index] : [];
      return {
        type: 'repositories',
        resource_id: gem.name ?? '',
        url: gem.project_uri ?? `https://rubygems.org/gems/${gem.name ?? ''}`,
        parent_url: `https://rubygems.org/profiles/${username}`,
        title: gem.name ?? '',
        caption: clean(gem.info),
        author: gem.authors ?? username,
        datetime: gem.version_created_at ?? '',
        media_type: 'gem',
        media_url: gem.gem_uri ?? '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: String((gem.downloads ?? 0) || ''),
        gem_name: gem.name ?? '',
        version: gem.version ?? '',
        version_created_at: gem.version_created_at ?? '',
        version_downloads: gem.version_downloads ?? 0,
        downloads: gem.downloads ?? 0,
        platform: gem.platform ?? '',
        authors: gem.authors ?? '',
        info: clean(gem.info),
        licenses: Array.isArray(gem.licenses) ? gem.licenses.join(', ') : '',
        yanked: gem.yanked ?? false,
        sha: gem.sha ?? '',
        spec_sha: gem.spec_sha ?? '',
        project_uri: gem.project_uri ?? '',
        gem_uri: gem.gem_uri ?? '',
        homepage_uri: gem.homepage_uri ?? '',
        wiki_uri: gem.wiki_uri ?? '',
        documentation_uri: gem.documentation_uri ?? '',
        mailing_list_uri: gem.mailing_list_uri ?? '',
        source_code_uri: gem.source_code_uri ?? metadata.source_code_uri ?? '',
        bug_tracker_uri: gem.bug_tracker_uri ?? metadata.bug_tracker_uri ?? '',
        changelog_uri: gem.changelog_uri ?? metadata.changelog_uri ?? '',
        funding_uri: gem.funding_uri ?? metadata.funding_uri ?? '',
        mfa_required: String(metadata.rubygems_mfa_required ?? '') === 'true',
        metadata_keys: Object.keys(metadata).join(', '),
        runtime_dependencies: runtime.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', '),
        runtime_dependencies_count: runtime.length,
        development_dependencies: development.map((entry: any) => entry?.name ?? '').filter(Boolean).join(', '),
        development_dependencies_count: development.length,
        maintainers: maintainers.map((owner: any) => owner?.handle ?? '').filter(Boolean).join(', '),
        maintainers_count: maintainers.length,
        maintainer_emails: maintainers.map((owner: any) => owner?.email ?? '').filter(Boolean).join(', '),
      };
    }).filter((item) => item.url), offset, all.length);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
