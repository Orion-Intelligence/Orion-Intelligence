import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const raw = String(payload.cursor ?? '').trim();
  const n = Math.floor(Number(raw));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export async function packageList(username: string): Promise<Record<string, string>> {
  const response = await fetch(`https://registry.npmjs.org/-/user/${encodeURIComponent(username)}/package`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return {};
  }
  const data = await response.json();
  return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const names = Object.keys(await packageList(username));
    if (!names.length) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const slice = names.slice(offset, offset + limit);
    const docs = await Promise.all(slice.map((name) => fetch(`https://registry.npmjs.org/${name.replace('/', '%2F')}`, { headers: { Accept: 'application/json' } })
      .then((response) => response.ok ? response.json() : null)
      .catch(() => null)));

    const items = slice.map((name: string, index: number): social_resource => {
      const doc: any = docs[index] ?? {};
      const latest = doc['dist-tags']?.latest ?? '';
      const version: any = doc.versions?.[latest] ?? {};
      const time = doc.time ?? {};
      const maintainers: any[] = Array.isArray(doc.maintainers) ? doc.maintainers : [];
      return {
        type: 'repositories',
        resource_id: name,
        url: `https://www.npmjs.com/package/${name}`,
        parent_url: `https://www.npmjs.com/~${username}`,
        title: name,
        caption: clean(doc.description ?? version.description),
        author: username,
        datetime: time[latest] ?? time.modified ?? '',
        media_type: 'package',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
        name,
        version: latest,
        description: clean(doc.description ?? version.description),
        license: String(version.license ?? doc.license ?? ''),
        homepage: doc.homepage ?? '',
        repository: String(doc.repository?.url ?? version.repository?.url ?? '').replace(/^git\+/, '').replace(/\.git$/, ''),
        keywords: Array.isArray(doc.keywords) ? doc.keywords.join(', ') : (Array.isArray(version.keywords) ? version.keywords.join(', ') : ''),
        latest_version: latest,
        created_at: time.created ?? '',
        modified_at: time.modified ?? '',
        versions_count: doc.versions ? Object.keys(doc.versions).length : 0,
        maintainers: maintainers.map((maintainer: any) => maintainer?.name ?? '').filter(Boolean).join(', '),
        maintainers_count: maintainers.length,
        dependencies_count: version.dependencies ? Object.keys(version.dependencies).length : 0,
      };
    }).filter((item) => item.url);

    const next = offset + slice.length;
    return { items, next_cursor: items.length && next < names.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
