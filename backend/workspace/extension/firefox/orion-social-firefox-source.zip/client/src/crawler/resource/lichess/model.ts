export interface GamesCursor {
  until: number;
  id: string;
}
