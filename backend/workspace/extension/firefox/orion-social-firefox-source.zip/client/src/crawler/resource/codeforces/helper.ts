import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://codeforces.com/api/${path}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return null;
    }
    const data = JSON.parse(response.body);
    return data?.status === 'OK' ? data.result : null;
  }
  catch {
    return null;
  }
}

export function fromOf(payload: CrawlPayload): number {
  const from = Number(String(payload.cursor ?? '').trim());
  return Number.isFinite(from) && from >= 1 ? Math.floor(from) : 1;
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
}
