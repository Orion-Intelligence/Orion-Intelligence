import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';

export class BaiduTieba implements Crawler {
  readonly platform = 'baidutieba';
  readonly base = 'https://tieba.baidu.com';
  readonly loginUrl = 'https://passport.baidu.com/v2/?login';
  readonly authwall = { ...NO_AUTH, details: true };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(_type: CrawlType, _payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    return { items: [] };
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://tieba.baidu.com/home/main?un=${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;

      const displayName = embedded('name_show') || embedded('user_name') || embedded('name');
      if (!displayName || /安全验证/.test(html)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: embedded('intro') || meta('description'),
        description: embedded('intro') || meta('description'),
        location: '',
        profile_url: `https://tieba.baidu.com/home/main?un=${encodeURIComponent(username)}`,
        total_posts: String((number('post_num')) || ''),
        total_followers: String((number('fans_num') || number('followed_count')) || ''),
        total_likes: '',
        avatar: (embedded('portrait') ? `https://himg.bdimg.com/sys/portrait/item/${embedded('portrait')}` : '') || meta('og:image'),
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username: embedded('user_name') || username,
        userId: embedded('user_id') || embedded('id'),
        gender: embedded('sex') || embedded('gender'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://passport.baidu.com/v2/api/?logincheck', { credentials: 'include' });
      if (!response.ok) {
        return false;
      }

      const body = await response.text();
      return /"isLogin"\s*:\s*"?1|"is_login"\s*:\s*1/.test(body);
    }
    catch {
      return false;
    }
  }
}
