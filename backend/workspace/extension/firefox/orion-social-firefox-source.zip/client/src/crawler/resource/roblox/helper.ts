import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { GAME_PAGE_SIZES } from './constant';

export async function api(tab: TabController, url: string): Promise<any> {
  try {
    const response = await tab.fetch(url, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export async function userId(tab: TabController, username: string): Promise<string> {
  if (/^\d+$/.test(username)) {
    return username;
  }

  try {
    const response = await tab.fetch('https://users.roblox.com/v1/usernames/users', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernames: [username], excludeBannedUsers: false }),
    });
    return response.ok ? String(JSON.parse(response.body)?.data?.[0]?.id ?? '') : '';
  }
  catch {
    return '';
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function gamePageSize(payload: CrawlPayload): number {
  const limit = limitOf(payload, 25, 50);
  return GAME_PAGE_SIZES.find((size) => size >= limit) ?? 50;
}

export function groupOffset(payload: CrawlPayload): number {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return 0;
  }

  try {
    const parsed: any = raw.startsWith('{') ? JSON.parse(raw) : { offset: raw };
    const offset = Math.floor(Number(parsed?.offset));
    return Number.isFinite(offset) && offset > 0 ? offset : 0;
  }
  catch {
    return 0;
  }
}
