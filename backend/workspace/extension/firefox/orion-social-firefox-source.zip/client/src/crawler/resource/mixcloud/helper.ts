import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { API } from './constant';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`${API}${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function withLimit(path: string, limit: number): string {
  const url = new URL(path, API);
  url.searchParams.set('limit', String(limit));
  return `${url.pathname}${url.search}`;
}

export function pagedPath(path: string, payload: CrawlPayload): string {
  const limit = limitOf(payload, 25, 100);
  const cursor = String(payload.cursor ?? '').trim();
  if (cursor) {
    try {
      const url = new URL(cursor, API);
      if (url.origin === API && url.pathname.startsWith('/')) {
        return withLimit(`${url.pathname}${url.search}`, limit);
      }
    }
    catch {
    }
  }
  return withLimit(path, limit);
}

export function page(items: social_resource[], data: any, payload: CrawlPayload): CrawlPage {
  let next = '';
  try {
    const raw = String(data?.paging?.next ?? '').trim();
    if (raw) {
      const url = new URL(raw, API);
      if (url.origin === API) {
        next = `${url.pathname}${url.search}`;
      }
    }
  }
  catch {
    next = '';
  }
  const received = String(payload.cursor ?? '').trim();
  return { items, next_cursor: items.length && next && next !== received ? next : undefined };
}

export function picture(pictures: any): string {
  return pictures?.extra_large ?? pictures?.['640wx640h'] ?? pictures?.large ?? pictures?.medium ?? '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function person(username: string, type: 'followers' | 'friends', entry: any): social_resource {
  return {
    type,
    resource_id: entry.key ?? '',
    url: entry.url ?? '',
    parent_url: `https://www.mixcloud.com/${username}/`,
    title: entry.name ?? entry.username ?? '',
    caption: clean(entry.biog).slice(0, 600),
    author: entry.username ?? '',
    datetime: entry.created_time ?? '',
    media_type: 'user',
    media_url: entry.url ?? '',
    thumbnail_url: picture(entry.pictures),
    likes: '',
    shares: '',
    views: '',
    user_key: entry.key ?? '',
    username: entry.username ?? '',
    name: entry.name ?? '',
    biog: clean(entry.biog),
    city: entry.city ?? '',
    country: entry.country ?? '',
    cloudcast_count: entry.cloudcast_count ?? 0,
    favorite_count: entry.favorite_count ?? 0,
    follower_count: entry.follower_count ?? 0,
    listen_count: entry.listen_count ?? 0,
    is_pro: entry.is_pro ?? false,
    is_premium: entry.is_premium ?? false,
    is_select: entry.is_select ?? false,
    picture: picture(entry.pictures),
    picture_medium: entry.pictures?.medium ?? '',
    cover_picture: picture(entry.cover_pictures),
    created_time: entry.created_time ?? '',
    updated_time: entry.updated_time ?? '',
  };
}
