export interface Listing {
  items: any[];
  after: string;
}
