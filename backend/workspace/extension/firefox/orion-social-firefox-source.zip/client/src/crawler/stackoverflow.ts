import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, comments, connections, posts } from './resource/stackoverflow/stackoverflow';

export class StackOverflow implements Crawler {
  readonly platform = 'stackoverflow';
  readonly base = 'https://stackoverflow.com';
  readonly loginUrl = 'https://stackoverflow.com/users/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.stackexchange.com/2.3/users/${username}?site=stackoverflow`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = Array.isArray(payload?.items) ? payload.items[0] : null;
      if (!data) {
        return [];
      }

      const collectives: any[] = Array.isArray(data.collectives) ? data.collectives : [];

      return [{
        real_name: data.display_name ?? '',
        bio: String(data.about_me ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        description: String(data.about_me ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        location: data.location ?? '',
        profile_url: data.link ?? url ?? '',
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.profile_image ?? '',
        banner: '',
        crawl_type: ['details', 'answers', 'posts', 'comments', 'connections'],
        platform: this.platform,
        username: String(data.user_id ?? username),
        user_id: data.user_id ?? 0,
        account_id: data.account_id ?? 0,
        display_name: data.display_name ?? '',
        user_type: data.user_type ?? '',
        is_employee: data.is_employee ?? false,
        reputation: data.reputation ?? 0,
        reputation_change_day: data.reputation_change_day ?? 0,
        reputation_change_week: data.reputation_change_week ?? 0,
        reputation_change_month: data.reputation_change_month ?? 0,
        reputation_change_quarter: data.reputation_change_quarter ?? 0,
        reputation_change_year: data.reputation_change_year ?? 0,
        gold_badges: data.badge_counts?.gold ?? 0,
        silver_badges: data.badge_counts?.silver ?? 0,
        bronze_badges: data.badge_counts?.bronze ?? 0,
        accept_rate: data.accept_rate ?? 0,
        website: data.website_url ?? '',
        collectives: collectives.map((c: any) => c.collective?.name ?? c.collective?.slug ?? '').filter(Boolean).join(', '),
        collectives_count: collectives.length,
        created_at: data.creation_date ? new Date(data.creation_date * 1000).toISOString() : '',
        last_access_at: data.last_access_date ? new Date(data.last_access_date * 1000).toISOString() : '',
        last_modified_at: data.last_modified_date ? new Date(data.last_modified_date * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://stackoverflow.com/users/current', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return /\/users\/\d+\//.test(response.url);
    }
    catch {
      return false;
    }
  }
}
