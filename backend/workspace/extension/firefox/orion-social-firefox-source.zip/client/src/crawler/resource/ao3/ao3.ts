import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';

const EMPTY: CrawlPage = { items: [] };

function text(node: Element | null): string {
  return (node?.textContent ?? '').replace(/\s+/g, ' ').trim();
}

function num(value: string): string {
  return value.replace(/[^\d]/g, '');
}

function worksUrl(username: string, page: number): string {
  return `https://archiveofourown.org/users/${encodeURIComponent(username)}/works?page=${page}`;
}

function parseWorks(html: string, username: string): social_resource[] {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return Array.from(doc.querySelectorAll('li[id^="work_"]')).map((work): social_resource => {
    const titleLink = work.querySelector('h4.heading a[href^="/works/"]');
    const path = titleLink?.getAttribute('href') ?? '';
    const authors = Array.from(work.querySelectorAll('h4.heading a[rel="author"]')).map((author) => text(author)).filter(Boolean);
    const fandoms = Array.from(work.querySelectorAll('h5.fandoms a.tag')).map((tag) => text(tag)).filter(Boolean);
    const tags = Array.from(work.querySelectorAll('ul.tags li a.tag')).map((tag) => text(tag)).filter(Boolean);
    const stat = (selector: string): string => num(text(work.querySelector(`dl.stats dd.${selector}`)));
    return {
      type: 'posts',
      resource_id: (work.getAttribute('id') ?? '').replace('work_', ''),
      url: path ? `https://archiveofourown.org${path}` : '',
      parent_url: `https://archiveofourown.org/users/${username}`,
      title: text(titleLink),
      caption: text(work.querySelector('blockquote.userstuff.summary')),
      author: authors.join(', ') || username,
      datetime: text(work.querySelector('.datetime')),
      media_type: 'work',
      media_url: '',
      thumbnail_url: '',
      likes: stat('kudos'),
      shares: stat('bookmarks'),
      views: stat('hits'),
      content: text(work.querySelector('blockquote.userstuff.summary')),
      fandoms: fandoms.join(', '),
      rating: text(work.querySelector('.required-tags .rating .text')),
      warnings: text(work.querySelector('.required-tags .warnings .text')),
      category: text(work.querySelector('.required-tags .category .text')),
      tags: tags.join(', '),
      language: text(work.querySelector('dl.stats dd.language')),
      words: stat('words'),
      chapters: text(work.querySelector('dl.stats dd.chapters')),
      comments: stat('comments'),
      kudos: stat('kudos'),
      bookmarks: stat('bookmarks'),
      hits: stat('hits'),
    };
  }).filter((item) => item.url);
}

function hasNext(html: string): boolean {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const next = doc.querySelector('.pagination .next a, ol.pagination li.next a');
  return Boolean(next);
}

function worksTotal(html: string): number {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const heading = text(doc.querySelector('#main h2.heading'));
  const match = /([\d,]+)\s+Work/i.exec(heading);
  return match ? Number(match[1].replace(/,/g, '')) : 0;
}

export async function details(username: string): Promise<social_profile_details[]> {
  const tab = await openSession('https://archiveofourown.org/');
  if (!tab) {
    return [];
  }
  try {
    const response = await tab.fetch(worksUrl(username, 1));
    const html = response.body ?? '';
    const works = parseWorks(html, username);
    if (!works.length) {
      return [];
    }
    const total = worksTotal(html) || works.length;
    return [{
      real_name: username,
      bio: '',
      description: '',
      location: '',
      profile_url: `https://archiveofourown.org/users/${username}`,
      total_posts: String(total || ''),
      total_followers: '',
      total_likes: '',
      avatar: '',
      banner: '',
      crawl_type: ['details', 'posts'],
      platform: 'ao3',
      username: username,
      works_count: total,
    }];
  }
  catch {
    return [];
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  const rawPage = Math.floor(Number(String(payload.cursor ?? '').trim()));
  const page = Number.isFinite(rawPage) && rawPage > 1 ? rawPage : 1;
  const tab = await openSession('https://archiveofourown.org/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const response = await tab.fetch(worksUrl(username, page));
    const html = response.body ?? '';
    const items = parseWorks(html, username);
    if (!items.length) {
      return EMPTY;
    }
    return { items, next_cursor: hasNext(html) ? String(page + 1) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
