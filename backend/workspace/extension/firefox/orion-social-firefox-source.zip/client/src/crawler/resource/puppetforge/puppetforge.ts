import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function modules(username: string, offset: number, limit: number): Promise<any> {
  const response = await fetch(`https://forgeapi.puppet.com/v3/modules?owner=${encodeURIComponent(username)}&limit=${limit}&offset=${offset}&sort_by=downloads`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function ownerTotal(username: string): Promise<number> {
  const data = await modules(username, 0, 1);
  return Number(data?.pagination?.total ?? 0);
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await modules(username, offset, limit);
    const total = Number(data?.pagination?.total ?? 0);
    const results: any[] = Array.isArray(data?.results) ? data.results : [];
    if (!results.length) {
      return EMPTY;
    }

    const items = results.map((module: any): social_resource => {
      const slug = String(module.slug ?? '');
      const name = String(module.name ?? slug);
      const release = module.current_release ?? {};
      const metadata = release.metadata ?? {};
      const owner = module.owner ?? {};
      return {
        type: 'repositories',
        resource_id: slug,
        url: `https://forge.puppet.com/modules/${String(owner.username ?? username)}/${name}`,
        parent_url: `https://forge.puppet.com/${String(owner.username ?? username)}`,
        title: slug || name,
        caption: clean(metadata.summary),
        author: String(owner.username ?? username),
        datetime: module.updated_at ?? module.created_at ?? '',
        media_type: 'module',
        media_url: '',
        thumbnail_url: '',
        likes: String((module.feedback_score ?? 0) || ''),
        shares: '',
        views: String((module.downloads ?? 0) || ''),
        name,
        description: clean(metadata.summary),
        version: release.version ?? '',
        license: metadata.license ?? '',
        source: metadata.source ?? '',
        project_page: metadata.project_page ?? module.homepage_url ?? '',
        issues_url: module.issues_url ?? '',
        homepage_url: module.homepage_url ?? '',
        downloads: module.downloads ?? 0,
        feedback_score: module.feedback_score ?? 0,
        supported: Boolean(module.supported),
        endorsement: module.endorsement ?? '',
        deprecated_at: module.deprecated_at ?? '',
        created_at: module.created_at ?? '',
        updated_at: module.updated_at ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + results.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
