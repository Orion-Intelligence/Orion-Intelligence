import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, posts } from './resource/leetcode/leetcode';

export class LeetCode implements Crawler {
  readonly platform = 'leetcode';
  readonly base = 'https://leetcode.com';
  readonly loginUrl = 'https://leetcode.com/accounts/login/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const query = 'query($u:String!){matchedUser(username:$u){username githubUrl twitterUrl linkedinUrl contestBadge{name} profile{realName aboutMe countryName company school websites userAvatar reputation ranking skillTags postViewCount solutionCount categoryDiscussCount} submitStats{acSubmissionNum{difficulty count} totalSubmissionNum{difficulty count}}}}';
      const response = await fetch(`https://leetcode.com/graphql`, { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ query, variables: { u: username } }) });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload?.data?.matchedUser;
      if (!data?.username) {
        return [];
      }

      const profile: any = data.profile ?? {};
      const ac: any[] = Array.isArray(data.submitStats?.acSubmissionNum) ? data.submitStats.acSubmissionNum : [];
      const byDiff = (list: any[], diff: string) => list.find((x: any) => x.difficulty === diff)?.count ?? 0;
      const websites: string[] = Array.isArray(profile.websites) ? profile.websites : [];
      const skills: string[] = Array.isArray(profile.skillTags) ? profile.skillTags : [];

      return [{
        real_name: profile.realName || data.username,
        bio: profile.aboutMe ?? '',
        description: profile.aboutMe ?? '',
        location: profile.countryName ?? '',
        profile_url: `https://leetcode.com/${data.username ?? username}/`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: profile.userAvatar ?? '',
        banner: '',
        crawl_type: ['details', 'answers', 'posts'],
        platform: this.platform,
        username: data.username ?? username,
        country: profile.countryName ?? '',
        company: profile.company ?? '',
        school: profile.school ?? '',
        github_url: data.githubUrl ?? '',
        twitter_url: data.twitterUrl ?? '',
        linkedin_url: data.linkedinUrl ?? '',
        websites: websites.join(', '),
        skill_tags: skills.join(', '),
        contest_badge: data.contestBadge?.name ?? '',
        ranking: profile.ranking ?? 0,
        reputation: profile.reputation ?? 0,
        post_view_count: profile.postViewCount ?? 0,
        solution_count: profile.solutionCount ?? 0,
        discuss_count: profile.categoryDiscussCount ?? 0,
        solved_total: byDiff(ac, 'All'),
        solved_easy: byDiff(ac, 'Easy'),
        solved_medium: byDiff(ac, 'Medium'),
        solved_hard: byDiff(ac, 'Hard'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://leetcode.com/api/problems/all/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user_name);
    }
    catch {
      return false;
    }
  }
}
