export interface BandcampCursor {
  band_id: number;
  offset: number;
  skip: number;
}
