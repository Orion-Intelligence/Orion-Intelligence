import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { comments, posts } from './resource/wordpresscom/wordpresscom';

export class WordPressCom implements Crawler {
  readonly platform = 'wordpresscom';
  readonly base = 'https://wordpress.com';
  readonly loginUrl = 'https://wordpress.com/log-in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'comments':
        return comments(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://public-api.wordpress.com/rest/v1.1/sites/${encodeURIComponent(username.includes('.') ? username : `${username}.wordpress.com`)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.ID) {
        return [];
      }

      return [{
        real_name: data.name ?? username,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: '',
        profile_url: `${data.URL ?? `https://${username}.wordpress.com`}`,
        total_posts: String((data.post_count ?? 0) || ''),
        total_followers: String((data.subscribers_count ?? 0) || ''),
        total_likes: '',
        avatar: data.logo?.url ?? data.icon?.img ?? '',
        banner: '',
        crawl_type: ['details', 'posts', 'comments'],
        platform: this.platform,
        username: String(data.ID ?? username),
        site_id: data.ID ?? 0,
        site_name: data.name ?? '',
        site_url: data.URL ?? '',
        subscribers_count: data.subscribers_count ?? 0,
        post_count: data.post_count ?? 0,
        language: (data.lang && data.lang !== false) ? data.lang : '',
        icon: data.icon?.img ?? '',
        logo: data.logo?.url ?? '',
        is_private: data.is_private ?? false,
        is_coming_soon: data.is_coming_soon ?? false,
        visible: data.visible ?? true,
        organization_id: data.organization_id ?? 0,
        jetpack: data.jetpack ?? false,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://public-api.wordpress.com/rest/v1.1/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.ID);
    }
    catch {
      return false;
    }
  }
}
