export interface Cursor {
  offset: number | null;
  skip: number;
  rss: string[];
  done: string[];
}
