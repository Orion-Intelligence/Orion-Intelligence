import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, friends, posts, reviews } from './resource/anilist/anilist';

export class AniList implements Crawler {
  readonly platform = 'anilist';
  readonly base = 'https://anilist.co';
  readonly loginUrl = 'https://anilist.co/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'reviews':
        return reviews(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch('https://graphql.anilist.co', {
        method: 'POST',
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: 'query ($name: String) { User(name: $name) { id name about siteUrl donatorTier donatorBadge unreadNotificationCount createdAt updatedAt avatar { large medium } bannerImage options { profileColor timezone activityMergeTime displayAdultContent } statistics { anime { count minutesWatched episodesWatched meanScore standardDeviation genres { genre count } } manga { count chaptersRead volumesRead meanScore } } } }',
          variables: { name: username },
        }),
      });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload?.data?.User;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.name ?? username,
        bio: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        description: String(data.about ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        location: '',
        profile_url: data.siteUrl ?? `https://anilist.co/user/${data.name ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.avatar?.large ?? '',
        banner: data.bannerImage ?? '',
        crawl_type: ['details', 'posts', 'reviews', 'followers', 'friends'],
        platform: this.platform,
        username: data.name ?? username,
        id: data.id ?? 0,
        donator_tier: data.donatorTier ?? 0,
        donator_badge: data.donatorBadge ?? '',
        profile_color: data.options?.profileColor ?? '',
        timezone: data.options?.timezone ?? '',
        anime_count: data.statistics?.anime?.count ?? 0,
        anime_minutes_watched: data.statistics?.anime?.minutesWatched ?? 0,
        anime_episodes_watched: data.statistics?.anime?.episodesWatched ?? 0,
        anime_mean_score: data.statistics?.anime?.meanScore ?? 0,
        manga_count: data.statistics?.manga?.count ?? 0,
        manga_chapters_read: data.statistics?.manga?.chaptersRead ?? 0,
        manga_volumes_read: data.statistics?.manga?.volumesRead ?? 0,
        manga_mean_score: data.statistics?.manga?.meanScore ?? 0,
        top_genres: (Array.isArray(data.statistics?.anime?.genres) ? data.statistics.anime.genres : []).slice(0, 5).map((g: any) => g.genre).filter(Boolean).join(', '),
        created_at: data.createdAt ? new Date(data.createdAt * 1000).toISOString() : '',
        updated_at: data.updatedAt ? new Date(data.updatedAt * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://graphql.anilist.co', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.data?.Viewer?.id);
    }
    catch {
      return false;
    }
  }
}
