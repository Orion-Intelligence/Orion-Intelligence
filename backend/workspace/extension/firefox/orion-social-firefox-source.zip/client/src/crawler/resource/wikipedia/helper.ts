import { CrawlPayload } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function origin(payload: CrawlPayload): string {
  return /^https?:\/\/[^/]+/.exec(payload.url ?? '')?.[0] ?? 'https://en.wikipedia.org';
}

export async function api(tab: TabController, base: string, params: Record<string, string>): Promise<any> {
  try {
    const query = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params });
    const response = await tab.fetch(`${base}/w/api.php?${query.toString()}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}
