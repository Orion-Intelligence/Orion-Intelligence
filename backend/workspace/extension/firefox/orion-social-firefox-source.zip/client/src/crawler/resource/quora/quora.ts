import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { decode } from './helper';

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.quora.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    await tab.navigate(`https://www.quora.com/profile/${encodeURIComponent(username)}/answers`);
    await tab.scrollLoad(15);
    const html = await tab.html();
    if (!html) {
      return { items: [] };
    }

    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const match of html.matchAll(/href="(?:https:\/\/www\.quora\.com)?(\/[^"]*\/answer\/[^"?#]+)"/g)) {
      const path = match[1];
      if (seen.has(path)) {
        continue;
      }
      seen.add(path);
      items.push({
        type: 'answers',
        resource_id: path,
        url: `https://www.quora.com${path}`,
        parent_url: `https://www.quora.com/profile/${username}`,
        title: decode(path.split('/answer/')[0].replace(/^\//, '').replace(/-/g, ' ')),
        caption: '',
        author: username,
        datetime: '',
        media_type: 'answer',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
      });
    }
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
