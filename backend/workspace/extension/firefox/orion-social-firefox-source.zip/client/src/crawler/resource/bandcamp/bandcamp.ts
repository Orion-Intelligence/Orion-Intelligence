import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { EMPTY, MAX_TRALBUMS_PER_PAGE } from './constant';
import { BandcampCursor } from './model';
import { api, art, bandId, clean, decode, discography, nextCursor, parseCursor, subdomain, tralbum } from './helper';

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const host = subdomain(payload);
    const cursor = parseCursor(payload);
    const { id, band, list } = await discography(payload, cursor);
    if (!id) {
      return EMPTY;
    }

    const limit = limitOf(payload, 25, 100);
    const slice = list.slice(cursor.offset, cursor.offset + limit) as any[];
    const fulls = await Promise.all(slice.map((item: any) => tralbum(id, item)));

    const items = slice.map((item: any, index: number): social_resource => {
      const full: any = fulls[index] ?? {};
      const tracks: any[] = Array.isArray(full.tracks) ? full.tracks : [];
      const tags: any[] = Array.isArray(full.tags) ? full.tags : [];
      return {
        type: 'albums',
        resource_id: String(item.item_id ?? ''),
        url: full.bandcamp_url ?? '',
        parent_url: `https://${host}.bandcamp.com`,
        title: item.title ?? '',
        caption: clean(full.about).slice(0, 1000),
        author: item.band_name ?? band?.name ?? host,
        datetime: item.release_date ?? '',
        media_type: item.item_type ?? 'album',
        media_url: tracks[0]?.streaming_url?.['mp3-128'] ?? '',
        thumbnail_url: art(item.art_id),
        likes: '',
        shares: '',
        views: '',
        album_id: item.item_id ?? 0,
        item_type: item.item_type ?? '',
        band_id: item.band_id ?? id,
        band_name: item.band_name ?? band?.name ?? '',
        artist_name: full.tralbum_artist ?? item.artist_name ?? '',
        album_title: full.album_title ?? item.title ?? '',
        about: clean(full.about),
        credits: clean(full.credits),
        release_date: item.release_date ?? '',
        release_timestamp: full.release_date ?? 0,
        art_id: item.art_id ?? 0,
        art_url: art(item.art_id),
        tracks_count: tracks.length,
        track_titles: tracks.map((track: any) => track?.title ?? '').filter(Boolean).join(' | '),
        track_ids: tracks.map((track: any) => track?.track_id ?? '').filter(Boolean).join(', '),
        duration_seconds: Math.round(tracks.reduce((sum: number, track: any) => sum + (Number(track?.duration) || 0), 0)),
        featured_track_id: full.featured_track_id ?? 0,
        tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        tags_normalized: tags.map((tag: any) => tag?.norm_name ?? '').filter(Boolean).join(', '),
        location_tags: tags.filter((tag: any) => tag?.isloc).map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        label: full.label ?? '',
        label_id: full.label_id ?? 0,
        currency: full.currency ?? '',
        price: full.price ?? 0,
        is_set_price: full.is_set_price ?? false,
        is_purchasable: item.is_purchasable ?? full.is_purchasable ?? false,
        is_preorder: full.is_preorder ?? false,
        free_download: full.free_download ?? false,
        has_digital_download: full.has_digital_download ?? false,
        downloadable_tracks: full.num_downloadable_tracks ?? 0,
        merch_sold_out: full.merch_sold_out ?? false,
        streaming_limit: full.streaming_limit ?? 0,
        require_email: full.require_email ?? false,
        band_location: band?.location ?? '',
        band_bio: clean(band?.bio).slice(0, 500),
        band_url: band?.bandcamp_url ?? '',
      };
    }).filter((item) => item.url);

    const next: BandcampCursor = { band_id: id, offset: cursor.offset + slice.length, skip: 0 };
    return { items, next_cursor: nextCursor(next, list.length, slice.length) };
  }
  catch {
    return EMPTY;
  }
}

export async function tracks(payload: CrawlPayload): Promise<CrawlPage> {
  try {
    const host = subdomain(payload);
    const cursor = parseCursor(payload);
    const { id, band, list } = await discography(payload, cursor);
    if (!id) {
      return EMPTY;
    }

    const limit = limitOf(payload, 25, 100);
    const items: social_resource[] = [];
    let offset = cursor.offset;
    let skip = cursor.skip;
    let consumed = 0;
    let fetched = 0;

    while (consumed < limit && offset < list.length && fetched < MAX_TRALBUMS_PER_PAGE) {
      const parent: any = list[offset] ?? {};
      const full: any = await tralbum(id, parent);
      fetched += 1;

      const all: any[] = Array.isArray(full?.tracks) ? full.tracks : [];
      const page = all.slice(skip, skip + (limit - consumed));
      page.forEach((track: any) => {
        items.push({
          type: 'tracks',
          resource_id: String(track.track_id ?? ''),
          url: track.track_url ?? '',
          parent_url: full?.bandcamp_url ?? `https://${host}.bandcamp.com`,
          title: track.title ?? '',
          caption: full?.album_title ?? parent.title ?? '',
          author: track.band_name ?? band?.name ?? host,
          datetime: parent.release_date ?? '',
          media_type: 'track',
          media_url: track.streaming_url?.['mp3-128'] ?? '',
          thumbnail_url: art(track.art_id ?? parent.art_id),
          likes: '',
          shares: '',
          views: '',
          track_id: track.track_id ?? 0,
          track_number: track.track_num ?? 0,
          track_title: track.title ?? '',
          album_id: track.album_id ?? parent.item_id ?? 0,
          album_title: full?.album_title ?? parent.title ?? '',
          album_url: full?.bandcamp_url ?? '',
          band_id: track.band_id ?? id,
          band_name: track.band_name ?? band?.name ?? '',
          duration: Math.round(Number(track.duration) || 0),
          stream_url: track.streaming_url?.['mp3-128'] ?? '',
          is_streamable: track.is_streamable ?? false,
          has_lyrics: track.has_lyrics ?? false,
          lyrics: clean(track.lyrics).slice(0, 2000),
          price: track.price ?? 0,
          currency: track.currency ?? '',
          is_set_price: track.is_set_price ?? false,
          is_purchasable: track.is_purchasable ?? false,
          has_digital_download: track.has_digital_download ?? false,
          require_email: track.require_email ?? false,
          merch_sold_out: track.merch_sold_out ?? false,
          label: track.label ?? '',
          label_id: track.label_id ?? 0,
          encodings_id: track.encodings_id ?? 0,
          license_id: track.track_license_id ?? 0,
          art_id: track.art_id ?? parent.art_id ?? 0,
          release_date: parent.release_date ?? '',
          band_location: band?.location ?? '',
        });
      });

      consumed += page.length;
      skip += page.length;
      if (skip >= all.length) {
        offset += 1;
        skip = 0;
      }
    }

    const next: BandcampCursor = { band_id: id, offset, skip };
    return { items: items.filter((item) => item.url), next_cursor: nextCursor(next, list.length, consumed) };
  }
  catch {
    return EMPTY;
  }
}
