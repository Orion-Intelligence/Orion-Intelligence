import { CrawlPage, CrawlPayload, social_profile_details, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };
const HOST = 'https://discoveryprovider.audius.co';
const APP = 'orion';

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function artwork(entry: any): string {
  const art = entry?.artwork ?? entry?.cover_photo ?? entry?.profile_picture ?? {};
  return art?.['480x480'] ?? art?.['150x150'] ?? art?.['1000x1000'] ?? '';
}

export async function userByHandle(handle: string): Promise<any> {
  const clean = handle.replace(/^@/, '').trim();
  const response = await fetch(`${HOST}/v1/users/handle/${encodeURIComponent(clean)}?app_name=${APP}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  return data?.data ?? null;
}

export async function details(handle: string): Promise<social_profile_details[]> {
  const user = await userByHandle(handle);
  if (!user) {
    return [];
  }

  return [{
    real_name: clean(user.name) || user.handle,
    bio: clean(user.bio),
    description: clean(user.bio),
    location: clean(user.location),
    profile_url: `https://audius.co/${user.handle}`,
    total_posts: String((user.track_count ?? 0) || ''),
    total_followers: String((user.follower_count ?? 0) || ''),
    total_likes: '',
    avatar: artwork({ profile_picture: user.profile_picture }),
    banner: artwork({ cover_photo: user.cover_photo }),
    crawl_type: ['details', 'tracks'],
    platform: 'audius',
    username: user.handle,
    track_count: user.track_count ?? 0,
    album_count: user.album_count ?? 0,
    playlist_count: user.playlist_count ?? 0,
    follower_count: user.follower_count ?? 0,
    followee_count: user.followee_count ?? 0,
    is_verified: Boolean(user.is_verified),
    audius_id: user.id ?? '',
  }];
}

export async function tracks(payload: CrawlPayload): Promise<CrawlPage> {
  const handle = String(payload.username ?? '');
  if (!handle) {
    return EMPTY;
  }

  try {
    const user = await userByHandle(handle);
    const id = user?.id;
    if (!id) {
      return EMPTY;
    }

    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const response = await fetch(`${HOST}/v1/users/${encodeURIComponent(id)}/tracks?app_name=${APP}&limit=${limit}&offset=${offset}&sort=date`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }
    const data = await response.json();
    const rows: any[] = Array.isArray(data?.data) ? data.data : [];
    if (!rows.length) {
      return EMPTY;
    }

    const items = rows.map((track: any): social_resource => {
      const permalink = track.permalink ?? '';
      return {
        type: 'tracks',
        resource_id: String(track.id ?? ''),
        url: permalink ? `https://audius.co${permalink}` : `https://audius.co/${user.handle}`,
        parent_url: `https://audius.co/${user.handle}`,
        title: clean(track.title),
        caption: clean(track.description),
        author: user.handle,
        datetime: track.release_date ?? track.created_at ?? '',
        media_type: 'track',
        media_url: `${HOST}/v1/tracks/${track.id}/stream?app_name=${APP}`,
        thumbnail_url: artwork(track),
        likes: String((track.favorite_count ?? 0) || ''),
        shares: String((track.repost_count ?? 0) || ''),
        views: String((track.play_count ?? 0) || ''),
        name: clean(track.title),
        description: clean(track.description),
        genre: track.genre ?? '',
        mood: track.mood ?? '',
        duration: track.duration ?? 0,
        play_count: track.play_count ?? 0,
        favorite_count: track.favorite_count ?? 0,
        repost_count: track.repost_count ?? 0,
        comment_count: track.comment_count ?? 0,
        release_date: track.release_date ?? '',
        is_downloadable: Boolean(track.is_downloadable ?? track.downloadable),
        tags: clean(track.tags),
      };
    }).filter((item) => item.url);

    const next = offset + rows.length;
    return { items, next_cursor: items.length && rows.length >= limit ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
