export interface Cursor {
  page: number;
  id: number;
}

export interface ApiPage {
  list: any[];
  next?: string;
}
