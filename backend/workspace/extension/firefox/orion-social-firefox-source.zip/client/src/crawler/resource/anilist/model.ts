export interface Cursor { p: number; id: number }
