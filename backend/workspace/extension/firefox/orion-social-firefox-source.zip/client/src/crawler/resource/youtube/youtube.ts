import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { channelUrl, collect, commentAuthors, commentInitialToken, commentNextToken, decodeCursor, encodeCursor, feed, metaParts, next, number, page, runs, video, watchPage, widest } from './helper';

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const videoUrl = String(payload.url ?? '');
  const videoId = /[?&]v=([\w-]+)/.exec(videoUrl)?.[1] ?? /\/shorts\/([\w-]+)/.exec(videoUrl)?.[1] ?? /youtu\.be\/([\w-]+)/.exec(videoUrl)?.[1] ?? '';
  const watchUrl = videoId ? `https://www.youtube.com/watch?v=${videoId}` : videoUrl;
  if (!watchUrl) {
    return { items: [] };
  }
  const session = await openSession('https://www.youtube.com/');
  if (!session) {
    return { items: [] };
  }
  try {
    const state = decodeCursor(String(payload.cursor ?? '') || undefined);
    let token = '';
    let apiKey = '';
    let clientVersion = '';
    if (state) {
      token = state.t;
      apiKey = state.k;
      clientVersion = state.v;
    }
    else {
      const { data, html } = await watchPage(session, watchUrl);
      apiKey = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(html)?.[1] ?? '';
      clientVersion = /"clientVersion":"([0-9.]+)"/.exec(html)?.[1] ?? '';
      token = commentInitialToken(data);
    }
    if (!token || !apiKey || !clientVersion) {
      return { items: [] };
    }
    const data = await next(session, apiKey, clientVersion, token);
    if (!data) {
      return { items: [] };
    }
    const items: social_resource[] = commentAuthors(data).map((entry): social_resource => ({
      type: 'connections',
      resource_id: entry.channelId,
      url: `https://www.youtube.com/channel/${entry.channelId}`,
      parent_url: watchUrl,
      title: '',
      caption: entry.text,
      author: entry.name.replace(/^@/, ''),
      datetime: entry.time,
      media_type: 'user',
      media_url: entry.avatar,
      thumbnail_url: entry.avatar,
      likes: '',
      shares: '',
      views: '',
      comment_text: entry.text,
      handle: entry.name,
      channel_id: entry.channelId,
      published_text: entry.time,
    }));
    const nextTok = commentNextToken(data);
    return { items, next_cursor: items.length && nextTok ? encodeCursor({ t: nextTok, k: apiKey, v: clientVersion, c: videoId }) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const channel = channelUrl(payload);
  const session = channel ? await openSession('https://www.youtube.com/') : null;
  if (!session) {
    return { items: [] };
  }
  try {
    const { data, channelId, next, first } = await page(session, channel, 'videos', String(payload.cursor ?? '') || undefined);
    const stats = first ? await feed(session, channelId) : new Map<string, any>();
    const lockups = collect(data, 'lockupViewModel').filter((lockup: any) => String(lockup?.contentType ?? '').includes('VIDEO'));
    const items = lockups.map((lockup: any) => video('videos', channel, channelId, lockup, stats.get(String(lockup.contentId ?? '')))).filter((item) => item.resource_id);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}

export async function streams(payload: CrawlPayload): Promise<CrawlPage> {
  const channel = channelUrl(payload);
  const session = channel ? await openSession('https://www.youtube.com/') : null;
  if (!session) {
    return { items: [] };
  }
  try {
    const { data, channelId, next, first } = await page(session, channel, 'streams', String(payload.cursor ?? '') || undefined);
    const stats = first ? await feed(session, channelId) : new Map<string, any>();
    const lockups = collect(data, 'lockupViewModel').filter((lockup: any) => String(lockup?.contentType ?? '').includes('VIDEO'));
    const items = lockups.map((lockup: any) => video('streams', channel, channelId, lockup, stats.get(String(lockup.contentId ?? '')))).filter((item) => item.resource_id);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}

export async function shorts(payload: CrawlPayload): Promise<CrawlPage> {
  const channel = channelUrl(payload);
  const session = channel ? await openSession('https://www.youtube.com/') : null;
  if (!session) {
    return { items: [] };
  }
  try {
    const { data, channelId, next } = await page(session, channel, 'shorts', String(payload.cursor ?? '') || undefined);
    const lockups = collect(data, 'shortsLockupViewModel');
    const items = lockups.map((lockup: any): social_resource => {
      const id = collect(lockup, 'reelWatchEndpoint').map((endpoint: any) => endpoint?.videoId ?? '').filter(Boolean)[0] ?? String(lockup.entityId ?? '').replace('shorts-shelf-item-', '');
      const accessibility = String(lockup.accessibilityText ?? '');
      const primary = runs(lockup?.overlayMetadata?.primaryText);
      const secondary = runs(lockup?.overlayMetadata?.secondaryText);
      const thumbnails = collect(lockup, 'thumbnails').flat();
      return {
        type: 'shorts',
        resource_id: id,
        url: `https://www.youtube.com/shorts/${id}`,
        parent_url: channel,
        title: primary || accessibility.replace(/,\s*[\d.,KMB\s]+views?.*$/i, '').trim(),
        caption: '',
        author: '',
        datetime: '',
        media_type: 'short',
        media_url: `https://www.youtube.com/shorts/${id}`,
        thumbnail_url: widest(thumbnails) || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        likes: '',
        shares: '',
        views: String(number(secondary || accessibility) || ''),
        video_id: id,
        channel_id: channelId,
        entity_id: lockup.entityId ?? '',
        title_text: primary,
        views_text: secondary,
        views_count: number(secondary || accessibility),
        accessibility_text: accessibility,
        thumbnail_frame: `https://i.ytimg.com/vi/${id}/frame0.jpg`,
        thumbnail_default: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        thumbnail_source: widest(thumbnails),
        thumbnail_count: thumbnails.length,
        embed_url: `https://www.youtube.com/embed/${id}`,
        short_url: `https://youtu.be/${id}`,
      };
    }).filter((item) => item.resource_id);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const channel = channelUrl(payload);
  const session = channel ? await openSession('https://www.youtube.com/') : null;
  if (!session) {
    return { items: [] };
  }
  try {
    const { data, channelId, next } = await page(session, channel, 'playlists', String(payload.cursor ?? '') || undefined);
    const lockups = collect(data, 'lockupViewModel').filter((lockup: any) => String(lockup?.contentType ?? '').includes('PLAYLIST'));
    const items = lockups.map((lockup: any): social_resource => {
      const id = String(lockup.contentId ?? '');
      const parts = metaParts(lockup);
      const badges = collect(lockup, 'thumbnailBadgeViewModel').map((badge: any) => runs(badge?.text)).filter(Boolean);
      const images = collect(lockup?.contentImage, 'sources').flat();
      const overlay = collect(lockup, 'thumbnailOverlayBadgeViewModel').map((badge: any) => runs(badge?.text)).filter(Boolean);
      return {
        type: 'albums',
        resource_id: id,
        url: `https://www.youtube.com/playlist?list=${id}`,
        parent_url: channel,
        title: runs(lockup?.metadata?.lockupMetadataViewModel?.title),
        caption: parts.join(' | '),
        author: '',
        datetime: '',
        media_type: 'playlist',
        media_url: `https://www.youtube.com/playlist?list=${id}`,
        thumbnail_url: widest(images),
        likes: '',
        shares: '',
        views: String(number(parts.find((part: string) => /view/i.test(part)) ?? '') || ''),
        playlist_id: id,
        channel_id: channelId,
        title_text: runs(lockup?.metadata?.lockupMetadataViewModel?.title),
        content_type: lockup.contentType ?? '',
        video_count: number(badges.concat(overlay).find((badge: string) => /video|episode/i.test(badge)) ?? parts.find((part: string) => /video|episode/i.test(part)) ?? ''),
        badges: badges.concat(overlay).join(', '),
        metadata_parts: parts.join(' | '),
        updated_text: parts.find((part: string) => /updated|ago/i.test(part)) ?? '',
        thumbnail_source: widest(images),
        thumbnail_count: images.length,
        first_video_url: `https://www.youtube.com/watch?list=${id}`,
      };
    }).filter((item) => item.resource_id);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const channel = channelUrl(payload);
  const session = channel ? await openSession('https://www.youtube.com/') : null;
  if (!session) {
    return { items: [] };
  }
  try {
    const { data, next } = await page(session, channel, 'posts', String(payload.cursor ?? '') || undefined);
    const nodes = collect(data, 'backstagePostRenderer');
    const items = nodes.map((post: any): social_resource => {
      const text = runs(post.contentText);
      const links = (Array.isArray(post.contentText?.runs) ? post.contentText.runs : []).map((run: any) => run?.navigationEndpoint?.commandMetadata?.webCommandMetadata?.url ?? '').filter(Boolean);
      const attachment = post.backstageAttachment ?? {};
      const image = collect(attachment, 'thumbnails').flat();
      const video = attachment.videoRenderer ?? {};
      const poll = attachment.pollRenderer ?? {};
      const likeLabel = post.actionButtons?.commentActionButtonsRenderer?.likeButton?.toggleButtonRenderer?.accessibility?.label ?? '';
      return {
        type: 'posts',
        resource_id: post.postId ?? '',
        url: post.postId ? `https://www.youtube.com/post/${post.postId}` : '',
        parent_url: channel,
        title: '',
        caption: text,
        author: runs(post.authorText),
        datetime: runs(post.publishedTimeText),
        media_type: video.videoId ? 'video' : image.length ? 'image' : poll.choices ? 'poll' : 'text',
        media_url: video.videoId ? `https://www.youtube.com/watch?v=${video.videoId}` : widest(image),
        thumbnail_url: widest(image) || (video.videoId ? `https://i.ytimg.com/vi/${video.videoId}/hqdefault.jpg` : ''),
        likes: String(runs(post.voteCount) || ''),
        shares: '',
        views: '',
        post_id: post.postId ?? '',
        text,
        text_length: text.length,
        links: links.join(', '),
        links_count: links.length,
        published_text: runs(post.publishedTimeText),
        is_edited: /edited/i.test(runs(post.publishedTimeText)),
        vote_count_text: runs(post.voteCount),
        vote_count: number(runs(post.voteCount)),
        vote_label: post.voteCount?.accessibility?.accessibilityData?.label ?? '',
        like_label: likeLabel,
        like_exact: number(/([\d,]+)\s*other/i.exec(likeLabel)?.[1] ?? ''),
        author_name: runs(post.authorText),
        author_url: post.authorEndpoint?.commandMetadata?.webCommandMetadata?.url ? `https://www.youtube.com${post.authorEndpoint.commandMetadata.webCommandMetadata.url}` : '',
        author_channel_id: post.authorEndpoint?.browseEndpoint?.browseId ?? '',
        author_avatar: widest(collect(post.authorThumbnail, 'thumbnails').flat()),
        surface: post.surface ?? '',
        attachment_type: Object.keys(attachment)[0] ?? '',
        attachment_image: widest(image),
        attachment_images_count: image.length,
        attached_video_id: video.videoId ?? '',
        attached_video_title: runs(video.title),
        attached_video_views: runs(video.viewCountText),
        poll_choices: Array.isArray(poll.choices) ? poll.choices.map((choice: any) => runs(choice?.text)).filter(Boolean).join(' | ') : '',
        poll_votes: runs(poll.totalVotes),
      };
    }).filter((item) => item.url);
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await session.close();
  }
}
