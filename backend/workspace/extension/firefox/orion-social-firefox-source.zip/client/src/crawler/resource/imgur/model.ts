export interface Cursor {
  page: number;
  offset: number;
}
