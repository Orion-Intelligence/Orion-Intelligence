import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_PAGE_SIZE } from './constant';
import { api, clean, https, mid, page, pageNumber, person, stamp } from './helper';

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const id = mid(payload);
  const tab = id ? await openSession('https://www.bilibili.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const pn = pageNumber(payload);
    const ps = limitOf(payload, 25, MAX_PAGE_SIZE);
    const data = await api(tab, `/x/space/arc/search?mid=${encodeURIComponent(id)}&ps=${ps}&pn=${pn}&order=pubdate`);
    const list = (data?.list?.vlist ?? []) as any[];
    const items = list.map((video: any): social_resource => ({
      type: 'videos',
      resource_id: video.bvid ?? String(video.aid ?? ''),
      url: video.bvid ? `https://www.bilibili.com/video/${video.bvid}` : (video.aid ? `https://www.bilibili.com/video/av${video.aid}` : ''),
      parent_url: `https://space.bilibili.com/${id}`,
      title: clean(video.title),
      caption: clean(video.description),
      author: video.author ?? '',
      datetime: stamp(video.created),
      media_type: 'video',
      media_url: video.bvid ? `https://www.bilibili.com/video/${video.bvid}` : '',
      thumbnail_url: https(video.pic),
      likes: '',
      shares: '',
      views: String((video.play ?? 0) || ''),
      bvid: video.bvid ?? '',
      aid: video.aid ?? 0,
      title_text: clean(video.title),
      description: clean(video.description),
      duration_text: video.length ?? '',
      play_count: video.play ?? 0,
      danmaku_count: video.video_review ?? 0,
      comment_count: video.comment ?? 0,
      review_count: video.review ?? 0,
      favorites: video.favorites ?? 0,
      author_name: video.author ?? '',
      author_mid: video.mid ?? Number(id),
      copyright: video.copyright ?? '',
      is_union_video: Boolean(video.is_union_video),
      is_charging_arc: Boolean(video.is_charging_arc),
      is_live_playback: Boolean(video.is_live_playback),
      is_steins_gate: Boolean(video.is_steins_gate),
      type_id: video.typeid ?? 0,
      subtitle: clean(video.subtitle),
      hide_click: Boolean(video.hide_click),
      pic: https(video.pic),
      space_url: `https://space.bilibili.com/${id}`,
      created_at: stamp(video.created),
    })).filter((item) => item.url);
    return page(items, pn, ps, list.length, data?.page?.count);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const id = mid(payload);
  const tab = id ? await openSession('https://www.bilibili.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const pn = pageNumber(payload);
    const ps = limitOf(payload, 25, MAX_PAGE_SIZE);
    const data = await api(tab, `/x/relation/followers?vmid=${encodeURIComponent(id)}&ps=${ps}&pn=${pn}`);
    const list = (data?.list ?? []) as any[];
    const items = list.map((entry: any) => person(id, 'followers', entry)).filter((item) => item.url);
    return page(items, pn, ps, list.length, data?.total);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

