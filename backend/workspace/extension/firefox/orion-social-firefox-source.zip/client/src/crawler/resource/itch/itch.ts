import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function host(username: string): string {
  return `https://${username.toLowerCase().trim()}.itch.io`;
}

function parseGames(html: string): social_resource[] {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return Array.from(doc.querySelectorAll('div.game_cell[data-game_id]')).map((cell): social_resource => {
    const link = cell.querySelector('a.title.game_link') ?? cell.querySelector('a.game_link');
    const url = link?.getAttribute('href') ?? '';
    const title = link?.textContent?.trim() ?? '';
    const image = cell.querySelector('.game_thumb img');
    const thumb = image?.getAttribute('data-lazy_src') ?? image?.getAttribute('src') ?? '';
    const text = cell.querySelector('.game_text')?.getAttribute('title') ?? cell.querySelector('.game_text')?.textContent?.trim() ?? '';
    const author = cell.querySelector('.game_author a')?.textContent?.trim() ?? '';
    const genre = cell.querySelector('.game_genre')?.textContent?.trim() ?? '';
    const price = cell.querySelector('.price_value')?.textContent?.trim() ?? cell.querySelector('.sale_tag')?.textContent?.trim() ?? '';
    const platforms = Array.from(cell.querySelectorAll('.game_platform span, .web_flag, .windows8, .android_flag, .tux, .apple')).map((flag) => flag.className.replace(/\s+/g, ' ').trim()).filter(Boolean);
    return {
      type: 'games',
      resource_id: cell.getAttribute('data-game_id') ?? url,
      url,
      parent_url: '',
      title,
      caption: text,
      author: author || '',
      datetime: '',
      media_type: 'game',
      media_url: '',
      thumbnail_url: thumb,
      likes: '',
      shares: '',
      views: '',
      name: title,
      description: text,
      price,
      genre,
      platforms: platforms.join(', '),
    };
  }).filter((item) => item.url && item['name']);
}

async function fetchGames(username: string): Promise<social_resource[]> {
  const url = `${host(username)}/`;
  const tab = await openSession(url);
  if (!tab) {
    return [];
  }
  try {
    const response = await tab.fetch(url);
    return parseGames(response.body ?? '');
  }
  catch {
    return [];
  }
  finally {
    await tab.close();
  }
}

export async function gameCount(username: string): Promise<number> {
  return (await fetchGames(username)).length;
}

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const all = await fetchGames(username);
    if (!all.length) {
      return EMPTY;
    }

    const rawOffset = Math.floor(Number(String(payload.cursor ?? '').trim()));
    const offset = Number.isFinite(rawOffset) && rawOffset > 0 ? rawOffset : 0;
    const limit = limitOf(payload, 25, 50);
    const slice = all.slice(offset, offset + limit).map((game) => ({ ...game, parent_url: `${host(username)}/`, author: game.author || username }));

    const next = offset + slice.length;
    return { items: slice, next_cursor: slice.length && next < all.length ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
