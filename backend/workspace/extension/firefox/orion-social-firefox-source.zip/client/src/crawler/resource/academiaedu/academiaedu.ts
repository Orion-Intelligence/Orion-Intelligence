import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { decode } from './helper';

export async function papers(payload: CrawlPayload): Promise<CrawlPage> {
  const host = /^https?:\/\/([^/]+\.academia\.edu)/i.exec(payload.url ?? '')?.[1] ?? 'independent.academia.edu';
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.academia.edu/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const response = await tab.fetch(`https://${host}/${encodeURIComponent(username)}`);
    if (!response.ok) {
      return { items: [] };
    }

    const html = response.body;
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const match of html.matchAll(/https:\/\/www\.academia\.edu\/(\d+)\/([^"'\s?]+)/g)) {
      const id = match[1];
      if (seen.has(id)) {
        continue;
      }
      seen.add(id);
      const block = html.slice(match.index ?? 0, (match.index ?? 0) + 2000);
      items.push({
        type: 'papers',
        resource_id: id,
        url: match[0],
        parent_url: `https://${host}/${username}`,
        title: decode(match[2].replace(/_/g, ' ')),
        caption: decode(/<div[^>]+class="[^"]*abstract[^"]*"[^>]*>([\s\S]{0,600}?)<\/div>/i.exec(block)?.[1] ?? ''),
        author: username,
        datetime: '',
        media_type: 'paper',
        media_url: '',
        thumbnail_url: '',
        likes: '',
        shares: '',
        views: '',
      });
    }
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
