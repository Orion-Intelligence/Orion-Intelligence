import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, followers, friends, tracks } from './resource/mixcloud/mixcloud';

export class Mixcloud implements Crawler {
  readonly platform = 'mixcloud';
  readonly base = 'https://www.mixcloud.com';
  readonly loginUrl = 'https://www.mixcloud.com/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'tracks':
        return tracks(payload);
      case 'albums':
        return albums(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.mixcloud.com/${encodeURIComponent(username)}/`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.key) {
        return [];
      }

      return [{
        real_name: data.name ?? data.username ?? username,
        bio: data.biog ?? '',
        description: data.biog ?? '',
        location: [data.city, data.country].filter(Boolean).join(', '),
        profile_url: data.url ?? `https://www.mixcloud.com/${username}/`,
        total_posts: String((data.cloudcast_count ?? 0) || ''),
        total_followers: String((data.follower_count ?? 0) || ''),
        total_likes: String((data.favorite_count ?? 0) || ''),
        avatar: data.pictures?.large ?? data.pictures?.medium ?? '',
        banner: String(Object.values(data.cover_pictures ?? {}).slice(-1)[0] ?? ''),
        crawl_type: ['details', 'tracks', 'albums', 'followers', 'friends'],
        platform: this.platform,
        username: data.username ?? username,
        key: data.key ?? '',
        city: data.city ?? '',
        country: data.country ?? '',
        cloudcast_count: data.cloudcast_count ?? 0,
        follower_count: data.follower_count ?? 0,
        favorite_count: data.favorite_count ?? 0,
        listen_count: data.listen_count ?? 0,
        is_pro: data.is_pro ?? false,
        is_premium: data.is_premium ?? false,
        updated_at: data.updated_time ?? '',
        created_at: data.created_time ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://api.mixcloud.com/me/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.username);
    }
    catch {
      return false;
    }
  }
}
