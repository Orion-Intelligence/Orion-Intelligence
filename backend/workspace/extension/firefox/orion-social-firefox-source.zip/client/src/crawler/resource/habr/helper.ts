import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function host(payload: CrawlPayload): string {
  return /^https?:\/\/([^/]+)/.exec(payload.url ?? '')?.[1] ?? 'habr.com';
}

export function language(payload: CrawlPayload): string {
  return /\/(en|ru)\//.exec(payload.url ?? '')?.[1] ?? 'ru';
}

export async function api(tab: TabController, base: string, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://${base}/kek/v2${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim();
}

export function pageOf(cursor: unknown): number {
  const page = Number(String(cursor ?? '').trim());
  return Number.isFinite(page) && page >= 1 ? Math.floor(page) : 1;
}

export function totalPages(data: any): number {
  const total = Number(data?.pagesCount ?? data?.pages);
  return Number.isFinite(total) && total >= 0 ? Math.floor(total) : NaN;
}

export function commentsCursor(cursor: unknown): { page: number; skip: number } {
  const raw = String(cursor ?? '').trim();
  if (!raw) {
    return { page: 1, skip: 0 };
  }
  try {
    const parsed: any = raw.startsWith('{') ? JSON.parse(raw) : { page: raw };
    const page = Number(parsed?.page);
    const skip = Number(parsed?.skip);
    return {
      page: Number.isFinite(page) && page >= 1 ? Math.floor(page) : 1,
      skip: Number.isFinite(skip) && skip > 0 ? Math.floor(skip) : 0,
    };
  }
  catch {
    return { page: pageOf(raw), skip: 0 };
  }
}

export function comment_of(base: string, lang: string, username: string, id: string, refs: any): social_resource {
  const comment: any = refs[id] ?? {};
  const author = comment.author ?? {};
  const parent = comment.publication ?? comment.post ?? {};
  return {
    type: 'comments',
    resource_id: String(comment.id ?? id),
    url: parent.id ? `https://${base}/${lang}/articles/${parent.id}/comments/#comment_${comment.id ?? id}` : '',
    parent_url: `https://${base}/${lang}/users/${username}/`,
    title: clean(parent.titleHtml ?? parent.title),
    caption: clean(comment.message ?? comment.messageHtml ?? comment.textHtml),
    author: author.alias ?? username,
    datetime: comment.timePublished ?? '',
    media_type: 'comment',
    media_url: parent.id ? `https://${base}/${lang}/articles/${parent.id}/` : '',
    thumbnail_url: author.avatarUrl ? `https:${String(author.avatarUrl).replace(/^https?:/, '')}` : '',
    likes: String((comment.score ?? 0) || ''),
    shares: '',
    views: '',
    comment_id: comment.id ?? id,
    parent_comment_id: comment.parentId ?? '',
    is_reply: Boolean(comment.parentId),
    level: comment.level ?? 0,
    message: clean(comment.message ?? comment.messageHtml ?? comment.textHtml),
    message_length: String(comment.message ?? comment.messageHtml ?? '').length,
    score: comment.score ?? 0,
    votes_count: comment.votesCount ?? 0,
    is_favorite: comment.isFavorite ?? false,
    is_author: comment.isPostAuthor ?? false,
    is_new: comment.isNew ?? false,
    is_suspended: comment.isSuspended ?? false,
    children_count: Array.isArray(comment.children) ? comment.children.length : 0,
    post_id: parent.id ?? '',
    post_title: clean(parent.titleHtml ?? parent.title),
    post_url: parent.id ? `https://${base}/${lang}/articles/${parent.id}/` : '',
    author_id: author.id ?? '',
    author_alias: author.alias ?? '',
    author_fullname: author.fullname ?? '',
    author_avatar: author.avatarUrl ? `https:${String(author.avatarUrl).replace(/^https?:/, '')}` : '',
    author_speciality: author.speciality ?? '',
    language: lang,
    time_published: comment.timePublished ?? '',
  };
}
