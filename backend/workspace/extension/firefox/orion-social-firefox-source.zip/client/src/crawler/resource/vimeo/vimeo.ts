import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession } from '../../tab_management/tab.controller';
import { api, clean, iso, pageOf } from './helper';

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://vimeo.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const page = pageOf(payload);
    const rows = await api(tab, username, 'videos', page);
    const items = rows.map((video: any): social_resource => ({
      type: 'videos',
      resource_id: String(video.id ?? ''),
      url: video.url ?? '',
      parent_url: video.user_url ?? `https://vimeo.com/${username}`,
      title: video.title ?? '',
      caption: clean(video.description),
      author: video.user_name ?? username,
      datetime: iso(video.upload_date),
      media_type: 'video',
      media_url: video.url ?? '',
      thumbnail_url: video.thumbnail_large ?? video.thumbnail_medium ?? '',
      likes: String((video.stats_number_of_likes ?? 0) || ''),
      shares: '',
      views: String((video.stats_number_of_plays ?? 0) || ''),
      video_id: video.id ?? 0,
      title_text: video.title ?? '',
      description: clean(video.description),
      duration: video.duration ?? 0,
      width: video.width ?? 0,
      height: video.height ?? 0,
      likes_count: video.stats_number_of_likes ?? 0,
      plays_count: video.stats_number_of_plays ?? 0,
      comments_count: video.stats_number_of_comments ?? 0,
      tags: String(video.tags ?? ''),
      tags_count: String(video.tags ?? '') ? String(video.tags).split(',').filter(Boolean).length : 0,
      embed_privacy: video.embed_privacy ?? '',
      thumbnail_small: video.thumbnail_small ?? '',
      thumbnail_medium: video.thumbnail_medium ?? '',
      thumbnail_large: video.thumbnail_large ?? '',
      user_id: video.user_id ?? 0,
      user_name: video.user_name ?? '',
      user_url: video.user_url ?? '',
      user_portrait_small: video.user_portrait_small ?? '',
      user_portrait_medium: video.user_portrait_medium ?? '',
      user_portrait_large: video.user_portrait_large ?? '',
      user_portrait_huge: video.user_portrait_huge ?? '',
      upload_date: iso(video.upload_date),
      modified_date: iso(video.modified_date),
    })).filter((item) => item.url);
    return { items, next_cursor: rows.length >= 20 && page < 3 ? String(page + 1) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function albums(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://vimeo.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const page = pageOf(payload);
    const rows = await api(tab, username, 'albums', page);
    const items = rows.map((album: any): social_resource => ({
      type: 'albums',
      resource_id: String(album.id ?? ''),
      url: album.url ?? '',
      parent_url: `https://vimeo.com/${username}`,
      title: album.title ?? '',
      caption: clean(album.description),
      author: album.user_name ?? username,
      datetime: iso(album.created_on),
      media_type: 'showcase',
      media_url: album.url ?? '',
      thumbnail_url: album.thumbnail_large ?? album.thumbnail_medium ?? '',
      likes: '',
      shares: '',
      views: '',
      album_id: album.id ?? 0,
      title_text: album.title ?? '',
      description: clean(album.description),
      total_videos: album.total_videos ?? 0,
      thumbnail_small: album.thumbnail_small ?? '',
      thumbnail_medium: album.thumbnail_medium ?? '',
      thumbnail_large: album.thumbnail_large ?? '',
      user_id: album.user_id ?? 0,
      user_name: album.user_name ?? '',
      user_url: album.user_url ?? '',
      created_on: iso(album.created_on),
      last_modified: iso(album.last_modified),
    })).filter((item) => item.url);
    return { items, next_cursor: rows.length >= 20 && page < 3 ? String(page + 1) : undefined };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}

export async function organizations(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://vimeo.com/') : null;
  if (!tab) {
    return { items: [] };
  }

  try {
    const channels = await api(tab, username, 'channels');
    const groups = await api(tab, username, 'groups');
    const entries = [...channels.map((entry: any) => ({ entry, kind: 'channel' })), ...groups.map((entry: any) => ({ entry, kind: 'group' }))];

    const items = entries.map(({ entry, kind }): social_resource => ({
      type: 'organizations',
      resource_id: String(entry.id ?? ''),
      url: entry.url ?? '',
      parent_url: `https://vimeo.com/${username}`,
      title: entry.name ?? '',
      caption: clean(entry.description),
      author: entry.creator_display_name ?? '',
      datetime: iso(entry.created_on),
      media_type: kind,
      media_url: entry.url ?? '',
      thumbnail_url: entry.thumbnail ?? entry.logo ?? '',
      likes: '',
      shares: String((entry.total_users ?? entry.total_subscribers ?? 0) || ''),
      views: '',
      group_id: entry.id ?? 0,
      kind,
      name: entry.name ?? '',
      description: clean(entry.description),
      logo: entry.logo ?? '',
      badge: entry.badge ?? '',
      thumbnail: entry.thumbnail ?? '',
      rss: entry.rss ?? '',
      total_videos: entry.total_videos ?? 0,
      total_users: entry.total_users ?? 0,
      total_subscribers: entry.total_subscribers ?? 0,
      total_moderators: entry.total_moderators ?? 0,
      total_files: entry.total_files ?? 0,
      creator_id: entry.creator_id ?? 0,
      creator_display_name: entry.creator_display_name ?? '',
      creator_url: entry.creator_url ?? '',
      creator_portrait: entry.creator_portrait_large ?? entry.creator_portrait_medium ?? '',
      created_on: iso(entry.created_on),
      modified_on: iso(entry.modified_on),
    })).filter((item) => item.url);
    return { items };
  }
  catch {
    return { items: [] };
  }
  finally {
    await tab.close();
  }
}
