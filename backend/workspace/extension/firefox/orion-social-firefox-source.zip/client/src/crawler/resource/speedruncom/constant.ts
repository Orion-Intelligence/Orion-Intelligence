import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const PAGE_SIZE = 25;

export const PAGE_MAX = 200;
