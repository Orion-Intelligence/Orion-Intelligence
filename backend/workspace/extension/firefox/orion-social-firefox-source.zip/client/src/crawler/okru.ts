import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityRedirect } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/okru/okru';

export class OKru implements Crawler {
  readonly platform = 'okru';
  readonly base = 'https://ok.ru';
  readonly loginUrl = 'https://ok.ru/';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://ok.ru/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');

      const displayName = meta('og:title') || title.split('|')[0].trim();
      if (!displayName || /^(OK|Одноклассники)$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://ok.ru/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: username,
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityRedirect(tab, 'https://ok.ru/settings', /anonymMain|st\.cmd=anonym/i);
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://ok.ru/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/anonymMain|\/dk\?st\.cmd=anonym/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
