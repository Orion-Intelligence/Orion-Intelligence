import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, organizations, videos } from './resource/vimeo/vimeo';

export class Vimeo implements Crawler {
  readonly platform = 'vimeo';
  readonly base = 'https://vimeo.com';
  readonly loginUrl = 'https://vimeo.com/log_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'videos':
        return videos(payload);
      case 'albums':
        return albums(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://vimeo.com/api/v2/${encodeURIComponent(username)}/info.json`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.display_name ?? username,
        bio: data.bio ?? '',
        description: data.bio ?? '',
        location: data.location ?? '',
        profile_url: data.url ?? data.profile_url ?? `https://vimeo.com/${data.display_name ?? username}`,
        total_posts: String((data.total_videos_uploaded ?? 0) || ''),
        total_followers: String((data.total_contacts ?? 0) || ''),
        total_likes: String((data.total_videos_liked ?? 0) || ''),
        avatar: data.portrait_huge ?? data.portrait_large ?? data.portrait_medium ?? '',
        banner: '',
        crawl_type: ['details', 'videos', 'albums', 'organizations'],
        platform: this.platform,
        username: data.display_name ?? username,
        id: data.id ?? 0,
        videos_uploaded: data.total_videos_uploaded ?? 0,
        videos_liked: data.total_videos_liked ?? 0,
        videos_appears_in: data.total_videos_appears_in ?? 0,
        albums: data.total_albums ?? 0,
        channels: data.total_channels ?? 0,
        contacts: data.total_contacts ?? 0,
        is_plus: data.is_plus === '1' || data.is_plus === true,
        is_pro: data.is_pro === '1' || data.is_pro === true,
        is_staff: data.is_staff === '1' || data.is_staff === true,
        created_at: data.created_on ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://vimeo.com/_next/viewer', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.uri);
    }
    catch {
      return false;
    }
  }
}
