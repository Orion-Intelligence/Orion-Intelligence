import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { streams, videos } from './resource/kick/kick';

export class Kick implements Crawler {
  readonly platform = 'kick';
  readonly base = 'https://kick.com';
  readonly loginUrl = 'https://kick.com/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'streams':
        return streams(payload);
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://kick.com/api/v2/channels/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.id) {
        return [];
      }

      const u: any = data.user ?? {};
      const live: any = data.livestream ?? null;
      const categories: any[] = Array.isArray(data.recent_categories) ? data.recent_categories : [];

      return [{
        real_name: u.username ?? data.slug ?? username,
        bio: u.bio ?? '',
        description: u.bio ?? '',
        location: '',
        profile_url: `https://kick.com/${data.slug ?? username}`,
        total_posts: '',
        total_followers: String((data.followers_count ?? data.followersCount ?? 0) || ''),
        total_likes: '',
        avatar: u.profile_pic ?? '',
        banner: data.banner_image?.url ?? '',
        crawl_type: ['details', 'streams', 'videos'],
        platform: this.platform,
        username: data.slug ?? username,
        channel_id: data.id ?? 0,
        user_id: data.user_id ?? u.id ?? 0,
        slug: data.slug ?? '',
        followers_count: data.followers_count ?? 0,
        verified: data.verified ?? false,
        is_banned: data.is_banned ?? false,
        is_affiliate: data.is_affiliate ?? false,
        subscription_enabled: data.subscription_enabled ?? false,
        vod_enabled: data.vod_enabled ?? false,
        can_host: data.can_host ?? false,
        playback_url: data.playback_url ?? '',
        instagram: u.instagram ?? '',
        twitter: u.twitter ?? '',
        youtube: u.youtube ?? '',
        discord: u.discord ?? '',
        tiktok: u.tiktok ?? '',
        facebook: u.facebook ?? '',
        is_live: Boolean(live?.is_live),
        stream_title: live?.session_title ?? '',
        viewer_count: live?.viewer_count ?? 0,
        stream_language: live?.language ?? '',
        stream_started_at: live?.start_time ?? live?.created_at ?? '',
        category: categories[0]?.name ?? '',
        categories: categories.map((c: any) => c.name ?? '').filter(Boolean).join(', '),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://kick.com/api/v1/user', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id);
    }
    catch {
      return false;
    }
  }
}
