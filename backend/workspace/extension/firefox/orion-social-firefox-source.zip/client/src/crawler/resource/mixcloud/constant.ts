import { CrawlPage } from '../../../app/extension/model/extension.model';

export const API = 'https://api.mixcloud.com';

export const EMPTY: CrawlPage = { items: [] };
