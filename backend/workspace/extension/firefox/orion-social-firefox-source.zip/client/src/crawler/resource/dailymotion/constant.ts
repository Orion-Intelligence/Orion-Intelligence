import { CrawlPage } from '../../../app/extension/model/extension.model';

export const VIDEO_FIELDS = 'id,item_type,title,description,url,tiny_url,created_time,updated_time,uploaded_time,duration,views_total,views_last_hour,views_last_day,views_last_week,views_last_month,likes_total,audience_total,language,country,tags,hashtags,channel.id,channel.name,channel.slug,channel.description,thumbnail_url,thumbnail_720_url,thumbnail_1080_url,first_frame_720_url,embed_url,embed_html,allow_embed,width,height,aspect_ratio,available_formats,mode,status,private,published,explicit,is_created_for_kids,geoloc,geoblocking,onair,media_type,live_airing_time,filmstrip_60_url,sprite_url,seeker_url,partner,verified,soundtrack_isrc,record_status,allowed_in_playlists,owner.id,owner.username,owner.screenname,owner.url,owner.avatar_240_url';

export const USER_FIELDS = 'id,item_type,username,nickname,screenname,description,url,language,gender,country,city,created_time,views_total,videos_total,playlists_total,followers_total,reposts_total,children_total,community_members_total,community_memberships_total,partner,verified,active,status,website_url,facebook_url,twitter_url,instagram_url,pinterest_url,linkedin_url,googleplus_url,avatar_240_url,avatar_720_url,cover_url,cover_250_url';

export const EMPTY: CrawlPage = { items: [] };
