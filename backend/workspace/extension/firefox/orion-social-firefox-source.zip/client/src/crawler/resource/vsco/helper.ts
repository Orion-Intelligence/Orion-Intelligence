import { CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { WEB_TOKEN } from './constant';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://vsco.co/api${path}`, {
      headers: { Accept: 'application/json', Authorization: `Bearer ${WEB_TOKEN}` },
    });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export async function walk(tab: TabController, siteId: number, payload: CrawlPayload, keep: (item: any) => boolean): Promise<{ rows: any[]; next: string | undefined }> {
  let page = Math.max(1, Number.parseInt(String(payload.cursor ?? '').trim(), 10) || 1);
  for (let guard = 0; guard < 10; guard += 1) {
    const data = await api(tab, `/2.0/medias?site_id=${siteId}&limit=20&page=${page}`);
    const all = (Array.isArray(data?.media) ? data.media : []) as any[];
    const total = Number(data?.total) || 0;
    const more = all.length >= 20 && page * 20 < total;
    const rows = all.filter(keep);
    if (rows.length || !more) {
      return { rows, next: more ? String(page + 1) : undefined };
    }
    page += 1;
  }
  return { rows: [], next: undefined };
}

export function stamp(value: unknown): string {
  const millis = Number(value);
  return Number.isFinite(millis) && millis > 0 ? new Date(millis).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export async function site(tab: TabController, username: string): Promise<any> {
  const data = await api(tab, `/2.0/sites?subdomain=${encodeURIComponent(username)}`);
  return data?.sites?.[0] ?? null;
}

export function media(username: string, type: 'images' | 'videos', item: any, profile: any): social_resource {
  const responsive = item.responsive_url ? `https://${item.responsive_url}` : '';
  const video = item.video_url ? `https://${item.video_url}` : '';
  return {
    type,
    resource_id: item._id ?? '',
    url: item.permalink ? String(item.permalink).replace(/^http:/, 'https:') : '',
    parent_url: `https://vsco.co/${username}/gallery`,
    title: clean(item.grid_name),
    caption: clean(item.description),
    author: item.perma_subdomain ?? username,
    datetime: stamp(item.capture_date ?? item.upload_date),
    media_type: item.is_video ? 'video' : 'image',
    media_url: video || responsive,
    thumbnail_url: responsive ? `${responsive}?w=600` : '',
    likes: '',
    shares: '',
    views: '',
    media_id: item._id ?? '',
    site_id: item.site_id ?? profile?.id ?? 0,
    grid_name: clean(item.grid_name),
    description: clean(item.description),
    description_anchored: clean(item.description_anchored),
    permalink: item.permalink ? String(item.permalink).replace(/^http:/, 'https:') : '',
    share_link: item.share_link ? String(item.share_link).replace(/^http:/, 'https:') : '',
    adaptive_base: item.adaptive_base ?? '',
    responsive_url: responsive,
    image_full: responsive ? `${responsive}?w=2000` : '',
    image_medium: responsive ? `${responsive}?w=1200` : '',
    image_small: responsive ? `${responsive}?w=600` : '',
    video_url: video,
    is_video: item.is_video ?? false,
    is_featured: item.is_featured ?? false,
    feature_link: item.feature_link ?? '',
    width: item.width ?? 0,
    height: item.height ?? 0,
    has_location: item.has_location ?? false,
    show_location: item.show_location ?? 0,
    location_coords: Array.isArray(item.location_coords) ? item.location_coords.join(', ') : '',
    copyright_classes: Array.isArray(item.copyright_classes) ? item.copyright_classes.join(', ') : '',
    preset: item.preset?.short_name ?? '',
    preset_color: item.preset?.color ?? '',
    image_status: item.image_status?.code ?? 0,
    image_meta_make: item.image_meta?.make ?? '',
    image_meta_model: item.image_meta?.model ?? '',
    image_meta_aperture: item.image_meta?.aperture ?? '',
    image_meta_iso: item.image_meta?.iso ?? '',
    image_meta_shutter: item.image_meta?.shutter_speed ?? '',
    image_meta_flash: item.image_meta?.flash ?? '',
    image_meta_focal: item.image_meta?.focal_length ?? '',
    image_meta_edited: item.image_meta?.edited ?? false,
    image_meta_copyright: item.image_meta?.copyright ?? '',
    site_profile_image: item.site_profile_image_url ? `https://${item.site_profile_image_url}` : '',
    site_domain: item.perma_domain ?? '',
    site_subdomain: item.perma_subdomain ?? '',
    capture_date: stamp(item.capture_date),
    upload_date: stamp(item.upload_date),
    last_updated: stamp(item.last_updated),
  };
}
