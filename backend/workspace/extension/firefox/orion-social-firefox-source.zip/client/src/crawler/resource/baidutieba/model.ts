export interface Position {
  pn: number;
  skip: number;
}
