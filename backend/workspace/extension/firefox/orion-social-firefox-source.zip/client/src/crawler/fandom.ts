import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { images, posts } from './resource/fandom/fandom';

export class Fandom implements Crawler {
  readonly platform = 'fandom';
  readonly base = 'https://www.fandom.com';
  readonly loginUrl = 'https://www.fandom.com/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'images':
        return images(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const url = payload.url;

    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const host = /^https?:\/\/([^/]+\.fandom\.com)/i.exec(url ?? '')?.[1] ?? 'community.fandom.com';
      const response = await fetch(`https://${host}/api.php?action=query&list=users&ususers=${encodeURIComponent(username)}&usprop=editcount|registration|groups|implicitgroups|rights|gender|blockinfo&format=json`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload?.query?.users?.[0];
      if (!data || data.missing !== undefined || data.invalid !== undefined) {
        return [];
      }

      const groups: string[] = Array.isArray(data.groups) ? data.groups : [];
      const rights: string[] = Array.isArray(data.rights) ? data.rights : [];

      return [{
        real_name: data.name ?? username,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://${host}/wiki/User:${encodeURIComponent((data.name ?? username).replace(/ /g, '_'))}`,
        total_posts: String((data.editcount ?? 0) || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'posts', 'images'],
        platform: this.platform,
        username: data.name ?? username,
        user_id: data.userid ?? 0,
        wiki: host,
        edit_count: data.editcount ?? 0,
        groups: groups.filter((g: string) => !['*', 'user', 'autoconfirmed'].includes(g)).join(', '),
        all_groups: groups.join(', '),
        groups_count: groups.length,
        rights_count: rights.length,
        gender: data.gender ?? '',
        is_blocked: data.blockid !== undefined,
        blocked_by: data.blockedby ?? '',
        block_reason: data.blockreason ?? '',
        registration: data.registration ?? '',
        created_at: data.registration ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://community.fandom.com/api.php?action=query&meta=userinfo&format=json', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.query?.userinfo && data.query.userinfo.id !== 0);
    }
    catch {
      return false;
    }
  }
}
