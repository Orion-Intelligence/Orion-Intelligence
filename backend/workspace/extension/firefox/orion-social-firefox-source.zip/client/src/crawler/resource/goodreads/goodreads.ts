import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { ShelfCursor } from './model';
import { advance, book, cursorOf, decode, shelf, tag, userId, walk } from './helper';

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const tab = userId(payload) ? await openSession('https://www.goodreads.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return await walk(tab, payload, ['read'], 'reviews');
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const tab = userId(payload) ? await openSession('https://www.goodreads.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    return await walk(tab, payload, ['currently-reading', 'to-read'], 'posts');
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
