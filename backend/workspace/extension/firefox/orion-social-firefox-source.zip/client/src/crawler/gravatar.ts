import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { images, organizations } from './resource/gravatar/gravatar';

export class Gravatar implements Crawler {
  readonly platform = 'gravatar';
  readonly base = 'https://gravatar.com';
  readonly loginUrl = 'https://gravatar.com/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'images':
        return images(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://en.gravatar.com/${encodeURIComponent(username)}.json`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = Array.isArray(payload?.entry) ? payload.entry[0] : null;
      if (!data) {
        return [];
      }

      const accounts: any[] = Array.isArray(data.accounts) ? data.accounts : [];
      const emails: any[] = Array.isArray(data.emails) ? data.emails : [];
      const urls: any[] = Array.isArray(data.urls) ? data.urls : [];
      const photos: any[] = Array.isArray(data.photos) ? data.photos : [];

      return [{
        real_name: data.displayName ?? data.preferredUsername ?? username,
        bio: data.aboutMe ?? '',
        description: data.aboutMe ?? '',
        location: data.currentLocation ?? '',
        profile_url: data.profileUrl ?? `https://gravatar.com/${data.preferredUsername ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.thumbnailUrl ?? '',
        banner: data.profileBackground?.url ?? '',
        crawl_type: ['details', 'images', 'organizations'],
        platform: this.platform,
        username: data.preferredUsername ?? username,
        display_name: data.displayName ?? '',
        name: [data.name?.givenName, data.name?.familyName].filter(Boolean).join(' '),
        given_name: data.name?.givenName ?? '',
        family_name: data.name?.familyName ?? '',
        formatted_name: data.name?.formatted ?? '',
        hash: data.hash ?? '',
        request_hash: data.requestHash ?? '',
        thumbnail_url: data.thumbnailUrl ?? '',
        pronouns: data.pronouns ?? '',
        job_title: data.job_title ?? '',
        company: data.company ?? '',
        current_location: data.currentLocation ?? '',
        accounts: accounts.map((a: any) => `${a.shortname ?? a.name ?? ''}:${a.url ?? ''}`).filter((v: string) => v !== ':').join(' | '),
        accounts_count: accounts.length,
        account_names: accounts.map((a: any) => a.shortname ?? a.name ?? '').filter(Boolean).join(', '),
        verified_accounts: accounts.filter((a: any) => a.verified === true || a.verified === 'true').map((a: any) => a.shortname ?? a.name ?? '').filter(Boolean).join(', '),
        emails: emails.map((e: any) => e.value ?? '').filter(Boolean).join(', '),
        urls: urls.map((u: any) => u.value ?? u.url ?? '').filter(Boolean).join(', '),
        urls_count: urls.length,
        photos: photos.map((p: any) => p.value ?? '').filter(Boolean).join(', '),
        photos_count: photos.length,
        profile_background: data.profileBackground?.url ?? '',
        profile_background_color: data.profileBackground?.color ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://gravatar.com/profile', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/connect|\/signin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
