import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { albums, images, organizations } from './resource/flickr/flickr';

export class Flickr implements Crawler {
  readonly platform = 'flickr';
  readonly base = 'https://www.flickr.com';
  readonly loginUrl = 'https://www.flickr.com/signin';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'images':
        return images(payload);
      case 'albums':
        return albums(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.flickr.com/people/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => {
        const found = new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };

      const displayName = meta('og:title').replace(/\s*\|\s*Flickr$/i, '') || title.replace(/\s*\|\s*Flickr$/i, '');
      if (!displayName || /^Flickr$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://www.flickr.com/people/${username}`,
        total_posts: String((number('photoCount')) || ''),
        total_followers: String((number('followerCount')) || ''),
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'images', 'albums', 'organizations'],
        platform: this.platform,
        username: embedded('pathAlias') || username,
        nsid: embedded('nsid'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.flickr.com/account', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/signin|identity\.flickr/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
