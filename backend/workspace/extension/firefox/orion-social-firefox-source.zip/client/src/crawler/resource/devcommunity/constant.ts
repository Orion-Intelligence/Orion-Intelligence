import { CrawlPage } from '../../../app/extension/model/extension.model';

export const EMPTY: CrawlPage = { items: [] };

export const PER_PAGE_MAX = 1000;

export const ORG_DISCOVERY_PAGES = 4;
