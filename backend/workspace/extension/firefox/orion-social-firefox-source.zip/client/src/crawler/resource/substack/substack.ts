import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, cursorOffset, origin } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const tab = base ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25, 50);
    const offset = cursorOffset(payload);
    const raw = await api(tab, base, `/api/v1/archive?sort=new&limit=${limit}&offset=${offset}`);
    const list = (Array.isArray(raw) ? raw : []) as any[];
    const items = list.map((post: any): social_resource => {
      const author = (Array.isArray(post.publishedBylines) ? post.publishedBylines[0] : null) ?? {};
      const reactions = post.reactions ?? {};
      const totalReactions = Object.values(reactions).reduce((sum: number, value: any) => sum + (Number(value) || 0), 0);
      return {
        type: 'posts',
        resource_id: String(post.id ?? ''),
        url: post.canonical_url ?? '',
        parent_url: base,
        title: clean(post.title),
        caption: clean(post.subtitle ?? post.description ?? post.truncated_body_text),
        author: author.name ?? '',
        datetime: post.post_date ?? '',
        media_type: post.type ?? 'newsletter',
        media_url: post.podcast_url ?? post.videoUpload?.url ?? post.canonical_url ?? '',
        thumbnail_url: post.cover_image ?? '',
        likes: String((totalReactions ?? 0) || ''),
        shares: '',
        views: '',
        post_id: post.id ?? 0,
        publication_id: post.publication_id ?? 0,
        slug: post.slug ?? '',
        title_text: clean(post.title),
        social_title: clean(post.social_title),
        subtitle: clean(post.subtitle),
        description: clean(post.description),
        truncated_body: clean(post.truncated_body_text).slice(0, 2000),
        post_type: post.type ?? '',
        audience: post.audience ?? '',
        is_paid: post.audience !== 'everyone',
        section_id: post.section_id ?? 0,
        section_name: post.section_name ?? '',
        section_slug: post.section_slug ?? '',
        cover_image: post.cover_image ?? '',
        podcast_url: post.podcast_url ?? '',
        podcast_duration: post.podcast_duration ?? 0,
        video_upload_id: post.video_upload_id ?? '',
        podcast_upload_id: post.podcast_upload_id ?? '',
        comment_count: post.comment_count ?? 0,
        child_comment_count: post.child_comment_count ?? 0,
        reactions_total: totalReactions,
        reactions: Object.entries(reactions).map(([key, value]) => `${key}:${value}`).join(', '),
        restacks: post.restacks ?? 0,
        write_comment_permissions: post.write_comment_permissions ?? '',
        default_comment_sort: post.default_comment_sort ?? '',
        is_section_pinned: post.is_section_pinned ?? false,
        should_send_free_preview: post.should_send_free_preview ?? false,
        free_unlock_required: post.free_unlock_required ?? false,
        hidden: post.hidden ?? false,
        editor_v2: post.editor_v2 ?? false,
        wordcount: post.wordcount ?? 0,
        postTags: Array.isArray(post.postTags) ? post.postTags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', ') : '',
        bylines: Array.isArray(post.publishedBylines) ? post.publishedBylines.map((byline: any) => byline?.name ?? '').filter(Boolean).join(', ') : '',
        author_id: author.id ?? 0,
        author_name: author.name ?? '',
        author_handle: author.handle ?? '',
        author_bio: clean(author.bio).slice(0, 500),
        author_photo: author.photo_url ?? '',
        author_is_admin: author.is_guest === false,
        canonical_url: post.canonical_url ?? '',
        search_engine_title: clean(post.search_engine_title),
        search_engine_description: clean(post.search_engine_description),
        post_date: post.post_date ?? '',
        updated_at: post.updated_at ?? '',
      };
    }).filter((item) => item.url);
    return { items, next_cursor: items.length && list.length >= limit ? String(offset + list.length) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const tab = base ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, 25, 100);
    const postsPerBatch = 5;
    const maxBatches = 4;
    let offset = cursorOffset(payload);
    let morePosts = false;

    const items: social_resource[] = [];
    for (let batch = 0; batch < maxBatches && items.length < limit; batch += 1) {
      const archive = await api(tab, base, `/api/v1/archive?sort=new&limit=${postsPerBatch}&offset=${offset}`);
      const list = (Array.isArray(archive) ? archive : []) as any[];
      if (!list.length) {
        morePosts = false;
        break;
      }

      offset += list.length;
      morePosts = list.length >= postsPerBatch;
      const threads = await Promise.all(list.map((post: any) => api(tab, base, `/api/v1/post/${post.id}/comments?token=&all_comments=true&sort=best_first`)));
      threads.forEach((thread: any, index: number) => {
        const post = list[index] ?? {};
        const comments_list: any[] = Array.isArray(thread?.comments) ? thread.comments : [];
        comments_list.forEach((comment: any) => {
          items.push({
            type: 'comments',
            resource_id: String(comment.id ?? ''),
            url: post.canonical_url ? `${post.canonical_url}/comment/${comment.id}` : '',
            parent_url: base,
            title: clean(post.title),
            caption: clean(comment.body),
            author: comment.name ?? '',
            datetime: comment.date ?? '',
            media_type: 'comment',
            media_url: post.canonical_url ?? '',
            thumbnail_url: comment.photo_url ?? '',
            likes: String((comment.reaction_count ?? 0) || ''),
            shares: '',
            views: '',
            comment_id: comment.id ?? 0,
            post_id: post.id ?? 0,
            post_title: clean(post.title),
            post_url: post.canonical_url ?? '',
            body: clean(comment.body),
            body_length: String(comment.body ?? '').length,
            parent_comment_id: comment.parent_post_id ?? comment.ancestor_path ?? '',
            depth: String(comment.ancestor_path ?? '').split('.').filter(Boolean).length,
            reaction_count: comment.reaction_count ?? 0,
            children_count: Array.isArray(comment.children) ? comment.children.length : 0,
            user_id: comment.user_id ?? 0,
            user_name: comment.name ?? '',
            user_handle: comment.handle ?? '',
            user_photo: comment.photo_url ?? '',
            user_bio: clean(comment.bio).slice(0, 300),
            is_author: comment.user_banned === false && Boolean(comment.is_author),
            edited_at: comment.edited_at ?? '',
            date: comment.date ?? '',
          });
        });
      });

      if (!morePosts) {
        break;
      }
    }

    const filtered = items.filter((item) => item.url);
    return { items: filtered, next_cursor: filtered.length && morePosts ? JSON.stringify({ o: offset }) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
