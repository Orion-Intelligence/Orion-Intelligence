import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { ApiPage, Cursor } from './model';
import { api, apiPage, clean, cursorOf, page, project, userId } from './helper';

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gitlab.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = cursorOf(payload);
    const id = await userId(tab, username, cursor);
    if (!id) {
      return EMPTY;
    }

    const data = await apiPage(tab, `/users/${id}/projects?statistics=true&order_by=last_activity_at`, payload, cursor, id);
    return page(data.list.map((entry: any) => project(username, 'repositories', entry)).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function projects(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gitlab.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = cursorOf(payload);
    const id = await userId(tab, username, cursor);
    if (!id) {
      return EMPTY;
    }

    const data = await apiPage(tab, `/users/${id}/starred_projects?order_by=last_activity_at`, payload, cursor, id);
    return page(data.list.map((entry: any) => project(username, 'projects', entry)).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://gitlab.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const cursor = cursorOf(payload);
    const id = await userId(tab, username, cursor);
    if (!id) {
      return EMPTY;
    }

    const data = await apiPage(tab, `/users/${id}/events`, payload, cursor, id);
    return page(data.list.map((event: any): social_resource => {
      const author = event.author ?? {};
      const note = event.note ?? {};
      const push = event.push_data ?? {};
      return {
        type: 'posts',
        resource_id: String(event.id ?? ''),
        url: event.target_iid && event.project_id ? `https://gitlab.com/projects/${event.project_id}` : (author.web_url ?? ''),
        parent_url: `https://gitlab.com/${username}`,
        title: `${event.action_name ?? ''} ${event.target_type ?? push.ref_type ?? ''}`.trim(),
        caption: clean(event.target_title ?? note.body ?? push.commit_title),
        author: author.username ?? username,
        datetime: event.created_at ?? '',
        media_type: event.target_type ?? push.ref_type ?? 'event',
        media_url: author.web_url ?? '',
        thumbnail_url: author.avatar_url ?? '',
        likes: '',
        shares: '',
        views: '',
        event_id: event.id ?? 0,
        project_id: event.project_id ?? 0,
        action_name: event.action_name ?? '',
        target_id: event.target_id ?? 0,
        target_iid: event.target_iid ?? 0,
        target_type: event.target_type ?? '',
        target_title: clean(event.target_title),
        author_id: event.author_id ?? author.id ?? 0,
        author_username: author.username ?? '',
        author_name: author.name ?? '',
        author_state: author.state ?? '',
        author_locked: author.locked ?? false,
        author_avatar: author.avatar_url ?? '',
        author_web_url: author.web_url ?? '',
        author_public_email: author.public_email ?? '',
        imported: event.imported ?? false,
        imported_from: event.imported_from ?? '',
        note_id: note.id ?? 0,
        note_body: clean(note.body).slice(0, 1000),
        note_type: note.noteable_type ?? '',
        note_system: note.system ?? false,
        note_resolvable: note.resolvable ?? false,
        note_noteable_iid: note.noteable_iid ?? 0,
        push_action: push.action ?? '',
        push_ref_type: push.ref_type ?? '',
        push_ref: push.ref ?? '',
        push_commit_count: push.commit_count ?? 0,
        push_commit_title: clean(push.commit_title),
        push_commit_from: push.commit_from ?? '',
        push_commit_to: push.commit_to ?? '',
        created_at: event.created_at ?? '',
      };
    }).filter((item) => item.url), data);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
