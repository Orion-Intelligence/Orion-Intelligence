import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { PostsCursor } from './model';
import { campaignId, clean, nextPostsCursor, parsePostsCursor } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.patreon.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const state = parsePostsCursor(payload);
    const campaign = state.campaign || await campaignId(tab, username);
    if (!campaign) {
      return EMPTY;
    }

    const count = limitOf(payload, 25, 50);
    const cursorParam = state.cursor ? `&page%5Bcursor%5D=${encodeURIComponent(state.cursor)}` : '';
    const response = await tab.fetch(`https://www.patreon.com/api/posts?filter%5Bcampaign_id%5D=${campaign}&filter%5Bcontains_exclusive_posts%5D=true&sort=-published_at&page%5Bcount%5D=${count}${cursorParam}&json-api-version=1.0`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }

    const data = JSON.parse(response.body);
    const entries = (Array.isArray(data?.data) ? data.data : []) as any[];
    const items = entries.map((item: any): social_resource => {
      const post = item.attributes ?? {};
      const metadata = post.post_metadata ?? {};
      const teaser = post.teaser_text ?? '';
      return {
        type: 'posts',
        resource_id: String(item.id ?? ''),
        url: post.url ?? (post.patreon_url ? `https://www.patreon.com${post.patreon_url}` : ''),
        parent_url: `https://www.patreon.com/${username}`,
        title: clean(post.title),
        caption: clean(post.content ?? teaser).slice(0, 2000),
        author: username,
        datetime: post.published_at ?? '',
        media_type: post.post_type ?? 'post',
        media_url: post.embed?.url ?? post.image?.large_url ?? '',
        thumbnail_url: post.image?.thumb_url ?? post.image?.large_url ?? post.share_images?.landscape?.url ?? '',
        likes: String((post.like_count ?? 0) || ''),
        shares: '',
        views: '',
        post_id: item.id ?? '',
        title_text: clean(post.title),
        teaser_text: clean(teaser),
        content_text: clean(post.content).slice(0, 6000),
        content_length: String(post.content ?? '').length,
        post_type: post.post_type ?? '',
        patreon_url: post.patreon_url ? `https://www.patreon.com${post.patreon_url}` : '',
        like_count: post.like_count ?? 0,
        comment_count: post.comment_count ?? 0,
        is_paid: post.is_paid ?? false,
        is_public: post.is_public ?? false,
        min_cents_pledged: post.min_cents_pledged_to_view ?? 0,
        current_user_can_view: post.current_user_can_view ?? false,
        moderation_status: post.moderation_status ?? '',
        pledge_url: post.pledge_url ?? '',
        preview_asset_type: post.preview_asset_type ?? '',
        image_url: post.image?.large_url ?? '',
        image_thumb: post.image?.thumb_url ?? '',
        image_width: post.image?.width ?? 0,
        image_height: post.image?.height ?? 0,
        share_image_landscape: post.share_images?.landscape?.url ?? '',
        share_image_square: post.share_images?.square?.url ?? '',
        embed_url: post.embed?.url ?? '',
        embed_provider: post.embed?.provider ?? '',
        embed_subject: clean(post.embed?.subject),
        embed_description: clean(post.embed?.description).slice(0, 500),
        platform: metadata.platform ? Object.keys(metadata.platform).join(', ') : '',
        image_order_count: Array.isArray(metadata.image_order) ? metadata.image_order.length : 0,
        attachments_count: Array.isArray(post.attachments_preview_metadata) ? post.attachments_preview_metadata.length : 0,
        has_ti_violation: post.has_ti_violation ?? false,
        is_automated_monthly_charge: post.is_automated_monthly_charge ?? false,
        campaign_id: campaign,
        created_at: post.created_at ?? '',
        edited_at: post.edited_at ?? '',
        published_at: post.published_at ?? '',
        scheduled_for: post.scheduled_for ?? '',
        deleted_at: post.deleted_at ?? '',
      };
    }).filter((item) => item.url);

    const upstreamNext = nextPostsCursor(data);
    const hasMore = entries.length > 0 && Boolean(upstreamNext) && upstreamNext !== state.cursor;
    return { items, next_cursor: items.length && hasMore ? JSON.stringify({ campaign, cursor: upstreamNext } as PostsCursor) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function products(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  if (String(payload.cursor ?? '').trim()) {
    return EMPTY;
  }

  const tab = await openSession('https://www.patreon.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const campaign = await campaignId(tab, username);
    if (!campaign) {
      return EMPTY;
    }

    const response = await tab.fetch(`https://www.patreon.com/api/campaigns/${campaign}?include=rewards,creator&json-api-version=1.0`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }

    const data = JSON.parse(response.body);
    const included = (Array.isArray(data?.included) ? data.included : []) as any[];
    const rewards = included.filter((entry: any) => entry?.type === 'reward');
    const campaignData = data?.data?.attributes ?? {};

    const items = rewards.map((entry: any): social_resource => {
      const reward = entry.attributes ?? {};
      return {
        type: 'products',
        resource_id: String(entry.id ?? ''),
        url: reward.url ? `https://www.patreon.com${reward.url}` : `https://www.patreon.com/${username}`,
        parent_url: `https://www.patreon.com/${username}`,
        title: reward.title ?? '',
        caption: String(reward.description ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        author: username,
        datetime: reward.created_at ?? '',
        media_type: 'tier',
        media_url: reward.image_url ?? '',
        thumbnail_url: reward.image_url ?? '',
        likes: '',
        shares: String((reward.patron_count ?? 0) || ''),
        views: '',
        reward_id: entry.id ?? '',
        title_text: reward.title ?? '',
        description: String(reward.description ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(),
        amount_cents: reward.amount_cents ?? 0,
        amount: reward.amount ?? 0,
        currency: reward.patron_currency ?? reward.currency ?? '',
        patron_count: reward.patron_count ?? 0,
        user_limit: reward.user_limit ?? 0,
        remaining: reward.remaining ?? 0,
        requires_shipping: reward.requires_shipping ?? false,
        is_published: reward.published ?? false,
        published_at: reward.published_at ?? '',
        unpublished_at: reward.unpublished_at ?? '',
        discord_role_ids: Array.isArray(reward.discord_role_ids) ? reward.discord_role_ids.join(', ') : '',
        post_count: reward.post_count ?? 0,
        image_url: reward.image_url ?? '',
        reward_url: reward.url ? `https://www.patreon.com${reward.url}` : '',
        campaign_id: campaign,
        campaign_name: campaignData.creation_name ?? '',
        campaign_patron_count: campaignData.patron_count ?? 0,
        campaign_pledge_sum: campaignData.pledge_sum ?? 0,
        campaign_currency: campaignData.currency ?? '',
        campaign_is_nsfw: campaignData.is_nsfw ?? false,
        campaign_pay_per_name: campaignData.pay_per_name ?? '',
        created_at: reward.created_at ?? '',
        edited_at: reward.edited_at ?? '',
      };
    }).filter((item) => item.resource_id);

    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
