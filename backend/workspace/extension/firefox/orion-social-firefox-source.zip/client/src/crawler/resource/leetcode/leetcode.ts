import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, UPSTREAM_MAX } from './constant';
import { graphql, offsetOf, page, slice, stamp, stats } from './helper';

export async function answers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://leetcode.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await graphql(tab, `query ($u: String!) { recentAcSubmissionList(username: $u, limit: ${UPSTREAM_MAX}) { id title titleSlug timestamp lang statusDisplay runtime memory } }`, { u: username });
    const list = (Array.isArray(data?.recentAcSubmissionList) ? data.recentAcSubmissionList : []) as any[];
    const { entries: items, next } = slice(list, payload);
    const slugs = [...new Set(items.map((item: any) => item.titleSlug ?? '').filter(Boolean))] as string[];
    const details = await Promise.all(slugs.map((slug: string) => graphql(tab, 'query ($s: String!) { question(titleSlug: $s) { questionId questionFrontendId title titleSlug difficulty isPaidOnly likes dislikes categoryTitle stats acRate topicTags { name slug } } }', { s: slug })));
    const bySlug = new Map<string, any>(slugs.map((slug: string, index: number) => [slug, details[index]?.question ?? {}]));

    return page(items.map((item: any): social_resource => {
      const question: any = bySlug.get(item.titleSlug ?? '') ?? {};
      const counts = stats(question.stats);
      const tags: any[] = Array.isArray(question.topicTags) ? question.topicTags : [];
      return {
        type: 'answers',
        resource_id: String(item.id ?? ''),
        url: item.id ? `https://leetcode.com/submissions/detail/${item.id}/` : '',
        parent_url: `https://leetcode.com/u/${username}/`,
        title: item.title ?? question.title ?? '',
        caption: question.difficulty ?? '',
        author: username,
        datetime: stamp(item.timestamp),
        media_type: 'submission',
        media_url: item.titleSlug ? `https://leetcode.com/problems/${item.titleSlug}/` : '',
        thumbnail_url: '',
        likes: String((question.likes ?? 0) || ''),
        shares: '',
        views: '',
        submission_id: item.id ?? '',
        title_text: item.title ?? '',
        problem_slug: item.titleSlug ?? '',
        problem_url: item.titleSlug ? `https://leetcode.com/problems/${item.titleSlug}/` : '',
        language: item.lang ?? '',
        status: item.statusDisplay ?? 'Accepted',
        runtime: item.runtime ?? '',
        memory: item.memory ?? '',
        question_id: question.questionId ?? '',
        question_frontend_id: question.questionFrontendId ?? '',
        difficulty: question.difficulty ?? '',
        category: question.categoryTitle ?? '',
        is_paid_only: question.isPaidOnly ?? false,
        likes_count: question.likes ?? 0,
        dislikes_count: question.dislikes ?? 0,
        ac_rate: question.acRate ?? counts.acRate ?? '',
        total_accepted: counts.totalAccepted ?? '',
        total_submission: counts.totalSubmission ?? '',
        total_accepted_raw: counts.totalAcceptedRaw ?? 0,
        total_submission_raw: counts.totalSubmissionRaw ?? 0,
        topic_tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        topic_slugs: tags.map((tag: any) => tag?.slug ?? '').filter(Boolean).join(', '),
        topic_count: tags.length,
        timestamp: item.timestamp ?? '',
        submitted_at: stamp(item.timestamp),
      };
    }).filter((item) => item.url), next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://leetcode.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const data = await graphql(tab, `query ($u: String!) { recentSubmissionList(username: $u, limit: ${UPSTREAM_MAX}) { id title titleSlug timestamp statusDisplay lang } }`, { u: username });
    const list = (Array.isArray(data?.recentSubmissionList) ? data.recentSubmissionList : []) as any[];
    const { entries: items, next } = slice(list, payload);
    return page(items.map((item: any): social_resource => ({
      type: 'posts',
      resource_id: String(item.id ?? ''),
      url: item.id ? `https://leetcode.com/submissions/detail/${item.id}/` : '',
      parent_url: `https://leetcode.com/u/${username}/`,
      title: item.title ?? '',
      caption: item.statusDisplay ?? '',
      author: username,
      datetime: stamp(item.timestamp),
      media_type: 'submission',
      media_url: item.titleSlug ? `https://leetcode.com/problems/${item.titleSlug}/` : '',
      thumbnail_url: '',
      likes: '',
      shares: '',
      views: '',
      submission_id: item.id ?? '',
      title_text: item.title ?? '',
      problem_slug: item.titleSlug ?? '',
      problem_url: item.titleSlug ? `https://leetcode.com/problems/${item.titleSlug}/` : '',
      status: item.statusDisplay ?? '',
      is_accepted: item.statusDisplay === 'Accepted',
      language: item.lang ?? '',
      timestamp: item.timestamp ?? '',
      submitted_at: stamp(item.timestamp),
    })).filter((item) => item.url), next);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
