import { CrawlPayload } from '../../../app/extension/model/extension.model';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function profileUrl(payload: CrawlPayload): string {
  const url = String(payload.url ?? '');
  if (/^https?:\/\/(www\.)?ok\.ru\//i.test(url)) {
    return url.split(/[?#]/)[0];
  }
  const username = String(payload.username ?? '');
  if (!username) {
    return '';
  }
  return /^\d+$/.test(username) ? `https://ok.ru/profile/${username}` : `https://ok.ru/${username}`;
}
