export interface Context {
  nsid: string;
  key: string;
  alias: string;
}

export interface Cursor extends Partial<Context> {
  page: number;
}
