import { social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { GamesCursor } from './model';

export async function json(tab: TabController, url: string): Promise<any> {
  try {
    const response = await tab.fetch(url, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function api(tab: TabController, path: string): Promise<any> {
  return json(tab, `https://api.chess.com/pub${path}`);
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function tag(pgn: string, name: string): string {
  return new RegExp(`\\[${name} "([^"]*)"\\]`).exec(pgn)?.[1] ?? '';
}

export function parseGamesCursor(raw: unknown): GamesCursor | null {
  try {
    const parsed: any = JSON.parse(String(raw ?? ''));
    const archive = String(parsed?.archive ?? '').trim();
    const offset = Number(parsed?.offset);
    return archive ? { archive, offset: Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0 } : null;
  }
  catch {
    return null;
  }
}

export function game_resource(game: any, username: string, archive: string): social_resource {
  const pgn = String(game.pgn ?? '');
  const white = game.white ?? {};
  const black = game.black ?? {};
  const isWhite = String(white.username ?? '').toLowerCase() === username;
  const player = isWhite ? white : black;
  const opponent = isWhite ? black : white;
  return {
    type: 'games',
    resource_id: game.uuid ?? String(game.url ?? '').split('/').pop() ?? '',
    url: game.url ?? '',
    parent_url: `https://www.chess.com/member/${username}`,
    title: `${white.username ?? ''} vs ${black.username ?? ''}`,
    caption: tag(pgn, 'ECOUrl').split('/').pop()?.replace(/-/g, ' ') ?? tag(pgn, 'ECO'),
    author: player.username ?? username,
    datetime: stamp(game.end_time),
    media_type: game.time_class ?? 'game',
    media_url: game.pgn ? '' : '',
    thumbnail_url: '',
    likes: '',
    shares: '',
    views: '',
    uuid: game.uuid ?? '',
    time_class: game.time_class ?? '',
    time_control: game.time_control ?? '',
    rules: game.rules ?? '',
    rated: game.rated ?? false,
    eco: tag(pgn, 'ECO'),
    eco_url: game.eco ?? tag(pgn, 'ECOUrl'),
    opening: tag(pgn, 'ECOUrl').split('/').pop()?.replace(/-/g, ' ') ?? '',
    fen: game.fen ?? '',
    initial_setup: game.initial_setup ?? '',
    tcn: game.tcn ?? '',
    moves_count: (pgn.match(/\d+\.\s/g) ?? []).length,
    event: tag(pgn, 'Event'),
    site: tag(pgn, 'Site'),
    date: tag(pgn, 'Date'),
    round: tag(pgn, 'Round'),
    result: tag(pgn, 'Result'),
    termination: tag(pgn, 'Termination'),
    start_time: tag(pgn, 'StartTime'),
    end_date: tag(pgn, 'EndDate'),
    end_time_tag: tag(pgn, 'EndTime'),
    current_position: tag(pgn, 'CurrentPosition'),
    timezone: tag(pgn, 'Timezone'),
    link: tag(pgn, 'Link'),
    white_username: white.username ?? '',
    white_rating: white.rating ?? 0,
    white_result: white.result ?? '',
    white_uuid: white.uuid ?? '',
    white_url: white['@id'] ?? '',
    white_accuracy: game.accuracies?.white ?? 0,
    black_username: black.username ?? '',
    black_rating: black.rating ?? 0,
    black_result: black.result ?? '',
    black_uuid: black.uuid ?? '',
    black_url: black['@id'] ?? '',
    black_accuracy: game.accuracies?.black ?? 0,
    player_color: isWhite ? 'white' : 'black',
    player_rating: player.rating ?? 0,
    player_result: player.result ?? '',
    player_accuracy: (isWhite ? game.accuracies?.white : game.accuracies?.black) ?? 0,
    opponent_username: opponent.username ?? '',
    opponent_rating: opponent.rating ?? 0,
    opponent_result: opponent.result ?? '',
    opponent_url: opponent['@id'] ?? '',
    is_win: String(player.result ?? '') === 'win',
    rating_diff: (player.rating ?? 0) - (opponent.rating ?? 0),
    archive_url: archive,
    end_time: stamp(game.end_time),
  };
}

export function offsetOf(raw: unknown): number {
  const offset = Number(String(raw ?? '').trim());
  return Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0;
}
