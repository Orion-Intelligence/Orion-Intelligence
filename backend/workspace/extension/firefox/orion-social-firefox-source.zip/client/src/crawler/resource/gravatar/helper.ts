import { CrawlPage, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function profile(tab: TabController, username: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://gravatar.com/${encodeURIComponent(username)}.json`, { headers: { Accept: 'application/json' } });
    return response.ok ? (JSON.parse(response.body))?.entry?.[0] ?? null : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function page(items: social_resource[]): CrawlPage {
  return { items };
}
