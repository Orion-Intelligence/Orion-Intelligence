import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { openSession, TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, pollQuery } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { answers } from './resource/quora/quora';

export class Quora implements Crawler {
  readonly platform = 'quora';
  readonly base = 'https://www.quora.com';
  readonly loginUrl = 'https://www.quora.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    signedIn: ['a[href*="/profile/"]', '[data-functional-selector="user-menu"]'],
    signedOut: ['a[href*="/login"]', 'input[type="password"]'],
    username: 'a[href*="/profile/"]',
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    const tab = await openSession('https://www.quora.com/');
    if (!tab) {
      return [];
    }

    try {
      await tab.navigate(`https://www.quora.com/profile/${encodeURIComponent(username)}`);
      const html = await tab.html();
      if (!html) {
        return [];
      }
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => {
        const found = new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=(["'])((?:(?!\\1).)*)\\1`, 'i').exec(html) ?? new RegExp(`<meta[^>]+content=(["'])((?:(?!\\1).)*)\\1[^>]*(?:property|name)=["']${key}["']`, 'i').exec(html);
        return decode(found?.[2] ?? '');
      };
      const textStat = (pattern: RegExp): number => Number((pattern.exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;

      const displayName = (meta('og:title') || decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '')).replace(/\s*-\s*Quora$/i, '').replace(/^\(\d+\)\s*/, '').trim();
      if (!displayName || /^Quora$/i.test(displayName)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: '',
        profile_url: `https://www.quora.com/profile/${username}`,
        total_posts: '',
        total_followers: String((number('followerCount') || textStat(/([\d,]+)\s+followers/i)) || ''),
        total_likes: '',
        avatar: embedded('profileImageUrl') || meta('og:image'),
        banner: '',
        crawl_type: ['details', 'answers'],
        platform: this.platform,
        username: username,
        answers: number('answerCount') || number('numAnswers') || textStat(/([\d,]+)\s+Answers/i),
        questions: number('questionCount') || number('numQuestions'),
        credential: embedded('credential') || embedded('translatedCredential'),
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const dom = await pollQuery(tab, 'img[alt^="Profile photo for"]', (items) => {
      for (const item of items) {
        if (!item.href) {
          const name = item.alt.replace(/^Profile photo for\s*/i, '').trim();
          if (name) {
            return { loggedIn: true, username: name };
          }
        }
      }
      return null;
    });
    return dom || NO_IDENTITY;
  }

  async verifyLogin(): Promise<boolean> {
    const tab = await openSession('https://www.quora.com/');
    if (!tab) {
      return false;
    }
    try {
      const cookie = await tab.cookies();
      return /(?:^|;\s*)m-uid=/.test(cookie);
    }
    catch {
      return false;
    }
    finally {
      await tab.close();
    }
  }
}
