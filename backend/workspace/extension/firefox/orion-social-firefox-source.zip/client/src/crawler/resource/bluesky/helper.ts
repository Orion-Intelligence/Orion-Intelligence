import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';

export async function xrpc(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://public.api.bsky.app/xrpc/${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function pagedPath(path: string, payload: CrawlPayload): string {
  const cursor = String(payload.cursor ?? '').trim();
  return `${path}&limit=${limitOf(payload, 10, 100)}${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`;
}

export function page(items: social_resource[], data: any): CrawlPage {
  const nextCursor = String(data?.cursor ?? '').trim();
  return { items, next_cursor: items.length && nextCursor ? nextCursor : undefined };
}

export function rkey(uri: unknown): string {
  return String(uri ?? '').split('/').pop() ?? '';
}

export function text(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function person(username: string, type: 'followers' | 'friends' | 'connections', entry: any): social_resource {
  return {
    type,
    resource_id: entry.did ?? '',
    url: entry.handle ? `https://bsky.app/profile/${entry.handle}` : '',
    parent_url: `https://bsky.app/profile/${username}`,
    title: entry.displayName ?? entry.handle ?? '',
    caption: text(entry.description).slice(0, 600),
    author: entry.handle ?? '',
    datetime: entry.createdAt ?? '',
    media_type: 'user',
    media_url: entry.handle ? `https://bsky.app/profile/${entry.handle}` : '',
    thumbnail_url: entry.avatar ?? '',
    likes: '',
    shares: '',
    views: '',
    did: entry.did ?? '',
    handle: entry.handle ?? '',
    display_name: entry.displayName ?? '',
    description: text(entry.description),
    avatar: entry.avatar ?? '',
    created_at: entry.createdAt ?? '',
    indexed_at: entry.indexedAt ?? '',
    verified_status: entry.verification?.verifiedStatus ?? '',
    trusted_verifier_status: entry.verification?.trustedVerifierStatus ?? '',
    verifications_count: Array.isArray(entry.verification?.verifications) ? entry.verification.verifications.length : 0,
    chat_allow_incoming: entry.associated?.chat?.allowIncoming ?? '',
    allow_subscriptions: entry.associated?.activitySubscription?.allowSubscriptions ?? '',
    is_labeler: entry.associated?.labeler ?? false,
    lists_count: entry.associated?.lists ?? 0,
    feedgens_count: entry.associated?.feedgens ?? 0,
    starter_packs_count: entry.associated?.starterPacks ?? 0,
    labels: Array.isArray(entry.labels) ? entry.labels.map((label: any) => label?.val ?? '').filter(Boolean).join(', ') : '',
    label_sources: Array.isArray(entry.labels) ? [...new Set(entry.labels.map((label: any) => label?.src ?? '').filter(Boolean))].join(', ') : '',
    viewer_muted: entry.viewer?.muted ?? false,
    viewer_blocked: Boolean(entry.viewer?.blocking),
  };
}
