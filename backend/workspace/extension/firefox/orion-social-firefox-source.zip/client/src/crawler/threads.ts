import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { TabController } from './tab_management/tab.controller';
import { Identity, NO_IDENTITY, pollQuery } from './helper/identity';
import { Crawler } from './abstract/crawler';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/threads/threads';

export class Threads implements Crawler {
  readonly platform = 'threads';
  readonly base = 'https://www.threads.net';
  readonly loginUrl = 'https://www.threads.net/login/';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  readonly loginMarkers = {
    cookie: 'ds_user_id',
    signedIn: ['svg[aria-label="Profile"]', 'a[href*="/direct/"]'],
    signedOut: ['input[name="password"]', 'a[href*="/login"]', 'a[href*="instagram.com/accounts/login"]'],
  };

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return [];
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.threads.net/@${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };
      const number = (key: string): number => Number((new RegExp(`"${key}"\\s*:\\s*"?([\\d,.]+)`).exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;

      const displayName = embedded('full_name');
      const biography = embedded('biography');
      if (!displayName && !biography) {
        return [];
      }

      return [{
        real_name: displayName || username,
        bio: biography,
        description: biography,
        location: '',
        profile_url: `https://www.threads.net/@${embedded('username') || username}`,
        total_posts: '',
        total_followers: String((number('follower_count')) || ''),
        total_likes: '',
        avatar: embedded('profile_pic_url') || meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: embedded('username') || username,
        verified: /"is_verified"\s*:\s*true/.test(html),
        userId: embedded('pk') || embedded('id'),
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    const finalUrl = await tab.navigate('https://www.threads.com/');
    if (/\/login\/?(?:$|\?)/i.test(finalUrl)) {
      return NO_IDENTITY;
    }
    const html = await tab.html();
    if (/<html[^>]*class="[^"]*\bnot-logged-in\b/i.test(html)) {
      return NO_IDENTITY;
    }
    const username = await pollQuery(tab, 'a[href^="/@"]', (items) => {
      for (const item of items) {
        const match = item.href.match(/^\/@([A-Za-z0-9._]+)\/?$/);
        if (match && /profile/i.test(`${item.alt} ${item.text} ${item.testid}`)) {
          return { loggedIn: true, username: match[1] };
        }
      }
      return null;
    }, 6);
    return { loggedIn: true, username: username?.username || '' };
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.threads.net/api/v1/users/current_user/', {
        credentials: 'include',
        headers: { Accept: 'application/json', 'X-IG-App-ID': '238260118697367' },
      });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.pk || data?.user?.username);
    }
    catch {
      return false;
    }
  }
}
