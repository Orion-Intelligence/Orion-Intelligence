export interface PostsCursor {
  campaign: string;
  cursor: string;
}
