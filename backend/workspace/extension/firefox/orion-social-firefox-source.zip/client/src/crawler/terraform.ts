import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { moduleCount, repositories } from './resource/terraform/terraform';

export class Terraform implements Crawler {
  readonly platform = 'terraform';
  readonly base = 'https://registry.terraform.io';
  readonly loginUrl = 'https://registry.terraform.io/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const namespace = String(payload.username ?? '');
    if (!namespace) {
      return [];
    }

    try {
      const count = await moduleCount(namespace);
      if (!count) {
        return [];
      }

      return [{
        real_name: namespace,
        bio: '',
        description: '',
        location: '',
        profile_url: `https://registry.terraform.io/namespaces/${namespace}`,
        total_posts: String(count || ''),
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: namespace,
        module_count: count,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://registry.terraform.io/', { credentials: 'include', redirect: 'follow' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
