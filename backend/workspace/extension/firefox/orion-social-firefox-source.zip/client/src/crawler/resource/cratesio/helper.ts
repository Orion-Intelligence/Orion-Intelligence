import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://crates.io/api/v1/${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function cratesQuery(userId: unknown, payload: CrawlPayload): string {
  const cursor = String(payload.cursor ?? '').trim();
  if (cursor.startsWith('?') && /(^|[?&])(page|seek)=/.test(cursor)) {
    return cursor.slice(1);
  }
  return `user_id=${encodeURIComponent(String(userId))}&per_page=${limitOf(payload, 25, 100)}&sort=recent-updates`;
}

export function page(items: social_resource[], data: any, received: CrawlPayload): CrawlPage {
  const nextPage = String(data?.meta?.next_page ?? '').trim();
  const previous = String(received.cursor ?? '').trim();
  const nextCursor = nextPage.startsWith('?') && nextPage !== previous ? nextPage : '';
  return { items, next_cursor: items.length && nextCursor ? nextCursor : undefined };
}
