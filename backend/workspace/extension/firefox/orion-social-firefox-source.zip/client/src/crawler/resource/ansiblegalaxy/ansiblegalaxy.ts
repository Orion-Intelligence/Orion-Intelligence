import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function roles(username: string, page: number, size: number): Promise<any> {
  const response = await fetch(`https://galaxy.ansible.com/api/v1/roles/?owner__username=${encodeURIComponent(username)}&page=${page}&page_size=${size}&order_by=-download_count`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function roleCount(username: string): Promise<number> {
  const data = await roles(username, 1, 1);
  return Number(data?.count ?? 0);
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const page = Math.floor(offset / limit) + 1;
    const data = await roles(username, page, limit);
    const total = Number(data?.count ?? 0);
    const results: any[] = Array.isArray(data?.results) ? data.results : [];
    if (!results.length) {
      return EMPTY;
    }

    const items = results.map((role: any): social_resource => {
      const name = String(role.name ?? '');
      const owner = String(role.username ?? username);
      const summary = role.summary_fields ?? {};
      const tags = Array.isArray(summary.tags) ? summary.tags : [];
      const repository = summary.repository ?? {};
      return {
        type: 'repositories',
        resource_id: String(role.id ?? name),
        url: `https://galaxy.ansible.com/ui/standalone/roles/${owner}/${name}/`,
        parent_url: `https://galaxy.ansible.com/ui/standalone/roles/?keywords=&order_by=name&page=1&namespace=${encodeURIComponent(owner)}`,
        title: name,
        caption: clean(role.description),
        author: owner,
        datetime: role.modified ?? role.created ?? '',
        media_type: 'role',
        media_url: '',
        thumbnail_url: '',
        likes: String((repository.stargazers_count ?? 0) || ''),
        shares: String((repository.forks_count ?? 0) || ''),
        views: String((role.download_count ?? 0) || ''),
        name,
        description: clean(role.description),
        github_user: role.github_user ?? '',
        github_repo: role.github_repo ?? '',
        github_branch: role.github_branch ?? '',
        download_count: role.download_count ?? 0,
        stargazers_count: repository.stargazers_count ?? 0,
        forks_count: repository.forks_count ?? 0,
        open_issues_count: repository.open_issues_count ?? 0,
        tags: tags.map((tag: any) => typeof tag === 'object' ? (tag?.name ?? '') : String(tag)).filter(Boolean).join(', '),
        commit_message: clean(role.commit_message),
        created: role.created ?? '',
        modified: role.modified ?? '',
      };
    }).filter((item) => item.url && item['name']);

    const next = offset + results.length;
    return { items, next_cursor: items.length && next < total ? String(next) : undefined };
  }
  catch {
    return EMPTY;
  }
}
