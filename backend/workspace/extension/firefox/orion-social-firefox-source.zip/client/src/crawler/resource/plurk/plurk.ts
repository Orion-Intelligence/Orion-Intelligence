import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, MAX_UPSTREAM_CALLS, OWNER_FIELDS, UPSTREAM_PAGE_SIZE } from './constant';
import { PostsCursor } from './model';
import { balancedObject, base36, clean, isoOf, ownerSnapshot, parseCursor, parseJs, profilePage, timelinePage, toResource } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.plurk.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  const limit = limitOf(payload, UPSTREAM_PAGE_SIZE, UPSTREAM_PAGE_SIZE * MAX_UPSTREAM_CALLS);

  try {
    const cursor = parseCursor(payload);
    let userId = cursor?.user_id ?? 0;
    let owners: Record<string, any> = cursor?.owner ? { [String(userId)]: cursor.owner } : {};
    let offset = cursor?.offset ?? '';
    const collected: any[] = [];
    let exhausted = false;

    if (!cursor) {
      const first = await profilePage(tab, username);
      if (!first) {
        return EMPTY;
      }
      userId = first.userId;
      owners = first.owners;
      collected.push(...first.plurks);
      exhausted = first.plurks.length < UPSTREAM_PAGE_SIZE;
      offset = isoOf(first.plurks[first.plurks.length - 1]?.posted);
    }

    let calls = 0;
    while (!exhausted && collected.length < limit && calls < MAX_UPSTREAM_CALLS && userId && offset) {
      const batch = await timelinePage(tab, userId, offset);
      calls++;
      if (!batch || !batch.length) {
        exhausted = true;
        break;
      }
      collected.push(...batch);
      exhausted = batch.length < UPSTREAM_PAGE_SIZE;
      const nextOffset = isoOf(batch[batch.length - 1]?.posted);
      if (!nextOffset || nextOffset === offset) {
        exhausted = true;
      }
      offset = nextOffset;
    }

    const pageItems = collected.slice(0, limit);
    const items = pageItems.map((plurk: any) => toResource(plurk, owners, username)).filter((item) => item.resource_id);
    const hasMore = collected.length > limit || !exhausted;
    const lastOffset = isoOf(pageItems[pageItems.length - 1]?.posted);
    const advanced = Boolean(lastOffset) && lastOffset !== (cursor?.offset ?? '');
    const nextCursor = items.length && hasMore && userId && advanced
      ? JSON.stringify({ user_id: userId, offset: lastOffset, owner: ownerSnapshot(owners[String(userId)]) } as PostsCursor)
      : undefined;

    return { items, next_cursor: nextCursor };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
