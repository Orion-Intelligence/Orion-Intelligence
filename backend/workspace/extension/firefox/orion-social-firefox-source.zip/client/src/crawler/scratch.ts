import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, friends, organizations, projects } from './resource/scratch/scratch';

export class Scratch implements Crawler {
  readonly platform = 'scratch';
  readonly base = 'https://scratch.mit.edu';
  readonly loginUrl = 'https://scratch.mit.edu/';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      case 'organizations':
        return organizations(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.scratch.mit.edu/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.username ?? username,
        bio: data.profile?.bio ?? '',
        description: data.profile?.bio ?? '',
        location: data.profile?.country ?? '',
        profile_url: `https://scratch.mit.edu/users/${data.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.profile?.images?.['90x90'] ?? '',
        banner: '',
        crawl_type: ['details', 'projects', 'organizations', 'followers', 'friends'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? 0,
        profile_id: data.profile?.id ?? 0,
        account_status: data.profile?.status ?? '',
        country: data.profile?.country ?? '',
        membership_badge: data.profile?.membership_avatar_badge ?? '',
        scratch_team: data.scratchteam ?? false,
        joined: data.history?.joined ?? '',
        created_at: data.history?.joined ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://scratch.mit.edu/session/', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.id);
    }
    catch {
      return false;
    }
  }
}
