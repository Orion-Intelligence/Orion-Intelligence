import { social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';
import { CARD_WRAPPER, ORIGIN } from './constant';
import { Cursor } from './model';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function jsonBlocks(html: string): any[] {
  const parsed: any[] = [];
  for (const match of html.matchAll(/<script[^>]*type="application\/json"[^>]*>([\s\S]*?)<\/script>/g)) {
    try {
      parsed.push(JSON.parse(match[1]));
    }
    catch {
      continue;
    }
  }
  const next = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html)?.[1];
  if (next) {
    try {
      parsed.push(JSON.parse(next));
    }
    catch {
    }
  }
  return parsed;
}

export function collect(node: any, key: string, out: any[] = []): any[] {
  if (Array.isArray(node)) {
    node.forEach((entry) => collect(entry, key, out));
    return out;
  }
  if (node && typeof node === 'object') {
    for (const [name, value] of Object.entries(node)) {
      if (name === key) {
        out.push(value);
      }
      collect(value, key, out);
    }
  }
  return out;
}

export function absolute(href: string): string {
  try {
    const url = new URL(decode(href), ORIGIN);
    return url.origin === ORIGIN ? url.toString() : '';
  }
  catch {
    return '';
  }
}

export function parseCursor(raw: unknown): Cursor | null {
  const text = String(raw ?? '').trim();
  if (!text) {
    return null;
  }
  try {
    const parsed = JSON.parse(text);
    const next = absolute(String(parsed?.next ?? ''));
    return next ? { uid: String(parsed?.uid ?? '').replace(/\D/g, ''), next } : null;
  }
  catch {
    return null;
  }
}

export async function fetchHtml(tab: TabController, url: string): Promise<string> {
  const response = await tab.fetch(url);
  if (!response.ok) {
    return '';
  }
  return response.body;
}

export function resolveUid(html: string, username: string): string {
  const viewer = /<meta[^>]+name=["']user-id["'][^>]*content=["'](\d+)["']/i.exec(html)?.[1] ?? /<meta[^>]+content=["'](\d+)["'][^>]*name=["']user-id["']/i.exec(html)?.[1] ?? '';
  const name = username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const candidates = [
    new RegExp(`data-profile-url=["']/${name}/?["'][^>]*data-user-id=["'](\\d+)["']`, 'i').exec(html)?.[1],
    new RegExp(`data-user-id=["'](\\d+)["'][^>]*data-profile-url=["']/${name}/?["']`, 'i').exec(html)?.[1],
    new RegExp(`data-username=["']${name}["'][^>]*data-(?:user-id|uid)=["'](\\d+)["']`, 'i').exec(html)?.[1],
    new RegExp(`data-(?:user-id|uid)=["'](\\d+)["'][^>]*data-username=["']${name}["']`, 'i').exec(html)?.[1],
    /href=["'][^"']*\/app\/(\d+)\/posts\b/i.exec(html)?.[1],
    /\/app\/report\?[^"']*\buid=(\d+)/i.exec(html)?.[1],
    /\/app\/photo\?[^"']*\buid=(\d+)/i.exec(html)?.[1],
    /\/app\/profile\/compact\?[^"']*\buid=(\d+)/i.exec(html)?.[1],
    /feed_owner_id["']?\s*[:=]\s*["']?(\d+)/i.exec(html)?.[1],
    /inlineComments\(\s*['"]post['"]\s*,\s*['"]?\d+['"]?\s*,\s*['"]?(\d+)/i.exec(html)?.[1],
    /data-(?:feed-owner-id|profile-id|owner-id)=["'](\d+)["']/i.exec(html)?.[1],
  ];
  return candidates.find((candidate) => candidate && candidate !== viewer) ?? '';
}

export function setQuery(url: string, params: Record<string, string>): string {
  const target = new URL(url);
  Object.entries(params).forEach(([key, value]) => target.searchParams.set(key, value));
  return target.toString();
}

export function cursorNext(html: string, current: string): string {
  const container = /<[a-z][^>]*\bdata-next-cursor=["'][^"']*["'][^>]*>/i.exec(html)?.[0] ?? '';
  if (!container) {
    return '';
  }
  const cursor = decode(/\bdata-next-cursor=["']([^"']*)["']/i.exec(container)?.[1] ?? '');
  if (!cursor || !/\bdata-has-more=["']true["']/i.test(container)) {
    return '';
  }
  const next = setQuery(current, { cursor });
  return next !== current ? next : '';
}

export function linkNext(html: string, current: string): string {
  const rel = /<(?:a|link)[^>]+rel=["']next["'][^>]+href=["']([^"']+)["']/i.exec(html)?.[1] ?? /<(?:a|link)[^>]+href=["']([^"']+)["'][^>]+rel=["']next["']/i.exec(html)?.[1] ?? '';
  if (rel) {
    const next = absolute(rel);
    return next && next !== current ? next : '';
  }
  const page = Number(new URL(current).searchParams.get('page') ?? '1') || 1;
  const link = new RegExp(`href=["']([^"']*[?&](?:amp;)?page=${page + 1}(?:&[^"']*)?)["']`, 'i').exec(html)?.[1] ?? '';
  if (link) {
    const next = absolute(link);
    return next && next !== current ? next : '';
  }
  return '';
}

export function nextPageUrl(html: string, current: string): string {
  return cursorNext(html, current) || linkNext(html, current);
}

export function htmlEntries(html: string, username: string): any[] {
  const mentions = new Map<string, number>();
  const owners = new Map<string, string>();
  const comments = new Map<string, string>();
  for (const match of html.matchAll(/\/app\/(?:(\d+)\/)?posts\/(\d+)\b/g)) {
    if (!mentions.has(match[2])) {
      mentions.set(match[2], match.index ?? 0);
    }
    if (match[1] && !owners.has(match[2])) {
      owners.set(match[2], match[1]);
    }
  }
  for (const match of html.matchAll(/inlineComments\(\s*['"]post['"]\s*,\s*['"]?(\d+)['"]?\s*,\s*['"]?(\d+)['"]?\s*,\s*['"]?(\d+)/g)) {
    if (!mentions.has(match[1])) {
      mentions.set(match[1], match.index ?? 0);
    }
    owners.set(match[1], owners.get(match[1]) ?? match[2]);
    comments.set(match[1], match[3]);
  }
  for (const match of html.matchAll(/\b(?:data-post-id|data-entity-id)=["'](\d+)["']/g)) {
    if (!mentions.has(match[1])) {
      mentions.set(match[1], match.index ?? 0);
    }
  }

  const ordered = [...mentions.entries()].sort((a, b) => a[1] - b[1]);
  const starts = ordered.map(([, mention], index) => {
    const previous = index ? ordered[index - 1][1] + 1 : 0;
    const lower = Math.max(previous, mention - 4000);
    let wrapper = -1;
    for (const match of html.slice(lower, mention).matchAll(CARD_WRAPPER)) {
      wrapper = lower + (match.index ?? 0);
    }
    return wrapper >= 0 ? wrapper : Math.max(index ? Math.floor((ordered[index - 1][1] + mention) / 2) : 0, mention - 1500);
  });

  return ordered.map(([id], index) => {
    const from = starts[index];
    const end = index + 1 < starts.length ? starts[index + 1] : Math.min(html.length, from + 20000);
    const block = html.slice(from, Math.min(end, from + 40000));
    const owner = owners.get(id) ?? '';
    const body = /class=["'][^"']*post-body-content[^"']*["'][^>]*>([\s\S]*?)<\/div>/i.exec(block)?.[1] ?? /class=["'][^"']*(?:post-body|post-text|post-message|post-content)[^"']*["'][^>]*>([\s\S]*?)<\/(?:div|p)>/i.exec(block)?.[1] ?? '';
    const title = /class=["'][^"']*post-title[^"']*["'][^>]*>([\s\S]*?)<\/(?:h\d|div|span|a)>/i.exec(block)?.[1] ?? '';
    const link = /data-post-link=["']([^"']+)["']/i.exec(block)?.[1] ?? `/app/${owner || 'posts'}${owner ? '/posts' : ''}/${id}`;
    const datetime = /<time[^>]+datetime=["']([^"']+)["']/i.exec(block)?.[1] ?? /data-(?:timestamp|created-at|datetime)=["']([^"']+)["']/i.exec(block)?.[1] ?? '';
    const images = [...block.matchAll(/<img[^>]+src=["']([^"']+)["'][^>]*>/gi)]
      .map((match) => match[0])
      .filter((tag) => !/avatar|thumb_|\/images\/|logo|emoji|icon/i.test(tag) && /ipstatic\.net|\/photo|\/uploads?\//i.test(tag))
      .map((tag) => ({ url: decode(/src=["']([^"']+)["']/i.exec(tag)?.[1] ?? ''), thumb_url: decode(/data-(?:thumb|thumbnail)=["']([^"']+)["']/i.exec(tag)?.[1] ?? '') }))
      .filter((image) => image.url);
    const likes = /data-like-count=["'](\d+)["']/i.exec(block)?.[1] ?? /likeCount\s*[:=]\s*['"]?(\d+)/i.exec(block)?.[1] ?? /['"]?like_count['"]?\s*[:=]\s*['"]?(\d+)/i.exec(block)?.[1] ?? '';
    const views = /data-view-count=["'](\d+)["']/i.exec(block)?.[1] ?? /['"]?view_count['"]?\s*[:=]\s*['"]?(\d+)/i.exec(block)?.[1] ?? '';
    const authorName = /data-profile-card[^>]*>[\s\S]{0,400}?class=["'][^"']*(?:name|username)[^"']*["'][^>]*>([\s\S]*?)</i.exec(block)?.[1] ?? '';
    const avatar = /<img[^>]+(?:class=["'][^"']*avatar[^"']*["'][^>]+src=["']([^"']+)["']|src=["']([^"']+)["'][^>]+class=["'][^"']*avatar[^"']*["'])/i.exec(block);
    return {
      id,
      url: absolute(link) || `${ORIGIN}/${username}`,
      title: decode(title),
      text: decode(body),
      images,
      like_count: likes ? Number(likes) : 0,
      comment_count: comments.has(id) ? Number(comments.get(id)) : 0,
      share_count: 0,
      view_count: views ? Number(views) : 0,
      createdAt: datetime,
      author: { id: owner, nickname: decode(authorName) || username, unique_id: username, avatar: avatar?.[1] ?? avatar?.[2] ?? '' },
    };
  });
}

export function toResource(entry: any, username: string, seen: Set<string>): social_resource | null {
  const origin = ORIGIN;
  const id = String(entry.id ?? entry.item_id ?? entry.post_id ?? entry.postId ?? '');
  if (!id || seen.has(id)) {
    return null;
  }
  seen.add(id);
  const text = entry.text ?? entry.desc ?? entry.content ?? entry.title ?? '';
  const images: any[] = Array.isArray(entry.image_list) ? entry.image_list : Array.isArray(entry.images) ? entry.images : Array.isArray(entry.medias) ? entry.medias : [];
  return {
    type: 'posts',
    resource_id: id,
    url: entry.share_url ?? entry.url ?? entry.link ?? `${origin}/${username}`,
    parent_url: `${origin}/${username}`,
    title: decode(String(entry.title ?? '')),
    caption: decode(String(text)),
    author: entry.author?.nickname ?? entry.user?.name ?? username,
    datetime: entry.create_time ? new Date(Number(entry.create_time) * 1000).toISOString() : String(entry.createdAt ?? entry.published_at ?? ''),
    media_type: images.length ? 'image' : 'text',
    media_url: images[0]?.url_list?.[0] ?? images[0]?.url ?? images[0] ?? '',
    thumbnail_url: images[0]?.thumb_url ?? images[0]?.url_list?.[0] ?? '',
    likes: String((entry.like_count ?? entry.digg_count ?? entry.likes ?? 0) || ''),
    shares: String((entry.share_count ?? entry.shares ?? 0) || ''),
    views: String((entry.view_count ?? entry.play_count ?? 0) || ''),
    post_id: id,
    text: decode(String(text)),
    text_length: decode(String(text)).length,
    like_count: entry.like_count ?? entry.digg_count ?? entry.likes ?? 0,
    comment_count: entry.comment_count ?? entry.comments ?? 0,
    share_count: entry.share_count ?? entry.shares ?? 0,
    collect_count: entry.collect_count ?? 0,
    view_count: entry.view_count ?? entry.play_count ?? 0,
    images_count: images.length,
    image_urls: images.map((image: any) => image?.url_list?.[0] ?? image?.url ?? image ?? '').filter(Boolean).slice(0, 20).join(', '),
    tags: Array.isArray(entry.hashtags) ? entry.hashtags.map((tag: any) => tag?.name ?? tag).filter(Boolean).join(', ') : '',
    author_id: entry.author?.id ?? entry.user?.id ?? '',
    author_name: entry.author?.nickname ?? entry.user?.name ?? '',
    author_handle: entry.author?.unique_id ?? entry.user?.username ?? '',
    author_avatar: entry.author?.avatar_thumb?.url_list?.[0] ?? entry.user?.avatar ?? entry.author?.avatar ?? '',
    created_at: entry.create_time ? new Date(Number(entry.create_time) * 1000).toISOString() : String(entry.createdAt ?? ''),
  };
}

export function parsePosts(html: string, username: string): social_resource[] {
  const blocks = jsonBlocks(html);
  const candidates = [
    ...blocks.flatMap((block: any) => collect(block, 'item_list')).flat(),
    ...blocks.flatMap((block: any) => collect(block, 'posts')).flat(),
    ...blocks.flatMap((block: any) => collect(block, 'feed')).flat(),
    ...htmlEntries(html, username),
  ].filter((entry: any) => entry && typeof entry === 'object');

  const seen = new Set<string>();
  const items: social_resource[] = [];
  for (const entry of candidates) {
    const item = toResource(entry, username, seen);
    if (item?.resource_id) {
      items.push(item);
    }
  }
  return items;
}
