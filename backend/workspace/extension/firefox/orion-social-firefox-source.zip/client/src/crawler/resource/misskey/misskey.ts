import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { Cursor, Upstream } from './model';
import { accountId, api, clean, fetchPage, origin, page, parseCursor, person } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const upstream = await fetchPage(tab, base, 'users/notes', payload, username, { withRenotes: true, withReplies: true });
    return page(upstream.raw.map((note: any): social_resource => {
      const user = note.user ?? {};
      const files: any[] = Array.isArray(note.files) ? note.files : [];
      const poll = note.poll ?? {};
      const reactions = note.reactions ?? {};
      const renote = note.renote ?? {};
      return {
        type: 'posts',
        resource_id: note.id ?? '',
        url: note.id ? `${base}/notes/${note.id}` : '',
        parent_url: `${base}/@${username}`,
        title: note.cw ?? '',
        caption: clean(note.text),
        author: user.username ?? username,
        datetime: note.createdAt ?? '',
        media_type: files[0]?.type ?? (note.renoteId && !note.text ? 'renote' : 'note'),
        media_url: files[0]?.url ?? '',
        thumbnail_url: files[0]?.thumbnailUrl ?? '',
        likes: String((note.reactionCount ?? 0) || ''),
        shares: String((note.renoteCount ?? 0) || ''),
        views: '',
        note_id: note.id ?? '',
        text: clean(note.text),
        text_length: String(note.text ?? '').length,
        cw: note.cw ?? '',
        visibility: note.visibility ?? '',
        local_only: note.localOnly ?? false,
        reaction_acceptance: note.reactionAcceptance ?? '',
        renote_count: note.renoteCount ?? 0,
        replies_count: note.repliesCount ?? 0,
        reaction_count: note.reactionCount ?? 0,
        reactions: Object.entries(reactions).map(([key, value]) => `${key}:${value}`).join(', '),
        reaction_names: Object.keys(reactions).join(', '),
        reply_id: note.replyId ?? '',
        renote_id: note.renoteId ?? '',
        renote_text: clean(renote.text).slice(0, 500),
        renote_author: renote.user?.username ?? '',
        renote_url: renote.id ? `${base}/notes/${renote.id}` : '',
        files_count: files.length,
        file_urls: files.map((file: any) => file?.url ?? '').filter(Boolean).join(', '),
        file_types: [...new Set(files.map((file: any) => file?.type ?? '').filter(Boolean))].join(', '),
        file_names: files.map((file: any) => file?.name ?? '').filter(Boolean).join(', '),
        file_sizes: files.reduce((sum: number, file: any) => sum + (file?.size ?? 0), 0),
        file_sensitive: files.some((file: any) => file?.isSensitive),
        file_comments: files.map((file: any) => clean(file?.comment)).filter(Boolean).join(' | '),
        poll_choices: Array.isArray(poll.choices) ? poll.choices.map((choice: any) => choice?.text ?? '').filter(Boolean).join(' | ') : '',
        poll_votes: Array.isArray(poll.choices) ? poll.choices.reduce((sum: number, choice: any) => sum + (choice?.votes ?? 0), 0) : 0,
        poll_multiple: poll.multiple ?? false,
        poll_expires_at: poll.expiresAt ?? '',
        tags: Array.isArray(note.tags) ? note.tags.join(', ') : '',
        mentions_count: Array.isArray(note.mentions) ? note.mentions.length : 0,
        uri: note.uri ?? '',
        url_field: note.url ?? '',
        channel_id: note.channelId ?? '',
        channel_name: note.channel?.name ?? '',
        user_id: note.userId ?? user.id ?? '',
        user_name: user.name ?? '',
        user_username: user.username ?? '',
        user_host: user.host ?? '',
        user_avatar: user.avatarUrl ?? '',
        user_is_bot: user.isBot ?? false,
        user_is_cat: user.isCat ?? false,
        user_online_status: user.onlineStatus ?? '',
        user_badge_roles: Array.isArray(user.badgeRoles) ? user.badgeRoles.map((role: any) => role?.name ?? '').filter(Boolean).join(', ') : '',
        created_at: note.createdAt ?? '',
      };
    }).filter((item) => item.url), upstream);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const upstream = await fetchPage(tab, base, 'users/followers', payload, username);
    return page(upstream.raw.map((entry: any) => person(base, username, 'followers', entry)).filter((item) => item.url), upstream);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const upstream = await fetchPage(tab, base, 'users/following', payload, username);
    return page(upstream.raw.map((entry: any) => person(base, username, 'friends', entry)).filter((item) => item.url), upstream);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

