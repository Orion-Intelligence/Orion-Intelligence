import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { limitOf } from '../../helper/helper';
import { EMPTY, MEDIUM_QUERY } from './constant';
import { MediumPage } from './model';
import { decode, fetchPage, iso, mediumPost } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '').replace(/^@/, '');
  if (!username) {
    return EMPTY;
  }

  const tab = await openSession('https://medium.com/');
  if (!tab) {
    return EMPTY;
  }

  try {
    await tab.navigate(`https://medium.com/@${encodeURIComponent(username)}`);
    const cursor = String(payload.cursor ?? '').trim();
    const result = await fetchPage(tab, username, limitOf(payload, 25, 25), cursor || null);
    if (!result) {
      return EMPTY;
    }

    const seen = new Set<string>();
    const items = result.posts.filter((post: any) => {
      const url = post?.mediumUrl ?? '';
      if (!url || seen.has(url)) {
        return false;
      }
      seen.add(url);
      return true;
    }).map((post: any) => mediumPost(post, username));

    const next = result.from && result.from !== cursor ? result.from : undefined;
    return { items, next_cursor: items.length && next ? next : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
