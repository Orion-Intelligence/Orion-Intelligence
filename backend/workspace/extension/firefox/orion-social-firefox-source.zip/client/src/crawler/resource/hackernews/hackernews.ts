import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { SearchResult } from './model';
import { clean, pageFrom, pageOf, search } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://hn.algolia.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await search(tab, `story,author_${username}`, payload);
    return pageFrom(result.hits.map((hit: any): social_resource => {
      const id = hit.objectID ?? '';
      return {
        type: 'posts',
        resource_id: String(id),
        url: `https://news.ycombinator.com/item?id=${id}`,
        parent_url: `https://news.ycombinator.com/user?id=${username}`,
        title: clean(hit.title),
        caption: clean(hit.story_text ?? hit.url),
        author: hit.author ?? username,
        datetime: hit.created_at ?? '',
        media_type: hit.url ? 'link' : 'text',
        media_url: hit.url ?? '',
        thumbnail_url: '',
        likes: String((hit.points ?? 0) || ''),
        shares: '',
        views: '',
        story_id: String(id),
        title_text: clean(hit.title),
        link_url: hit.url ?? '',
        link_domain: hit.url ? String(hit.url).replace(/^https?:\/\//, '').split('/')[0] : '',
        story_text: clean(hit.story_text),
        points: hit.points ?? 0,
        num_comments: hit.num_comments ?? 0,
        children_count: Array.isArray(hit.children) ? hit.children.length : 0,
        tags: Array.isArray(hit._tags) ? hit._tags.join(', ') : '',
        is_show_hn: /^show hn/i.test(String(hit.title ?? '')),
        is_ask_hn: /^ask hn/i.test(String(hit.title ?? '')),
        is_job: Array.isArray(hit._tags) && hit._tags.includes('job'),
        is_poll: Array.isArray(hit._tags) && hit._tags.includes('poll'),
        author_name: hit.author ?? username,
        created_at: hit.created_at ?? '',
        created_at_timestamp: hit.created_at_i ?? 0,
        updated_at: hit.updated_at ?? '',
        hn_url: `https://news.ycombinator.com/item?id=${id}`,
        algolia_url: `https://hn.algolia.com/api/v1/items/${id}`,
      };
    }).filter((item) => item.resource_id), result);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function comments(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://hn.algolia.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const result = await search(tab, `comment,author_${username}`, payload);
    return pageFrom(result.hits.map((hit: any): social_resource => {
      const id = hit.objectID ?? '';
      return {
        type: 'comments',
        resource_id: String(id),
        url: `https://news.ycombinator.com/item?id=${id}`,
        parent_url: `https://news.ycombinator.com/user?id=${username}`,
        title: clean(hit.story_title),
        caption: clean(hit.comment_text),
        author: hit.author ?? username,
        datetime: hit.created_at ?? '',
        media_type: 'comment',
        media_url: hit.story_url ?? '',
        thumbnail_url: '',
        likes: String((hit.points ?? 0) || ''),
        shares: '',
        views: '',
        comment_id: String(id),
        comment_text: clean(hit.comment_text),
        comment_length: clean(hit.comment_text).length,
        story_id: String(hit.story_id ?? ''),
        story_title: clean(hit.story_title),
        story_url: hit.story_url ?? '',
        story_link: hit.story_id ? `https://news.ycombinator.com/item?id=${hit.story_id}` : '',
        parent_id: String(hit.parent_id ?? ''),
        parent_link: hit.parent_id ? `https://news.ycombinator.com/item?id=${hit.parent_id}` : '',
        is_top_level: String(hit.parent_id ?? '') === String(hit.story_id ?? ''),
        points: hit.points ?? 0,
        children_count: Array.isArray(hit.children) ? hit.children.length : 0,
        tags: Array.isArray(hit._tags) ? hit._tags.join(', ') : '',
        author_name: hit.author ?? username,
        created_at: hit.created_at ?? '',
        created_at_timestamp: hit.created_at_i ?? 0,
        updated_at: hit.updated_at ?? '',
        algolia_url: `https://hn.algolia.com/api/v1/items/${id}`,
      };
    }).filter((item) => item.resource_id), result);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const postUrl = String(payload.url ?? '');
  const id = /[?&]id=(\d+)/.exec(postUrl)?.[1] ?? /\/items\/(\d+)/.exec(postUrl)?.[1] ?? '';
  if (!id) {
    return EMPTY;
  }
  const tab = await openSession('https://hn.algolia.com/');
  if (!tab) {
    return EMPTY;
  }
  try {
    const response = await tab.fetch(`https://hn.algolia.com/api/v1/items/${id}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return EMPTY;
    }
    const data = JSON.parse(response.body);
    const children: any[] = Array.isArray(data?.children) ? data.children : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const child of children) {
      const author = String(child?.author ?? '');
      if (!author || seen.has(author)) {
        continue;
      }
      seen.add(author);
      items.push({
        type: 'connections',
        resource_id: author,
        url: `https://news.ycombinator.com/user?id=${encodeURIComponent(author)}`,
        parent_url: postUrl,
        title: author,
        caption: clean(child.text).slice(0, 600),
        author,
        datetime: child.created_at ?? '',
        media_type: 'user',
        media_url: `https://news.ycombinator.com/user?id=${encodeURIComponent(author)}`,
        thumbnail_url: '',
        likes: String((child.points ?? 0) || ''),
        shares: '',
        views: '',
        handle: author,
        comment_id: String(child.id ?? ''),
        comment_text: clean(child.text),
        comment_url: `https://news.ycombinator.com/item?id=${child.id ?? ''}`,
        comment_at: child.created_at ?? '',
        reply_count: Array.isArray(child.children) ? child.children.length : 0,
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
