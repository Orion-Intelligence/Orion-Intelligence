import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY, PAGE_MAX, PAGE_SIZE } from './constant';
import { GamesCursor } from './model';
import { api, clean, parseCursor, resolveUserId } from './helper';

export async function games(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://www.speedrun.com/') : null;
  if (!tab) {
    return EMPTY;
  }

  try {
    const limit = limitOf(payload, PAGE_SIZE, PAGE_MAX);
    const cursor = parseCursor(payload);
    const userId = cursor.user_id || await resolveUserId(tab, username);
    if (!userId) {
      return EMPTY;
    }

    const list = await api(tab, `/users/${userId}/personal-bests?embed=game,category,level,region,platform`);
    const all = (Array.isArray(list?.data) ? list.data : []) as any[];
    const slice = all.slice(cursor.offset, cursor.offset + limit);
    const end = cursor.offset + slice.length;

    const items = slice.map((entry: any): social_resource => {
      const run = entry.run ?? {};
      const game = run.game?.data ?? {};
      const category = run.category?.data ?? {};
      const level = run.level?.data ?? {};
      const platform = run.platform?.data ?? {};
      const region = run.region?.data ?? {};
      const times = run.times ?? {};
      const system = run.system ?? {};
      const videos: any[] = Array.isArray(run.videos?.links) ? run.videos.links : [];
      const players: any[] = Array.isArray(run.players) ? run.players : [];
      return {
        type: 'games',
        resource_id: run.id ?? '',
        url: run.weblink ?? '',
        parent_url: `https://www.speedrun.com/users/${username}`,
        title: game.names?.international ?? '',
        caption: `${category.name ?? ''}${level.name ? ` - ${level.name}` : ''}`.trim(),
        author: username,
        datetime: run.date ?? run.submitted ?? '',
        media_type: 'run',
        media_url: videos[0]?.uri ?? '',
        thumbnail_url: game.assets?.['cover-medium']?.uri ?? game.assets?.['cover-large']?.uri ?? '',
        likes: '',
        shares: '',
        views: '',
        run_id: run.id ?? '',
        place: entry.place ?? 0,
        game_id: game.id ?? '',
        game_name: game.names?.international ?? '',
        game_name_japanese: game.names?.japanese ?? '',
        game_abbreviation: game.abbreviation ?? '',
        game_weblink: game.weblink ?? '',
        game_released: game.released ?? 0,
        game_release_date: game['release-date'] ?? '',
        game_romhack: game.romhack ?? false,
        game_platforms: Array.isArray(game.platforms) ? game.platforms.join(', ') : '',
        game_genres: Array.isArray(game.genres) ? game.genres.join(', ') : '',
        game_cover: game.assets?.['cover-medium']?.uri ?? '',
        game_created: game.created ?? '',
        category_id: category.id ?? '',
        category_name: category.name ?? '',
        category_type: category.type ?? '',
        category_rules: clean(category.rules).slice(0, 1000),
        category_misc: category.miscellaneous ?? false,
        level_id: level.id ?? '',
        level_name: level.name ?? '',
        level_rules: clean(level.rules).slice(0, 500),
        platform_id: platform.id ?? run.system?.platform ?? '',
        platform_name: platform.name ?? '',
        platform_released: platform.released ?? 0,
        region_id: region.id ?? '',
        region_name: region.name ?? '',
        emulated: system.emulated ?? false,
        time_primary: times.primary ?? '',
        time_primary_seconds: times.primary_t ?? 0,
        time_realtime: times.realtime ?? '',
        time_realtime_seconds: times.realtime_t ?? 0,
        time_realtime_noloads: times.realtime_noloads ?? '',
        time_realtime_noloads_seconds: times.realtime_noloads_t ?? 0,
        time_ingame: times.ingame ?? '',
        time_ingame_seconds: times.ingame_t ?? 0,
        status: run.status?.status ?? '',
        examiner: run.status?.examiner ?? '',
        verify_date: run.status?.['verify-date'] ?? '',
        comment: clean(run.comment).slice(0, 1000),
        video_links: videos.map((video: any) => video?.uri ?? '').filter(Boolean).join(', '),
        video_count: videos.length,
        players_count: players.length,
        player_ids: players.map((player: any) => player?.id ?? player?.name ?? '').filter(Boolean).join(', '),
        splits_uri: run.splits?.uri ?? '',
        date: run.date ?? '',
        submitted: run.submitted ?? '',
      };
    }).filter((item) => item.url);

    const next: GamesCursor = { user_id: userId, offset: end };
    return { items, next_cursor: items.length && end < all.length ? JSON.stringify(next) : undefined };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
