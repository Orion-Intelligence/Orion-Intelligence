import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';

const EMPTY: CrawlPage = { items: [] };

function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function offsetOf(payload: CrawlPayload): number {
  const n = Math.floor(Number(String(payload.cursor ?? '').trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function fetchModules(namespace: string, offset: number, limit: number): Promise<any> {
  const response = await fetch(`https://registry.terraform.io/v1/modules?namespace=${encodeURIComponent(namespace)}&limit=${limit}&offset=${offset}`, { headers: { Accept: 'application/json' } });
  if (!response.ok) {
    return null;
  }
  return response.json();
}

export async function moduleCount(namespace: string): Promise<number> {
  const data = await fetchModules(namespace, 0, 100);
  return Array.isArray(data?.modules) ? data.modules.length : 0;
}

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const namespace = String(payload.username ?? '');
  if (!namespace) {
    return EMPTY;
  }

  try {
    const offset = offsetOf(payload);
    const limit = limitOf(payload, 25, 50);
    const data = await fetchModules(namespace, offset, limit);
    const modules: any[] = Array.isArray(data?.modules) ? data.modules : [];
    if (!modules.length) {
      return EMPTY;
    }
    const nextOffset = data?.meta?.next_offset;

    const items = modules.map((module: any): social_resource => {
      const ns = String(module.namespace ?? namespace);
      const name = String(module.name ?? '');
      const provider = String(module.provider ?? '');
      return {
        type: 'repositories',
        resource_id: String(module.id ?? `${ns}/${name}/${provider}`),
        url: `https://registry.terraform.io/modules/${ns}/${name}/${provider}`,
        parent_url: `https://registry.terraform.io/namespaces/${ns}`,
        title: `${ns}/${name}/${provider}`,
        caption: clean(module.description),
        author: ns,
        datetime: module.published_at ?? '',
        media_type: 'module',
        media_url: '',
        thumbnail_url: module.provider_logo_url ?? '',
        likes: '',
        shares: '',
        views: String((module.downloads ?? 0) || ''),
        name,
        description: clean(module.description),
        provider,
        version: module.version ?? '',
        source: module.source ?? '',
        owner: module.owner ?? '',
        downloads: module.downloads ?? 0,
        verified: Boolean(module.verified),
        tag: module.tag ?? '',
        published_at: module.published_at ?? '',
      };
    }).filter((item) => item.url && item['name']);

    return { items, next_cursor: items.length && nextOffset != null ? String(nextOffset) : undefined };
  }
  catch {
    return EMPTY;
  }
}
