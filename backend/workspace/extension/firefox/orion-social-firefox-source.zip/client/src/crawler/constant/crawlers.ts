import { CRAWL_TYPES, CrawlType } from '../../app/extension/model/extension.model';
import { Crawler } from '../abstract/crawler';
import { AcademiaEdu } from '../academiaedu';
import { AMO } from '../amo';
import { Anaconda } from '../anaconda';
import { AniList } from '../anilist';
import { AnsibleGalaxy } from '../ansiblegalaxy';
import { AO3 } from '../ao3';
import { ArchiveOrg } from '../archiveorg';
import { ArtStation } from '../artstation';
import { Audius } from '../audius';
import { AUR } from '../aur';
import { BaiduTieba } from '../baidutieba';
import { Bandcamp } from '../bandcamp';
import { Behance } from '../behance';
import { Bilibili } from '../bilibili';
import { Blogger } from '../blogger';
import { Bluesky } from '../bluesky';
import { CCMixter } from '../ccmixter';
import { ChessCom } from '../chesscom';
import { Codeberg } from '../codeberg';
import { Codeforces } from '../codeforces';
import { Codewars } from '../codewars';
import { CratesIo } from '../cratesio';
import { Dailymotion } from '../dailymotion';
import { DBLP } from '../dblp';
import { DEVCommunity } from '../devcommunity';
import { Discogs } from '../discogs';
import { DockerHub } from '../dockerhub';
import { Dribbble } from '../dribbble';
import { Elm } from '../elm';
import { Facebook } from '../facebook';
import { Fandom } from '../fandom';
import { Farcaster } from '../farcaster';
import { Flathub } from '../flathub';
import { Flickr } from '../flickr';
import { GameJolt } from '../gamejolt';
import { Github } from '../github';
import { GitLab } from '../gitlab';
import { Goodreads } from '../goodreads';
import { Gravatar } from '../gravatar';
import { Habr } from '../habr';
import { HackerNews } from '../hackernews';
import { HackerRank } from '../hackerrank';
import { Hashnode } from '../hashnode';
import { Hex } from '../hex';
import { Imgur } from '../imgur';
import { Instagram } from '../instagram';
import { InterPals } from '../interpals';
import { Itch } from '../itch';
import { Jsr } from '../jsr';
import { Keybase } from '../keybase';
import { Kick } from '../kick';
import { Kitsu } from '../kitsu';
import { LastFm } from '../lastfm';
import { LeetCode } from '../leetcode';
import { Lemmy } from '../lemmy';
import { Letterboxd } from '../letterboxd';
import { Lichess } from '../lichess';
import { LiveJournal } from '../livejournal';
import { Mastodon } from '../mastodon';
import { Medium } from '../medium';
import { MeWe } from '../mewe';
import { MicroBlog } from '../microblog';
import { Misskey } from '../misskey';
import { Mixcloud } from '../mixcloud';
import { Modrinth } from '../modrinth';
import { MyAnimeList } from '../myanimelist';
import { Nostr } from '../nostr';
import { Npm } from '../npmjs';
import { NuGet } from '../nuget';
import { OKru } from '../okru';
import { OpenCollective } from '../opencollective';
import { OpenLibrary } from '../openlibrary';
import { OpenVSX } from '../openvsx';
import { Orcid } from '../orcid';
import { OpenStreetMap } from '../osm';
import { Packagist } from '../packagist';
import { Patreon } from '../patreon';
import { PeerTube } from '../peertube';
import { Pinterest } from '../pinterest';
import { Plurk } from '../plurk';
import { PubDev } from '../pubdev';
import { PuppetForge } from '../puppetforge';
import { Quora } from '../quora';
import { Reddit } from '../reddit';
import { Roblox } from '../roblox';
import { RubyGems } from '../rubygems';
import { Scratch } from '../scratch';
import { Snapcraft } from '../snapcraft';
import { SpeedrunCom } from '../speedruncom';
import { StackExchange } from '../stackexchange';
import { StackOverflow } from '../stackoverflow';
import { SteamCommunity } from '../steamcommunity';
import { Substack } from '../substack';
import { Terraform } from '../terraform';
import { Threads } from '../threads';
import { TikTok } from '../tiktok';
import { Twitch } from '../twitch';
import { Vimeo } from '../vimeo';
import { VSCO } from '../vsco';
import { Wikipedia } from '../wikipedia';
import { WordPressCom } from '../wordpresscom';
import { X } from '../x';
import { YouTube } from '../youtube';

export const NO_AUTH = Object.fromEntries(CRAWL_TYPES.map((type) => [type, false])) as Record<CrawlType, boolean>;
export const ALL_AUTH = Object.fromEntries(CRAWL_TYPES.map((type) => [type, true])) as Record<CrawlType, boolean>;

export const CRAWL_ERRORS = {
  bot: 'bot_error',
  login: 'login_error',
  reach: 'reach_error'
} as const;

export const CRAWLERS: Record<string, Crawler> = {
  'academiaedu': new AcademiaEdu(),
  'amo': new AMO(),
  'anaconda': new Anaconda(),
  'anilist': new AniList(),
  'ansiblegalaxy': new AnsibleGalaxy(),
  'ao3': new AO3(),
  'archiveorg': new ArchiveOrg(),
  'artstation': new ArtStation(),
  'audius': new Audius(),
  'aur': new AUR(),
  'baidutieba': new BaiduTieba(),
  'bandcamp': new Bandcamp(),
  'behance': new Behance(),
  'bilibili': new Bilibili(),
  'blogger': new Blogger(),
  'bluesky': new Bluesky(),
  'ccmixter': new CCMixter(),
  'chesscom': new ChessCom(),
  'codeberg': new Codeberg(),
  'codeforces': new Codeforces(),
  'codewars': new Codewars(),
  'cratesio': new CratesIo(),
  'dailymotion': new Dailymotion(),
  'dblp': new DBLP(),
  'devcommunity': new DEVCommunity(),
  'discogs': new Discogs(),
  'dockerhub': new DockerHub(),
  'dribbble': new Dribbble(),
  'elm': new Elm(),
  'facebook': new Facebook(),
  'fandom': new Fandom(),
  'farcaster': new Farcaster(),
  'flathub': new Flathub(),
  'flickr': new Flickr(),
  'gamejolt': new GameJolt(),
  'github': new Github(),
  'gitlab': new GitLab(),
  'goodreads': new Goodreads(),
  'gravatar': new Gravatar(),
  'habr': new Habr(),
  'hackernews': new HackerNews(),
  'hackerrank': new HackerRank(),
  'hashnode': new Hashnode(),
  'hex': new Hex(),
  'imgur': new Imgur(),
  'instagram': new Instagram(),
  'interpals': new InterPals(),
  'itch': new Itch(),
  'jsr': new Jsr(),
  'keybase': new Keybase(),
  'kick': new Kick(),
  'kitsu': new Kitsu(),
  'lastfm': new LastFm(),
  'leetcode': new LeetCode(),
  'lemmy': new Lemmy(),
  'letterboxd': new Letterboxd(),
  'lichess': new Lichess(),
  'livejournal': new LiveJournal(),
  'mastodon': new Mastodon(),
  'medium': new Medium(),
  'mewe': new MeWe(),
  'microblog': new MicroBlog(),
  'misskey': new Misskey(),
  'mixcloud': new Mixcloud(),
  'modrinth': new Modrinth(),
  'myanimelist': new MyAnimeList(),
  'nostr': new Nostr(),
  'npm': new Npm(),
  'nuget': new NuGet(),
  'okru': new OKru(),
  'opencollective': new OpenCollective(),
  'openlibrary': new OpenLibrary(),
  'openvsx': new OpenVSX(),
  'orcid': new Orcid(),
  'osm': new OpenStreetMap(),
  'packagist': new Packagist(),
  'patreon': new Patreon(),
  'peertube': new PeerTube(),
  'pinterest': new Pinterest(),
  'plurk': new Plurk(),
  'pubdev': new PubDev(),
  'puppetforge': new PuppetForge(),
  'quora': new Quora(),
  'reddit': new Reddit(),
  'roblox': new Roblox(),
  'rubygems': new RubyGems(),
  'scratch': new Scratch(),
  'snapcraft': new Snapcraft(),
  'speedruncom': new SpeedrunCom(),
  'stackexchange': new StackExchange(),
  'stackoverflow': new StackOverflow(),
  'steamcommunity': new SteamCommunity(),
  'substack': new Substack(),
  'terraform': new Terraform(),
  'threads': new Threads(),
  'tiktok': new TikTok(),
  'twitch': new Twitch(),
  'vimeo': new Vimeo(),
  'vsco': new VSCO(),
  'wikipedia': new Wikipedia(),
  'wordpresscom': new WordPressCom(),
  'x': new X(),
  'youtube': new YouTube(),
};
