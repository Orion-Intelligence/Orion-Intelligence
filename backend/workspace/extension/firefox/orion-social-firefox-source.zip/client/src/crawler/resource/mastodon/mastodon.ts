import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { ApiPage } from './model';
import { api, apiPage, clean, cursorOf, lookup, origin, page, person } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const account = await lookup(tab, base, username);
    if (!account?.id) {
      return EMPTY;
    }

    const maxId = cursorOf(payload);
    const upstream = await apiPage(tab, base, `/api/v1/accounts/${account.id}/statuses`, limitOf(payload, 25, 40), maxId);
    return page(upstream.data.map((post: any): social_resource => {
      const source = post.reblog ?? post;
      const media: any[] = Array.isArray(source.media_attachments) ? source.media_attachments : [];
      const tags: any[] = Array.isArray(source.tags) ? source.tags : [];
      const mentions: any[] = Array.isArray(source.mentions) ? source.mentions : [];
      const emojis: any[] = Array.isArray(source.emojis) ? source.emojis : [];
      const poll = source.poll ?? {};
      const card = source.card ?? {};
      return {
        type: 'posts',
        resource_id: post.id ?? '',
        url: post.url ?? source.url ?? '',
        parent_url: account.url ?? `${base}/@${username}`,
        title: source.spoiler_text ?? '',
        caption: clean(source.content),
        author: source.account?.acct ?? account.acct ?? username,
        datetime: post.created_at ?? '',
        media_type: media[0]?.type ?? (post.reblog ? 'reblog' : 'text'),
        media_url: media[0]?.url ?? card.url ?? '',
        thumbnail_url: media[0]?.preview_url ?? card.image ?? '',
        likes: String((source.favourites_count ?? 0) || ''),
        shares: String((source.reblogs_count ?? 0) || ''),
        views: '',
        status_id: post.id ?? '',
        uri: post.uri ?? '',
        content: clean(source.content),
        content_length: clean(source.content).length,
        spoiler_text: source.spoiler_text ?? '',
        visibility: source.visibility ?? '',
        language: source.language ?? '',
        sensitive: source.sensitive ?? false,
        is_reblog: Boolean(post.reblog),
        reblog_id: post.reblog?.id ?? '',
        reblog_author: post.reblog?.account?.acct ?? '',
        reblog_url: post.reblog?.url ?? '',
        in_reply_to_id: source.in_reply_to_id ?? '',
        in_reply_to_account_id: source.in_reply_to_account_id ?? '',
        replies_count: source.replies_count ?? 0,
        reblogs_count: source.reblogs_count ?? 0,
        favourites_count: source.favourites_count ?? 0,
        quotes_count: source.quotes_count ?? 0,
        edited_at: source.edited_at ?? '',
        media_count: media.length,
        media_types: [...new Set(media.map((entry: any) => entry?.type ?? '').filter(Boolean))].join(', '),
        media_urls: media.map((entry: any) => entry?.url ?? '').filter(Boolean).join(', '),
        media_previews: media.map((entry: any) => entry?.preview_url ?? '').filter(Boolean).join(', '),
        media_descriptions: media.map((entry: any) => clean(entry?.description)).filter(Boolean).join(' | '),
        tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        tags_count: tags.length,
        mentions: mentions.map((mention: any) => mention?.acct ?? '').filter(Boolean).join(', '),
        mentions_count: mentions.length,
        emojis: emojis.map((emoji: any) => emoji?.shortcode ?? '').filter(Boolean).join(', '),
        poll_id: poll.id ?? '',
        poll_options: Array.isArray(poll.options) ? poll.options.map((option: any) => option?.title ?? '').filter(Boolean).join(' | ') : '',
        poll_votes: poll.votes_count ?? 0,
        poll_voters: poll.voters_count ?? 0,
        poll_expires_at: poll.expires_at ?? '',
        card_url: card.url ?? '',
        card_title: clean(card.title),
        card_description: clean(card.description).slice(0, 500),
        card_provider: card.provider_name ?? '',
        card_type: card.type ?? '',
        account_id: source.account?.id ?? account.id ?? '',
        account_acct: source.account?.acct ?? account.acct ?? '',
        account_display_name: source.account?.display_name ?? '',
        account_url: source.account?.url ?? '',
        account_avatar: source.account?.avatar ?? '',
        account_followers: source.account?.followers_count ?? 0,
        account_bot: source.account?.bot ?? false,
        application: source.application?.name ?? '',
        created_at: post.created_at ?? '',
      };
    }).filter((item) => item.url), upstream, maxId);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const account = await lookup(tab, base, username);
    if (!account?.id) {
      return EMPTY;
    }

    const maxId = cursorOf(payload);
    const upstream = await apiPage(tab, base, `/api/v1/accounts/${account.id}/followers`, limitOf(payload, 25, 80), maxId);
    return page(upstream.data.map((entry: any) => person(base, username, 'followers', entry)).filter((item) => item.url), upstream, maxId);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const username = String(payload.username ?? '');
  const tab = username ? await openSession(`${base}/`) : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const account = await lookup(tab, base, username);
    if (!account?.id) {
      return EMPTY;
    }

    const maxId = cursorOf(payload);
    const upstream = await apiPage(tab, base, `/api/v1/accounts/${account.id}/following`, limitOf(payload, 25, 80), maxId);
    return page(upstream.data.map((entry: any) => person(base, username, 'friends', entry)).filter((item) => item.url), upstream, maxId);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function connections(payload: CrawlPayload): Promise<CrawlPage> {
  const base = origin(payload);
  const postUrl = String(payload.url ?? '');
  const statusId = /\/(\d+)(?:[?#].*)?$/.exec(postUrl)?.[1] ?? '';
  if (!statusId) {
    return EMPTY;
  }
  const tab = await openSession(`${base}/`);
  if (!tab) {
    return EMPTY;
  }
  try {
    const context = await api(tab, base, `/api/v1/statuses/${statusId}/context`);
    const descendants: any[] = Array.isArray(context?.descendants) ? context.descendants : [];
    const seen = new Set<string>();
    const items: social_resource[] = [];
    for (const reply of descendants) {
      if (String(reply?.in_reply_to_id ?? '') !== statusId) {
        continue;
      }
      const account = reply?.account;
      const id = String(account?.id ?? '');
      if (!account?.url || seen.has(id)) {
        continue;
      }
      seen.add(id);
      items.push({
        ...person(base, '', 'connections', account),
        parent_url: postUrl,
        caption: clean(reply.content).slice(0, 600),
        comment_id: reply.id ?? '',
        comment_text: clean(reply.content),
        comment_url: reply.url ?? '',
        comment_at: reply.created_at ?? '',
        handle: account.acct ?? account.username ?? '',
      });
    }
    return { items };
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

