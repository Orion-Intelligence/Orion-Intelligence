import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { connections, organizations, posts } from './resource/devcommunity/devcommunity';

export class DEVCommunity implements Crawler {
  readonly platform = 'devcommunity';
  readonly base = 'https://dev.to';
  readonly loginUrl = 'https://dev.to/enter';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://dev.to/api/users/by_username?url=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.id) {
        return [];
      }

      return [{
        real_name: data.name ?? data.username ?? username,
        bio: data.summary ?? '',
        description: data.summary ?? '',
        location: data.location ?? '',
        profile_url: `https://dev.to/${data.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: data.profile_image ?? '',
        banner: '',
        crawl_type: ['details', 'posts', 'organizations', 'connections'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? 0,
        account_type: data.type_of ?? '',
        website: data.website_url ?? '',
        twitter: data.twitter_username ?? '',
        github: data.github_username ?? '',
        joined_at: data.joined_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://dev.to/api/users/me', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id || data?.username);
    }
    catch {
      return false;
    }
  }
}
