import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export function origin(payload: CrawlPayload): string {
  return /^https?:\/\/[^/]+/.exec(payload.url ?? '')?.[0] ?? 'https://community.fandom.com';
}

export async function api(tab: TabController, base: string, params: Record<string, string>): Promise<any> {
  try {
    const query = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params });
    const response = await tab.fetch(`${base}/api.php?${query.toString()}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function continuation(payload: CrawlPayload): Record<string, string> {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return {};
  }

  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {};
    }
    return Object.fromEntries(Object.entries(parsed).filter(([, value]) => typeof value === 'string' || typeof value === 'number').map(([key, value]) => [key, String(value)]));
  }
  catch {
    return {};
  }
}

export function page(items: social_resource[], data: any, payload: CrawlPayload): CrawlPage {
  const next = data?.continue;
  if (!items.length || !next || typeof next !== 'object' || !Object.keys(next).length) {
    return { items };
  }

  const nextCursor = JSON.stringify(next);
  return { items, next_cursor: nextCursor !== String(payload.cursor ?? '').trim() ? nextCursor : undefined };
}
