import { TabController } from '../tab_management/tab.controller';
import { TabQueryItem } from '../tab_management/tab.helper';

export interface Identity {
  loggedIn: boolean;
  username: string;
}

export const NO_IDENTITY: Identity = { loggedIn: false, username: '' };

const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

export async function tabJson(tab: TabController, url: string, headers?: Record<string, string>): Promise<any> {
  const response = await tab.fetch(url, headers ? { headers } : undefined);
  if (!response.ok) {
    return null;
  }
  try {
    return JSON.parse(response.body);
  }
  catch {
    return null;
  }
}

export async function pollQuery(tab: TabController, selector: string, test: (items: TabQueryItem[]) => Identity | null, attempts = 16): Promise<Identity | null> {
  for (let index = 0; index < attempts; index += 1) {
    const result = test(await tab.query(selector));
    if (result) {
      return result;
    }
    await sleep(500);
  }
  return null;
}

export async function identityJson(tab: TabController, url: string, read: (data: any) => Identity | null): Promise<Identity> {
  const data = await tabJson(tab, url, { Accept: 'application/json' });
  return (data && read(data)) || NO_IDENTITY;
}

export async function identityRedirect(tab: TabController, url: string, loggedOut: RegExp): Promise<Identity> {
  const finalUrl = await tab.navigate(url);
  if (!finalUrl || loggedOut.test(finalUrl)) {
    return NO_IDENTITY;
  }
  return { loggedIn: true, username: '' };
}

export async function identityStays(tab: TabController, url: string, stays: RegExp): Promise<Identity> {
  const finalUrl = await tab.navigate(url);
  return finalUrl && stays.test(finalUrl) ? { loggedIn: true, username: '' } : NO_IDENTITY;
}

export async function identityHtml(tab: TabController, url: string, loggedOut: RegExp): Promise<Identity> {
  const response = await tab.fetch(url);
  if (!response.ok || loggedOut.test(response.body)) {
    return NO_IDENTITY;
  }
  return { loggedIn: true, username: '' };
}
