import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://rubygems.org/api/v1${path}`, { headers: { Accept: 'application/json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function offsetOf(payload: CrawlPayload): number {
  const raw = String(payload.cursor ?? '').trim();
  if (!raw) {
    return 0;
  }

  try {
    const parsed = JSON.parse(raw);
    const offset = Number(typeof parsed === 'object' && parsed !== null ? parsed.offset : parsed);
    return Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0;
  }
  catch {
    const offset = Number(raw);
    return Number.isFinite(offset) && offset > 0 ? Math.floor(offset) : 0;
  }
}

export function page(items: social_resource[], offset: number, total: number): CrawlPage {
  const next = offset + items.length;
  return { items, next_cursor: items.length && next < total ? JSON.stringify({ offset: next }) : undefined };
}
