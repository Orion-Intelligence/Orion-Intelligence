import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';

export function decode(value: string): string {
  return value.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export async function page(tab: TabController, url: string): Promise<string> {
  try {
    const response = await tab.fetch(url);
    return response.ok ? response.body : '';
  }
  catch {
    return '';
  }
}

export function rows(html: string): string[] {
  return [...html.matchAll(/<tr[^>]*class="[^"]*chartlist-row[^"]*"[\s\S]*?<\/tr>/g)].map((match) => match[0]);
}

export function count(row: string): number {
  return Number((/chartlist-count-bar-value">\s*([\d,]+)/.exec(row)?.[1] ?? '').replace(/,/g, '')) || 0;
}

export function pageOf(payload: CrawlPayload): number {
  const parsed = Number(String(payload.cursor ?? '').trim());
  return Number.isInteger(parsed) && parsed > 1 ? parsed : 1;
}

export function hasNextPage(html: string, current: number): boolean {
  if (/class="[^"]*pagination-next[^"]*"[\s\S]{0,400}?href="[^"]*[?&;](?:amp;)?page=\d+/i.test(html)) {
    return true;
  }

  const nav = /<(?:nav|ul)[^>]*class="[^"]*pagination[^"]*"[\s\S]*?<\/(?:nav|ul)>/i.exec(html)?.[0] ?? '';
  const pages = [...nav.matchAll(/[?&;](?:amp;)?page=(\d+)/g)].map((match) => Number(match[1])).filter((value) => Number.isFinite(value));
  return pages.length > 0 && Math.max(...pages) > current;
}

export async function library(payload: CrawlPayload, section: 'tracks' | 'albums' | 'artists', build: (row: string, username: string) => social_resource): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  if (!username) {
    return EMPTY;
  }

  const tab = await openSession('https://www.last.fm/');
  if (!tab) {
    return EMPTY;
  }

  try {
    const current = pageOf(payload);
    const html = await page(tab, `https://www.last.fm/user/${encodeURIComponent(username)}/library/${section}?page=${current}`);
    if (!html && current === 1) {
      const items = rows(await page(tab, `https://www.last.fm/user/${encodeURIComponent(username)}`)).map((row) => build(row, username)).filter((item) => item.url);
      return { items };
    }

    const items = rows(html).map((row) => build(row, username)).filter((item) => item.url);
    return { items, next_cursor: items.length && hasNextPage(html, current) ? String(current + 1) : undefined };
  }
  finally {
    await tab.close();
  }
}
