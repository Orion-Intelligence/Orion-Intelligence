import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, friends, games, posts } from './resource/gamejolt/gamejolt';

export class GameJolt implements Crawler {
  readonly platform = 'gamejolt';
  readonly base = 'https://gamejolt.com';
  readonly loginUrl = 'https://gamejolt.com/login';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://gamejolt.com/site-api/web/profile/@${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const payload = await response.json();
      const data = payload?.payload?.user;
      if (!data?.id) {
        return [];
      }

      const bio = (() => {
        const raw = String(data.bio_content ?? '');
        try {
          const texts: string[] = [];
          const walk = (node: any): void => {
            if (!node) {
              return;
            }
            if (typeof node.text === 'string') {
              texts.push(node.text);
            }
            for (const child of Array.isArray(node.content) ? node.content : []) {
              walk(child);
            }
          };
          walk(JSON.parse(raw));
          return texts.join(' ').replace(/\s+/g, ' ').trim();
        }
        catch {
          return raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        }
      })();

      const dogtags: any[] = Array.isArray(data.dogtags) ? data.dogtags : [];

      return [{
        real_name: data.display_name ?? data.username ?? username,
        bio,
        description: bio,
        location: '',
        profile_url: `https://gamejolt.com/@${data.username ?? username}`,
        total_posts: '',
        total_followers: String((data.follower_count ?? 0) || ''),
        total_likes: String((data.like_count ?? 0) || ''),
        avatar: data.img_avatar ?? '',
        banner: data.header_media_item?.img_url ?? '',
        crawl_type: ['details', 'games', 'posts', 'followers', 'friends'],
        platform: this.platform,
        username: data.username ?? username,
        user_id: data.id ?? 0,
        display_name: data.display_name ?? '',
        account_type: data.type ?? '',
        website: data.web_site ?? '',
        gamejolt_url: data.url ?? `https://gamejolt.com/@${data.username ?? username}`,
        follower_count: data.follower_count ?? 0,
        like_count: data.like_count ?? 0,
        comment_count: data.comment_count ?? 0,
        status: data.status ?? 0,
        permission_level: data.permission_level ?? 0,
        shouts_enabled: data.shouts_enabled ?? false,
        friend_requests_enabled: data.friend_requests_enabled ?? false,
        liked_posts_enabled: data.liked_posts_enabled ?? false,
        disable_gravatar: data.disable_gravatar ?? false,
        dogtags: dogtags.map((d: any) => (typeof d === 'string' ? d : d?.text ?? '')).filter(Boolean).join(', '),
        verified: data.is_verified ?? false,
        created_at: data.created_on ? new Date(data.created_on).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://gamejolt.com/site-api/web/dash/main', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.payload?.user?.id);
    }
    catch {
      return false;
    }
  }
}
