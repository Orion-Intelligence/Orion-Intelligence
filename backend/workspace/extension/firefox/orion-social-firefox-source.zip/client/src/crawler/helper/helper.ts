import { CrawlPayload, CrawlType, social_resource } from '../../app/extension/model/extension.model';

export class Helper {
  static blank_resource(type: CrawlType): social_resource {
    return { type, resource_id: '', url: '', parent_url: '', title: '', caption: '', author: '', datetime: '', media_type: '', media_url: '', thumbnail_url: '', likes: '', shares: '', views: '' };
  }
}

export function limitOf(payload: CrawlPayload | null | undefined, fallback: number, max: number = fallback): number {
  const requested = Number(payload?.limit);
  if (!Number.isFinite(requested) || requested <= 0) {
    return fallback;
  }
  return Math.max(1, Math.min(Math.floor(requested), max));
}
