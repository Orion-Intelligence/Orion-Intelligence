export interface GamesCursor {
  archive: string;
  offset: number;
}
