import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { TabController } from '../../tab_management/tab.controller';
import { ApiResponse } from './model';

export async function api(tab: TabController, path: string): Promise<ApiResponse> {
  try {
    const response = await tab.fetch(`https://api.stackexchange.com/2.3${path}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) {
      return { items: [], has_more: false };
    }
    const data = JSON.parse(response.body);
    return { items: Array.isArray(data?.items) ? data.items : [], has_more: Boolean(data?.has_more) };
  }
  catch {
    return { items: [], has_more: false };
  }
}

export function pageOf(payload: CrawlPayload): number {
  const parsed = Number.parseInt(String(payload.cursor ?? '').trim(), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
}

export function pagedPath(path: string, payload: CrawlPayload): string {
  return `${path}&page=${pageOf(payload)}&pagesize=${limitOf(payload, 25, 100)}`;
}

export function page(items: social_resource[], data: ApiResponse, payload: CrawlPayload): CrawlPage {
  return { items, next_cursor: items.length && data.has_more ? String(pageOf(payload) + 1) : undefined };
}

export function stamp(value: unknown): string {
  const seconds = Number(value);
  return Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : '';
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
}

export function owner(entry: any): Record<string, unknown> {
  const user = entry.owner ?? {};
  return {
    owner_user_id: user.user_id ?? 0,
    owner_account_id: user.account_id ?? 0,
    owner_display_name: user.display_name ?? '',
    owner_reputation: user.reputation ?? 0,
    owner_user_type: user.user_type ?? '',
    owner_accept_rate: user.accept_rate ?? 0,
    owner_profile_image: user.profile_image ?? '',
    owner_link: user.link ?? '',
  };
}
