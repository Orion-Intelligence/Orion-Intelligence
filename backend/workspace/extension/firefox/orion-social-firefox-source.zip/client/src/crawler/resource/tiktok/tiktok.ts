import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { ItemPage } from './model';
import { account, clean, cookie, items, pageOf, post, stamp } from './helper';

export async function videos(payload: CrawlPayload): Promise<CrawlPage> {
  return pageOf(payload, 'videos');
}
