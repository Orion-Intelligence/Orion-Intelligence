import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { TabController } from './tab_management/tab.controller';
import { Identity, identityRedirect } from './helper/identity';
import { ALL_AUTH } from './constant/crawlers';
import { posts } from './resource/mewe/mewe';

export class MeWe implements Crawler {
  readonly platform = 'mewe';
  readonly base = 'https://mewe.com';
  readonly loginUrl = 'https://mewe.com/login';
  readonly authwall = ALL_AUTH;
  readonly profiling = true;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://mewe.com/i/${encodeURIComponent(username)}`, { redirect: 'follow', credentials: 'include' });
      if (!response.ok) {
        return [];
      }
      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');

      const displayName = (meta('og:title') || decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '')).replace(/\s*[|-]\s*MeWe.*$/i, '').trim();
      const description = meta('og:description');
      if (!displayName || /^mewe$/i.test(displayName) || /^Brilliant features with no BS/i.test(description)) {
        return [];
      }

      return [{
        real_name: displayName,
        bio: /^Brilliant features with no BS/i.test(description) ? '' : description,
        description: /^Brilliant features with no BS/i.test(description) ? '' : description,
        location: '',
        profile_url: `https://mewe.com/i/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: username,
      }];
    }
    catch {
      return [];
    }
  }

  async identity(tab: TabController): Promise<Identity> {
    return identityRedirect(tab, 'https://mewe.com/', /\/(register|login|signin)/i);
  }



  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://mewe.com/api/v2/me/info', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.id || data?.publicLinkId);
    }
    catch {
      return false;
    }
  }
}
