import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { EMPTY } from './constant';
import { api, clean, page, pageOf } from './helper';

export async function repositories(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://hub.docker.com/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const current = pageOf(payload);
    const list = await api(tab, `/repositories/${encodeURIComponent(username)}/?page=${current}&page_size=${limitOf(payload, 25, 100)}&ordering=last_updated`);
    const items = (Array.isArray(list?.results) ? list.results : []) as any[];
    const fulls = await Promise.all(items.map((repo: any) => api(tab, `/repositories/${encodeURIComponent(repo.namespace ?? username)}/${encodeURIComponent(repo.name ?? '')}/`)));
    const tagsets = await Promise.all(items.map((repo: any) => api(tab, `/repositories/${encodeURIComponent(repo.namespace ?? username)}/${encodeURIComponent(repo.name ?? '')}/tags/?page_size=25&ordering=last_updated`)));

    return page(items.map((repo: any, index: number): social_resource => {
      const full: any = fulls[index] ?? {};
      const tags: any[] = Array.isArray(tagsets[index]?.results) ? tagsets[index].results : [];
      const images: any[] = tags.flatMap((tag: any) => (Array.isArray(tag?.images) ? tag.images : []));
      const namespace = repo.namespace ?? username;
      return {
        type: 'repositories',
        resource_id: `${namespace}/${repo.name ?? ''}`,
        url: `https://hub.docker.com/r/${namespace}/${repo.name ?? ''}`,
        parent_url: `https://hub.docker.com/u/${username}`,
        title: repo.name ?? '',
        caption: clean(repo.description),
        author: namespace,
        datetime: repo.last_updated ?? '',
        media_type: repo.repository_type ?? 'image',
        media_url: `docker pull ${namespace}/${repo.name ?? ''}`,
        thumbnail_url: '',
        likes: String((repo.star_count ?? 0) || ''),
        shares: '',
        views: String((repo.pull_count ?? 0) || ''),
        name: repo.name ?? '',
        namespace,
        full_name: `${namespace}/${repo.name ?? ''}`,
        description: clean(repo.description),
        full_description: clean(full.full_description).slice(0, 4000),
        repository_type: repo.repository_type ?? '',
        status: repo.status ?? 0,
        status_description: repo.status_description ?? '',
        is_private: repo.is_private ?? false,
        is_automated: full.is_automated ?? false,
        star_count: repo.star_count ?? 0,
        pull_count: repo.pull_count ?? 0,
        storage_size: repo.storage_size ?? 0,
        collaborator_count: full.collaborator_count ?? 0,
        affiliation: repo.affiliation ?? '',
        hub_user: full.hub_user ?? '',
        media_types: Array.isArray(repo.media_types) ? repo.media_types.join(', ') : '',
        content_types: Array.isArray(repo.content_types) ? repo.content_types.join(', ') : '',
        categories: Array.isArray(repo.categories) ? repo.categories.map((category: any) => category?.name ?? category?.slug ?? '').filter(Boolean).join(', ') : '',
        permission_read: full.permissions?.read ?? false,
        permission_write: full.permissions?.write ?? false,
        permission_admin: full.permissions?.admin ?? false,
        tags_count: tags.length,
        tags: tags.map((tag: any) => tag?.name ?? '').filter(Boolean).join(', '),
        latest_tag: tags[0]?.name ?? '',
        latest_tag_size: tags[0]?.full_size ?? 0,
        latest_tag_digest: tags[0]?.digest ?? '',
        latest_tag_updated: tags[0]?.last_updated ?? '',
        latest_tag_status: tags[0]?.tag_status ?? '',
        architectures: [...new Set(images.map((image: any) => image?.architecture ?? '').filter(Boolean))].join(', '),
        operating_systems: [...new Set(images.map((image: any) => image?.os ?? '').filter(Boolean))].join(', '),
        variants: [...new Set(images.map((image: any) => image?.variant ?? '').filter(Boolean))].join(', '),
        images_count: images.length,
        total_tag_size: tags.reduce((sum: number, tag: any) => sum + (tag?.full_size ?? 0), 0),
        last_updated: repo.last_updated ?? '',
        last_modified: repo.last_modified ?? '',
        date_registered: repo.date_registered ?? '',
      };
    }).filter((item) => item.title), list, current);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}
