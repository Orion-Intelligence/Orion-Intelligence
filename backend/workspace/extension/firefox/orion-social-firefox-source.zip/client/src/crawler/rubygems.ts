import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { repositories } from './resource/rubygems/rubygems';

export class RubyGems implements Crawler {
  readonly platform = 'rubygems';
  readonly base = 'https://rubygems.org';
  readonly loginUrl = 'https://rubygems.org/sign_in';
  readonly authwall = NO_AUTH;

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'repositories':
        return repositories(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://rubygems.org/profiles/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      if (!/Profile of/i.test(title)) {
        return [];
      }

      const stat = (label: string): number => Number((new RegExp(`${label}[\\s\\S]{0,200}?([\\d,]{1,15})`, 'i').exec(html)?.[1] ?? '0').replace(/,/g, '')) || 0;
      const gems = [...html.matchAll(/href="\/gems\/([^"]+)"/g)].map((match) => match[1]);
      return [{
        real_name: title.replace(/^Profile of\s*/i, '').replace(/\s*\|.*$/, '').trim(),
        bio: '',
        description: '',
        location: '',
        profile_url: `https://rubygems.org/profiles/${username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: /<img[^>]+class="[^"]*gravatar[^"]*"[^>]+src="([^"]+)"/i.exec(html)?.[1] ?? '',
        banner: '',
        crawl_type: ['details', 'repositories'],
        platform: this.platform,
        username: username,
        gems: new Set(gems).size,
        totalDownloads: stat('Total downloads'),
        topGem: gems[0] ?? '',
        joined: decode(/Joined[\s\S]{0,120}?<time[^>]*>([\s\S]*?)<\/time>/i.exec(html)?.[1] ?? ''),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://rubygems.org/settings/edit', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/sign_in/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
