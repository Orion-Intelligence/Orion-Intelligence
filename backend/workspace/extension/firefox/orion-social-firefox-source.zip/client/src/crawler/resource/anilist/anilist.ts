import { CrawlPage, CrawlPayload, social_resource } from '../../../app/extension/model/extension.model';
import { limitOf } from '../../helper/helper';
import { openSession, TabController } from '../../tab_management/tab.controller';
import { ACTIVITY_FIELDS, EMPTY, REVIEW_FIELDS, USER_FIELDS } from './constant';
import { Cursor } from './model';
import { graphql, page, pagedQuery, parseCursor, person, stamp, text, userId } from './helper';

export async function posts(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://anilist.co/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { id, entries, nextCursor } = await pagedQuery(tab, payload, username, 'activities', ', sort: ID_DESC', ACTIVITY_FIELDS);
    if (!id) {
      return EMPTY;
    }

    return page(entries.map((activity: any): social_resource => {
      const media = activity.media ?? {};
      const actor = activity.user ?? activity.messenger ?? {};
      return {
        type: 'posts',
        resource_id: String(activity.id ?? ''),
        url: activity.siteUrl ?? '',
        parent_url: `https://anilist.co/user/${username}`,
        title: media.title?.romaji ?? media.title?.english ?? '',
        caption: text(activity.text ?? activity.message ?? `${activity.status ?? ''} ${activity.progress ?? ''}`),
        author: actor.name ?? username,
        datetime: stamp(activity.createdAt),
        media_type: String(activity.type ?? '').toLowerCase() || (activity.text ? 'text' : 'list'),
        media_url: media.siteUrl ?? '',
        thumbnail_url: media.coverImage?.large ?? actor.avatar?.large ?? '',
        likes: String((activity.likeCount ?? 0) || ''),
        shares: '',
        views: '',
        activity_id: activity.id ?? 0,
        activity_type: activity.type ?? '',
        user_id: activity.userId ?? id,
        user_name: actor.name ?? username,
        user_url: actor.siteUrl ?? '',
        user_avatar: actor.avatar?.large ?? '',
        body: text(activity.text ?? activity.message),
        status: activity.status ?? '',
        progress: activity.progress ?? '',
        replies: activity.replyCount ?? 0,
        is_liked: activity.isLiked ?? false,
        is_locked: activity.isLocked ?? false,
        is_subscribed: activity.isSubscribed ?? false,
        is_private: activity.isPrivate ?? false,
        recipient_id: activity.recipientId ?? 0,
        messenger_id: activity.messengerId ?? 0,
        media_id: media.id ?? 0,
        media_mal_id: media.idMal ?? 0,
        media_title_romaji: media.title?.romaji ?? '',
        media_title_english: media.title?.english ?? '',
        media_title_native: media.title?.native ?? '',
        media_format: media.format ?? '',
        media_status: media.status ?? '',
        media_episodes: media.episodes ?? 0,
        media_chapters: media.chapters ?? 0,
        media_volumes: media.volumes ?? 0,
        media_average_score: media.averageScore ?? 0,
        media_mean_score: media.meanScore ?? 0,
        media_popularity: media.popularity ?? 0,
        media_favourites: media.favourites ?? 0,
        media_genres: Array.isArray(media.genres) ? media.genres.join(', ') : '',
        media_season_year: media.seasonYear ?? 0,
        media_country: media.countryOfOrigin ?? '',
        media_is_adult: media.isAdult ?? false,
        media_cover: media.coverImage?.large ?? '',
        media_banner: media.bannerImage ?? '',
        created_at: stamp(activity.createdAt),
      };
    }).filter((item) => item.url), nextCursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function reviews(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://anilist.co/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { id, entries, nextCursor } = await pagedQuery(tab, payload, username, 'reviews', ', sort: CREATED_AT_DESC', REVIEW_FIELDS);
    if (!id) {
      return EMPTY;
    }

    return page(entries.map((review: any): social_resource => {
      const media = review.media ?? {};
      return {
        type: 'reviews',
        resource_id: String(review.id ?? ''),
        url: review.siteUrl ?? '',
        parent_url: `https://anilist.co/user/${username}`,
        title: media.title?.romaji ?? media.title?.english ?? review.summary ?? '',
        caption: text(review.summary),
        author: review.user?.name ?? username,
        datetime: stamp(review.createdAt),
        media_type: String(review.mediaType ?? '').toLowerCase(),
        media_url: media.siteUrl ?? '',
        thumbnail_url: media.coverImage?.large ?? '',
        likes: String((review.rating ?? 0) || ''),
        shares: '',
        views: '',
        review_id: review.id ?? 0,
        user_id: review.userId ?? id,
        user_name: review.user?.name ?? username,
        user_url: review.user?.siteUrl ?? '',
        user_avatar: review.user?.avatar?.large ?? '',
        summary: text(review.summary),
        body: text(review.body).slice(0, 4000),
        body_length: String(review.body ?? '').length,
        score: review.score ?? 0,
        rating: review.rating ?? 0,
        rating_amount: review.ratingAmount ?? 0,
        is_private: review.private ?? false,
        media_id: review.mediaId ?? media.id ?? 0,
        media_mal_id: media.idMal ?? 0,
        media_title_romaji: media.title?.romaji ?? '',
        media_title_english: media.title?.english ?? '',
        media_title_native: media.title?.native ?? '',
        media_format: media.format ?? '',
        media_status: media.status ?? '',
        media_episodes: media.episodes ?? 0,
        media_chapters: media.chapters ?? 0,
        media_volumes: media.volumes ?? 0,
        media_average_score: media.averageScore ?? 0,
        media_mean_score: media.meanScore ?? 0,
        media_popularity: media.popularity ?? 0,
        media_favourites: media.favourites ?? 0,
        media_genres: Array.isArray(media.genres) ? media.genres.join(', ') : '',
        media_season_year: media.seasonYear ?? 0,
        media_country: media.countryOfOrigin ?? '',
        media_is_adult: media.isAdult ?? false,
        media_cover: media.coverImage?.large ?? '',
        media_banner: media.bannerImage ?? '',
        created_at: stamp(review.createdAt),
        updated_at: stamp(review.updatedAt),
      };
    }).filter((item) => item.url), nextCursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function followers(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://anilist.co/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { id, entries, nextCursor } = await pagedQuery(tab, payload, username, 'followers', ', sort: ID', USER_FIELDS);
    if (!id) {
      return EMPTY;
    }

    return page(entries.map((entry: any) => person(username, 'followers', entry)).filter((item) => item.url), nextCursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

export async function friends(payload: CrawlPayload): Promise<CrawlPage> {
  const username = String(payload.username ?? '');
  const tab = username ? await openSession('https://anilist.co/') : null;
  if (!tab) {
    return EMPTY;
  }
  try {
    const { id, entries, nextCursor } = await pagedQuery(tab, payload, username, 'following', ', sort: ID', USER_FIELDS);
    if (!id) {
      return EMPTY;
    }

    return page(entries.map((entry: any) => person(username, 'friends', entry)).filter((item) => item.url), nextCursor);
  }
  catch {
    return EMPTY;
  }
  finally {
    await tab.close();
  }
}

