import { TabController } from '../../tab_management/tab.controller';
import { OrgCursor } from './model';

export async function api(tab: TabController, path: string): Promise<any> {
  try {
    const response = await tab.fetch(`https://dev.to/api/${path}`, { headers: { Accept: 'application/vnd.forem.api-v1+json' } });
    return response.ok ? JSON.parse(response.body) : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export function pageNumber(value: unknown): number {
  const parsed = Math.floor(Number(value));
  return Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
}

export async function articlesPage(tab: TabController, username: string, page: number, perPage: number): Promise<any[]> {
  const list = await api(tab, `articles?username=${encodeURIComponent(username)}&page=${page}&per_page=${perPage}`);
  return (Array.isArray(list) ? list : []) as any[];
}

export function parseOrgCursor(value: unknown): OrgCursor | null {
  const raw = String(value ?? '').trim();
  if (!raw) {
    return null;
  }

  try {
    const parsed: any = JSON.parse(raw);
    const strings = (list: unknown): string[] => (Array.isArray(list) ? list : []).map((entry) => String(entry ?? '')).filter(Boolean);
    return { page: pageNumber(parsed?.page), seen: strings(parsed?.seen), pending: strings(parsed?.pending) };
  }
  catch {
    return null;
  }
}
