import { CrawlPage, social_resource } from '../../../app/extension/model/extension.model';
import { TabController } from '../../tab_management/tab.controller';

export async function gql(tab: TabController, query: string, variables: Record<string, unknown>): Promise<any> {
  try {
    const response = await tab.fetch('https://gql.twitch.tv/gql', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', 'Client-ID': 'kimne78kx3ncx6brgo4mv6wki5h1ko' },
      body: JSON.stringify({ query, variables }),
    });
    return response.ok ? (JSON.parse(response.body))?.data ?? null : null;
  }
  catch {
    return null;
  }
}

export function clean(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function thumb(url: unknown, width = 640, height = 360): string {
  return String(url ?? '').replace('%{width}', String(width)).replace('%{height}', String(height));
}

export function page(items: social_resource[], edges: any[], connection: any, incoming: string): CrawlPage {
  const hasNext = Boolean(connection?.pageInfo?.hasNextPage);
  const last = edges.length ? String(edges[edges.length - 1]?.cursor ?? '').trim() : '';
  const next = hasNext && items.length && last && last !== incoming ? last : undefined;
  return { items, next_cursor: next };
}
