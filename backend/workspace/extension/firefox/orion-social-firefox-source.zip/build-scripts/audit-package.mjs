import { lstatSync, readFileSync, readdirSync } from 'node:fs';
import { relative, resolve } from 'node:path';

const packagePath = process.argv[2];

if (!packagePath) {
  throw new Error('Usage: node scripts/audit-package.mjs <package-directory>');
}

const packageRoot = resolve(packagePath);
const isDevPackage = process.argv[3] === 'dev';
const allowedFiles = new Set([
  '3rdpartylicenses.txt',
  'assets/images/icon-16.png',
  'assets/core/orion-bridge.js',
  'assets/core/orion-service.js',
  'assets/core/routes.js',
  'assets/core/activity-store.js',
  'assets/core/backend.js',
  'assets/core/capture-page.js',
  'assets/core/cookies.js',
  'assets/core/crawl.js',
  'assets/core/runner.js',
  'assets/core/session-capture.js',
  'assets/core/verify.js',
  'assets/tab/tab-service.js',
  'assets/verifying.html',
  'assets/verify-overlay.js',
  'assets/images/icon-32.png',
  'assets/images/icon-48.png',
  'assets/images/icon-128.png',
  'index.html',
  'main.js',
  'manifest.json',
  'styles.css'
]);
const requiredFiles = new Set([
  'assets/images/icon-16.png',
  'assets/core/orion-bridge.js',
  'assets/core/orion-service.js',
  'assets/core/routes.js',
  'assets/core/activity-store.js',
  'assets/core/backend.js',
  'assets/core/capture-page.js',
  'assets/core/cookies.js',
  'assets/core/crawl.js',
  'assets/core/runner.js',
  'assets/core/session-capture.js',
  'assets/core/verify.js',
  'assets/tab/tab-service.js',
  'assets/verify-overlay.js',
  'assets/images/icon-32.png',
  'assets/images/icon-48.png',
  'assets/images/icon-128.png',
  'index.html',
  'main.js',
  'manifest.json',
  'styles.css'
]);

function fail(message) {
  throw new Error(`Package security audit failed: ${message}`);
}

function collectFiles(directory) {
  const files = [];

  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const absolutePath = resolve(directory, entry.name);
    const stat = lstatSync(absolutePath);

    if (stat.isSymbolicLink()) {
      fail(`symbolic links are not allowed (${relative(packageRoot, absolutePath)})`);
    }

    if (entry.isDirectory()) {
      files.push(...collectFiles(absolutePath));
    }
    else if (entry.isFile()) {
      files.push(relative(packageRoot, absolutePath).replaceAll('\\', '/'));
    }
    else {
      fail(`unsupported file type (${relative(packageRoot, absolutePath)})`);
    }
  }

  return files;
}

const packagedFiles = collectFiles(packageRoot);

for (const file of packagedFiles) {
  if (!allowedFiles.has(file)) {
    fail(`unexpected file ${file}`);
  }
}

for (const file of requiredFiles) {
  if (!packagedFiles.includes(file)) {
    fail(`missing required file ${file}`);
  }
}

const manifest = JSON.parse(String(readFileSync(resolve(packageRoot, 'manifest.json'), 'utf8')));
const expectedCsp = "script-src 'self'; object-src 'self'";

if (manifest.manifest_version !== 3) {
  fail('manifest_version must be 3');
}

const allowedPermissions = ['alarms', 'cookies', 'offscreen', 'scripting', 'storage'];
if (!Array.isArray(manifest.permissions) || manifest.permissions.some(permission => !allowedPermissions.includes(permission))) {
  fail(`extension permissions must be limited to ${allowedPermissions.join(', ')}`);
}

const allowedHostPermissions = ['<all_urls>'];
const declaredHostPermissions = [...(manifest.host_permissions ?? []), ...(manifest.optional_host_permissions ?? [])];

if (
  declaredHostPermissions.length !== allowedHostPermissions.length
  || !allowedHostPermissions.every(host => declaredHostPermissions.includes(host))
) {
  fail(`host permissions must be limited to ${allowedHostPermissions.join(', ')}`);
}


if (manifest.content_security_policy?.extension_pages !== expectedCsp) {
  fail(`extension CSP must be ${expectedCsp}`);
}

const html = String(readFileSync(resolve(packageRoot, 'index.html'), 'utf8'));
const scriptTags = html.match(/<script\b[^>]*>/gi) ?? [];

if (scriptTags.some(tag => !/\bsrc\s*=/.test(tag))) {
  fail('inline scripts are not allowed');
}

if (scriptTags.some(tag => /\bsrc\s*=\s*["'](?:https?:)?\/\//i.test(tag))) {
  fail('remote scripts are not allowed');
}

const javascript = String(readFileSync(resolve(packageRoot, 'main.js'), 'utf8'));
const forbiddenJavaScript = [
  [/\beval\s*\(/, 'eval()'],
  [/new\s+Function\s*\(/, 'new Function()'],
  [/sourceMappingURL/, 'source map reference'],
  ...(isDevPackage ? [] : [[/http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?/i, 'insecure local HTTP endpoint']])
];

for (const [pattern, description] of forbiddenJavaScript) {
  if (pattern.test(javascript)) {
    fail(`${description} found in main.js`);
  }
}

const secretPatterns = [
  [/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/, 'private key'],
  [/\bAKIA[0-9A-Z]{16}\b/, 'AWS access key'],
  [/\bAIza[0-9A-Za-z_-]{35}\b/, 'Google API key'],
  [/\bgh[pousr]_[0-9A-Za-z]{36,255}\b/, 'GitHub token']
];

for (const file of packagedFiles.filter(file => /\.(?:css|html|js|json|txt)$/.test(file))) {
  const contents = String(readFileSync(resolve(packageRoot, file), 'utf8'));

  for (const [pattern, description] of secretPatterns) {
    if (pattern.test(contents)) {
      fail(`${description} found in ${file}`);
    }
  }
}

console.log(`Package security audit passed: ${packageRoot}`);
