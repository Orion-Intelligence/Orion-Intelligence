import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const [
  sourceDirectory,
  updateUrlValue,
  xpiUrlValue,
  updatesFile
] = process.argv.slice(2);

if (!sourceDirectory) {
  throw new Error(
    'Usage: node prepare-firefox-hosted-package.mjs '
    + '<source-directory> [<update-url> <xpi-url> <updates-file>]'
  );
}

const updateArguments = [updateUrlValue, xpiUrlValue, updatesFile];
const shouldGenerateUpdates = updateArguments.every(Boolean);

if (!shouldGenerateUpdates && updateArguments.some(Boolean)) {
  throw new Error('Firefox update URL, XPI URL, and updates file must be provided together');
}

function validateHttpUrl(value, label) {
  let parsed;

  try {
    parsed = new URL(value);
  }
  catch {
    throw new Error(`${label} must be an absolute HTTP(S) URL: ${value}`);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error(`${label} must use HTTP or HTTPS: ${value}`);
  }

  if (parsed.username || parsed.password || parsed.hash) {
    throw new Error(`${label} cannot contain credentials or a fragment: ${value}`);
  }

  return parsed.href;
}

const sourcePath = resolve(sourceDirectory);
const manifestPath = resolve(sourcePath, 'manifest.json');
const updateUrl = shouldGenerateUpdates
  ? validateHttpUrl(updateUrlValue, 'Firefox update URL')
  : undefined;
const xpiUrl = shouldGenerateUpdates
  ? validateHttpUrl(xpiUrlValue, 'Firefox XPI URL')
  : undefined;
const manifest = JSON.parse(String(readFileSync(manifestPath, 'utf8')));
const gecko = manifest.browser_specific_settings?.gecko;

if (!gecko || typeof gecko.id !== 'string' || !gecko.id) {
  throw new Error('Firefox manifest is missing browser_specific_settings.gecko.id');
}

if (typeof manifest.version !== 'string' || !/^\d+(?:\.\d+){0,3}$/.test(manifest.version)) {
  throw new Error(`Invalid Firefox extension version: ${String(manifest.version)}`);
}

if (shouldGenerateUpdates) {
  gecko.update_url = updateUrl;
}
else {
  delete gecko.update_url;
}
writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o644 });

if (shouldGenerateUpdates) {
  const updates = {
    addons: {
      [gecko.id]: {
        updates: [
          {
            version: manifest.version,
            update_link: xpiUrl,
            ...(gecko.strict_min_version
              ? { applications: { gecko: { strict_min_version: gecko.strict_min_version } } }
              : {})
          }
        ]
      }
    }
  };

  writeFileSync(resolve(updatesFile), `${JSON.stringify(updates, null, 2)}\n`, { mode: 0o644 });
}
process.stdout.write(gecko.id);
