import { setTimeout as setNodeTimeout } from 'node:timers';

const args = {};
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i].replace(/^--/, '');
  args[key] = process.argv[i + 1];
}
const port = args.port || '9333';
const path = args.path;
const oldId = args['old-id'] || '';
const startUrl = args.url || '';

if (!path) {
  console.error('cdp-load-extension: missing --path');
  process.exit(2);
}

const fail = (code, message) => { console.error('cdp-load-extension: ' + message); process.exit(code); };

const timer = setNodeTimeout(() => fail(5, 'timed out'), 15000);
timer.unref();

let wsUrl;
try {
  const res = await fetch(`http://127.0.0.1:${port}/json/version`);
  if (!res.ok) { fail(3, `CDP /json/version returned ${res.status}`); }
  const version = await res.json();
  wsUrl = version && typeof version === 'object' && 'webSocketDebuggerUrl' in version
    ? version.webSocketDebuggerUrl
    : undefined;
}
catch (error) {
  fail(3, 'CDP endpoint not reachable: ' + (error && error.message));
}
if (!wsUrl) { fail(3, 'no browser webSocketDebuggerUrl'); }

const ws = new WebSocket(wsUrl);
let nextId = 0;
const pending = new Map();
const send = (method, params = {}, sessionId) => new Promise((resolve, reject) => {
  const id = ++nextId;
  pending.set(id, { resolve, reject });
  const frame = { id, method, params };
  if (sessionId) { frame.sessionId = sessionId; }
  ws.send(JSON.stringify(frame));
});

const enableIncognito = async (extensionId) => {
  let target;
  try { target = await send('Target.createTarget', { url: 'chrome://extensions/' }); }
  catch { return; }
  const targetId = target && target.targetId;
  if (!targetId) { return; }
  try {
    const attached = await send('Target.attachToTarget', { targetId, flatten: true });
    const sessionId = attached && attached.sessionId;
    if (sessionId) {
      await send('Runtime.enable', {}, sessionId);
      for (let attempt = 0; attempt < 10; attempt += 1) {
        const res = await send('Runtime.evaluate', {
          awaitPromise: true, returnByValue: true,
          expression: `new Promise((resolve) => {
  if (!chrome.developerPrivate || !chrome.developerPrivate.updateExtensionConfiguration) { resolve('no-api'); return; }
  chrome.developerPrivate.updateExtensionConfiguration({ extensionId: ${JSON.stringify(extensionId)}, incognitoAccess: true }, () => resolve(chrome.runtime.lastError ? chrome.runtime.lastError.message : 'ok'));
})`
        }, sessionId);
        const value = res && res.result && res.result.value;
        if (value === 'ok') { break; }
        await new Promise((r) => setTimeout(r, 300));
      }
    }
  }
  catch { }
  finally {
    try { await send('Target.closeTarget', { targetId }); } catch { }
  }
};

const openStartUrl = async () => {
  if (!startUrl) { return; }
  const { targetInfos = [] } = await send('Target.getTargets');
  const existing = targetInfos.find((target) => target.type === 'page' && target.url.startsWith(startUrl));
  if (existing?.targetId) {
    await send('Target.activateTarget', { targetId: existing.targetId });
  }
  else {
    await send('Target.createTarget', { url: startUrl });
  }
};

ws.addEventListener('message', (event) => {
  let msg;
  try { msg = JSON.parse(event.data); }
  catch { return; }
  const waiter = msg.id && pending.get(msg.id);
  if (!waiter) { return; }
  pending.delete(msg.id);
  if (msg.error) { waiter.reject(new Error(msg.error.message || JSON.stringify(msg.error))); }
  else { waiter.resolve(msg.result); }
});

await new Promise((resolve, reject) => {
  ws.addEventListener('open', resolve);
  ws.addEventListener('error', () => reject(new Error('websocket error')));
});

if (oldId) {
  try { await send('Extensions.uninstall', { id: oldId }); }
  catch { }
}

let result;
try { result = await send('Extensions.loadUnpacked', { path }); }
catch (error) { fail(4, 'Extensions.loadUnpacked failed: ' + error.message); }

if (!result || !result.id) { ws.close(); fail(4, 'loadUnpacked returned no id'); }
try { await enableIncognito(result.id); } catch { }
try { await openStartUrl(); } catch { }
ws.close();
clearTimeout(timer);
process.stdout.write(result.id, () => process.exit(0));
