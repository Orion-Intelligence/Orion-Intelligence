#!/bin/bash
set -e
set -o pipefail

PROJECT_NAME="orion-social"
APP_DIR="client"

_dist_chars='abcdefghijklmnopqrstuvwxyz0123456789'
DIST_RAND=''
for _ in {1..10}; do
    DIST_RAND+="${_dist_chars:RANDOM % ${#_dist_chars}:1}"
done
DIST_DIR="build-$DIST_RAND"
SERVE_PORT="4300"
SERVE_PID_FILE=".serve.pid"
SERVE_LOG_FILE=".serve.log"
RUN_LOCK_FILE=".run.lock"
ENV_FILE=".env"
DEV_URL="http://localhost:4200"

if [ -f "$ENV_FILE" ]; then
    set -a
    . "./$ENV_FILE"
    set +a
fi

export ORION_URL="${ORION_URL:-https://127.0.0.1:8443}"
FIREFOX_DEV_PROFILE_DIR="${ORION_FIREFOX_DEV_PROFILE_DIR:-$HOME/snap/firefox/common/orion-social-dev-profile}"
FIREFOX_DEV_EXTENSION_DIR="${ORION_FIREFOX_DEV_EXTENSION_DIR:-$HOME/snap/firefox/common/orion-social-firefox-dev}"
FIREFOX_DEV_ARTIFACTS_DIR="${ORION_FIREFOX_DEV_ARTIFACTS_DIR:-$HOME/snap/firefox/common/orion-social-web-ext-artifacts}"
FIREFOX_DEV_PID_FILE="${ORION_FIREFOX_DEV_PID_FILE:-$HOME/snap/firefox/common/orion-social-firefox-dev.pid}"
FIREFOX_DEV_LOG_FILE="${ORION_FIREFOX_DEV_LOG_FILE:-$HOME/snap/firefox/common/orion-social-firefox-dev.log}"
CHROMIUM_DEV_EXTENSION_DIR="${ORION_CHROMIUM_DEV_EXTENSION_DIR:-$HOME/snap/chromium/common/orion-social-chromium-dev}"
CHROMIUM_DEV_SIGNING_KEY_FILE="${ORION_CHROMIUM_DEV_SIGNING_KEY_FILE:-$HOME/snap/chromium/common/orion-social-dev-signing-key.pem}"
CHROMIUM_HOSTED_SIGNING_KEY_FILE="${ORION_CHROMIUM_HOSTED_SIGNING_KEY_FILE:-$HOME/snap/chromium/common/orion-social-hosted-signing-key.pem}"
HOSTED_DIR="$(pwd)/hosted"
AMO_CHANNEL="${AMO_CHANNEL:-unlisted}"

exec 9>"$RUN_LOCK_FILE"
if ! flock -n 9; then
    echo "Error: another run.sh command is already running"
    exit 1
fi

ACTION="$1"
shift || true
[ "$ACTION" = "stop" ] && ACTION="-stop"

MODE=""
DEV_BROWSER="firefox"
DEV_BUILD_BROWSER="both"
PROD_BROWSER="both"
PROD_TARGET="store"

if [ "$ACTION" = "build" ]; then
    MODE="$1"
    shift || true

    if [ "$MODE" != "-p" ] && [ "$MODE" != "-d" ]; then
        echo "Error: build requires '-p' (production) or '-d' (development)"
        echo "Usage: $0 build [-p|-d] [-hosted] [-firefox] [-chrome]"
        exit 1
    fi

    want_firefox=0
    want_chrome=0
    while [ "$#" -gt 0 ]; do
        case "$1" in
            -firefox) want_firefox=1 ;;
            -chrome) want_chrome=1 ;;
            -hosted)
                if [ "$MODE" != "-p" ]; then
                    echo "Error: '-hosted' requires '-p' (production)"
                    echo "Usage: $0 build [-p|-d] [-hosted] [-firefox] [-chrome]"
                    exit 1
                fi
                PROD_TARGET="hosted"
                ;;
            *)
                echo "Error: build option must be '-hosted', '-firefox', or '-chrome'"
                echo "Usage: $0 build [-p|-d] [-hosted] [-firefox] [-chrome]"
                exit 1
                ;;
        esac
        shift
    done

    if [ "$want_firefox" = "1" ] && [ "$want_chrome" = "0" ]; then
        selected_browser="firefox"
    elif [ "$want_chrome" = "1" ] && [ "$want_firefox" = "0" ]; then
        selected_browser="chrome"
    else
        selected_browser="both"
    fi

    if [ "$MODE" = "-d" ]; then
        DEV_BUILD_BROWSER="$selected_browser"
        [ "$selected_browser" != "both" ] && DEV_BROWSER="$selected_browser"
    else
        PROD_BROWSER="$selected_browser"
    fi
elif [ "$ACTION" != "-c" ] && [ "$ACTION" != "-stop" ]; then
    echo "Error: first argument must be 'build', '-c', or '-stop'"
    echo "Usage: $0 [build [-p|-d] [-hosted] [-firefox] [-chrome]|-c|-stop]"
    exit 1
fi

stop_serve() {
    stopped_server=0

    if [ -f "$SERVE_PID_FILE" ]; then
        pid=$(cat "$SERVE_PID_FILE" 2>/dev/null || true)
        if [[ "$pid" =~ ^[1-9][0-9]*$ ]] && kill -0 "$pid" 2>/dev/null; then
            pgid=$(ps -o pgid= -p "$pid" 2>/dev/null | tr -d " ")
            if [ "$pgid" = "$pid" ]; then
                kill -- "-$pid" 2>/dev/null || true
            else
                kill "$pid" 2>/dev/null || true
            fi
            stopped_server=1
        fi
        rm -f "$SERVE_PID_FILE"
    fi

    if [ "$stopped_server" = "1" ]; then
        for _ in {1..50}; do
            pids=$(lsof -ti "tcp:$SERVE_PORT" -sTCP:LISTEN 2>/dev/null || true)
            [ -z "$pids" ] && break
            sleep 0.1
        done
    fi

    pids=$(lsof -ti "tcp:$SERVE_PORT" -sTCP:LISTEN 2>/dev/null || true)
    if [ -n "$pids" ]; then
        echo "Error: port $SERVE_PORT is used by a process not started by this launcher: $pids"
        return 1
    fi
}

stop_firefox_dev() {
    local pid command_line pgid

    [ -f "$FIREFOX_DEV_PID_FILE" ] || return 0
    pid=$(cat "$FIREFOX_DEV_PID_FILE" 2>/dev/null || true)

    if [[ "$pid" =~ ^[1-9][0-9]*$ ]] && kill -0 "$pid" 2>/dev/null; then
        command_line=$(ps -o args= -p "$pid" 2>/dev/null || true)
        if [[ "$command_line" == *"web-ext"* && "$command_line" == *"orion-social-firefox-dev"* ]]; then
            pgid=$(ps -o pgid= -p "$pid" 2>/dev/null | tr -d " ")
            if [ "$pgid" = "$pid" ]; then
                kill -- "-$pid" 2>/dev/null || true
            else
                kill "$pid" 2>/dev/null || true
            fi
            for _ in {1..50}; do
                kill -0 "$pid" 2>/dev/null || break
                sleep 0.1
            done
            echo "firefox: previous managed dev instance stopped"
        else
            echo "Warning: ignoring stale Firefox dev PID $pid (process does not belong to this launcher)"
        fi
    fi

    rm -f "$FIREFOX_DEV_PID_FILE"
}

build_app() {
    npm --prefix "$APP_DIR" install
    npm --prefix "$APP_DIR" run lint
    npm --prefix "$APP_DIR" run build
}

build_app_dev() {
    npm --prefix "$APP_DIR" install
    npm --prefix "$APP_DIR" run lint
    (cd "$APP_DIR" && npx ng build --configuration production)
    rm -f "$APP_DIR/build/prerendered-routes.json"
}

clean_dist() {
    rm -rf build build-* 2>/dev/null || true
}

reset_dist() {
    clean_dist
    rm -rf "$DIST_DIR"
    mkdir -p "$DIST_DIR"
}

prepare_dev_extension() {
    local browser target

    browser="$1"
    case "$browser" in
        firefox) target="$DIST_DIR/$PROJECT_NAME-firefox-dev" ;;
        chrome) target="$DIST_DIR/$PROJECT_NAME-chrome-dev" ;;
        *)
            echo "Error: unsupported development browser: $browser"
            return 1
            ;;
    esac

    rm -rf "$target"
    mkdir -p "$target"
    cp -r "$APP_DIR/build/." "$target/"
    cp "$APP_DIR/manifests/manifest.$browser.json" "$target/manifest.json"
    node "$APP_DIR/build-scripts/audit-package.mjs" "$target" dev
    echo "$browser development source ready for packaging: $target"
}

package_unsigned_firefox_dev() {
    local source_dir unsigned_xpi

    source_dir="$DIST_DIR/$PROJECT_NAME-firefox-dev"
    unsigned_xpi="$DIST_DIR/$PROJECT_NAME-firefox.xpi"

    if [ ! -d "$source_dir" ]; then
        echo "Error: Firefox development source is missing: $source_dir"
        return 1
    fi

    rm -f "$unsigned_xpi"
    (cd "$source_dir" && zip -9qrX "../$PROJECT_NAME-firefox.xpi" .)
    unzip -tq "$unsigned_xpi" >/dev/null
    echo "firefox unsigned development XPI ready: $unsigned_xpi"
}

stage_dev_runtime() {
    local browser source_dir target

    browser="$1"
    case "$browser" in
        firefox)
            source_dir="$DIST_DIR/$PROJECT_NAME-firefox-dev"
            target="$FIREFOX_DEV_EXTENSION_DIR"
            ;;
        chrome)
            source_dir="$DIST_DIR/$PROJECT_NAME-chrome-dev"
            target="$CHROMIUM_DEV_EXTENSION_DIR"
            ;;
        *)
            echo "Error: unsupported development browser: $browser"
            return 1
            ;;
    esac

    if [ ! -d "$source_dir" ]; then
        echo "Error: development runtime source is missing: $source_dir"
        return 1
    fi
    if [ -z "$target" ] || [ "$target" = "/" ] || [ "$target" = "$HOME" ] || [ "$target" = "." ]; then
        echo "Error: unsafe development runtime directory: $target"
        return 1
    fi

    rm -rf "$target"
    mkdir -p "$target"
    cp -r "$source_dir/." "$target/"
    echo "$browser launch runtime staged outside the project: $target"
}

cleanup_dev_dist() {
    rm -rf \
        "$DIST_DIR/$PROJECT_NAME-chrome-dev" \
        "$DIST_DIR/$PROJECT_NAME-firefox-dev"
    rm -f \
        "$DIST_DIR/$PROJECT_NAME-chrome-dev.crx" \
        "$DIST_DIR/.chromium-dev-pack.log"
}

prepare_production_extension() {
    local browser target

    browser="$1"
    target="$DIST_DIR/$PROJECT_NAME-$browser"
    rm -rf "$target"
    mkdir -p "$target"
    cp -r "$APP_DIR/build/." "$target/"
    cp "$APP_DIR/manifests/manifest.$browser.json" "$target/manifest.json"
    node "$APP_DIR/build-scripts/audit-package.mjs" "$target"
    echo "$browser production source ready for store packaging: $target"
}

find_chromium_binary() {
    command -v chromium 2>/dev/null \
        || command -v chromium-browser 2>/dev/null \
        || command -v google-chrome 2>/dev/null \
        || command -v google-chrome-stable 2>/dev/null \
        || true
}

ensure_chromium_signing_key() {
    local key_file key_label key_dir

    key_file="$1"
    key_label="${2:-chromium}"

    if [ -e "$key_file" ] && [ ! -f "$key_file" ]; then
        echo "Error: $key_label signing key is not a regular file: $key_file"
        return 1
    fi

    if [ ! -f "$key_file" ]; then
        if ! command -v openssl >/dev/null 2>&1; then
            echo "Error: openssl is required to create the $key_label signing key"
            return 1
        fi

        key_dir=$(dirname -- "$key_file")
        mkdir -p "$key_dir"
        if ! (umask 077 && openssl genrsa -out "$key_file" 2048 >/dev/null 2>&1); then
            echo "Error: failed to create $key_label signing key at $key_file"
            return 1
        fi
        echo "$key_label: created persistent signing key outside the project at $key_file"
        echo "$key_label: back up this key securely; losing it changes the extension ID"
    fi

    if ! openssl pkey -in "$key_file" -noout -check >/dev/null 2>&1; then
        echo "Error: invalid $key_label signing key: $key_file"
        return 1
    fi

    chmod 600 "$key_file" 2>/dev/null || true
}

package_chromium_dev() {
    local source_dir produced_crx final_crx chromium_bin pack_log extension_id magic

    source_dir="$DIST_DIR/$PROJECT_NAME-chrome-dev"
    produced_crx="$DIST_DIR/$PROJECT_NAME-chrome-dev.crx"
    final_crx="$DIST_DIR/$PROJECT_NAME-chromium.crx"
    pack_log="$DIST_DIR/.chromium-dev-pack.log"

    if [ ! -d "$source_dir" ]; then
        echo "Error: Chromium development source is missing: $source_dir"
        return 1
    fi

    chromium_bin=$(find_chromium_binary)
    if [ -z "$chromium_bin" ]; then
        echo "Error: Chromium or Chrome is required to create the development .crx"
        return 1
    fi

    ensure_chromium_signing_key "$CHROMIUM_DEV_SIGNING_KEY_FILE" "chromium development"
    rm -f "$produced_crx" "$final_crx" "$pack_log"
    extension_id=$(node "$APP_DIR/build-scripts/prepare-chromium-package.mjs" \
        "$source_dir" \
        "$CHROMIUM_DEV_SIGNING_KEY_FILE")
    node "$APP_DIR/build-scripts/audit-package.mjs" "$source_dir" dev

    if ! "$chromium_bin" \
        --pack-extension="$source_dir" \
        --pack-extension-key="$CHROMIUM_DEV_SIGNING_KEY_FILE" \
        >"$pack_log" 2>&1; then
        echo "Error: Chromium failed to create the development .crx"
        tail -20 "$pack_log" 2>/dev/null || true
        return 1
    fi

    if [ ! -s "$produced_crx" ]; then
        echo "Error: Chromium reported success but produced no development .crx at $produced_crx"
        tail -20 "$pack_log" 2>/dev/null || true
        return 1
    fi

    magic=$(dd if="$produced_crx" bs=1 count=4 2>/dev/null || true)
    if [ "$magic" != "Cr24" ]; then
        echo "Error: invalid Chromium development package header in $produced_crx"
        return 1
    fi

    mv "$produced_crx" "$final_crx"
    rm -f "$pack_log"
    echo "chromium development CRX ready: $final_crx"
    echo "chromium development extension ID: $extension_id"
}

cleanup_production_dist() {
    rm -rf \
        "$DIST_DIR/$PROJECT_NAME-chrome" \
        "$DIST_DIR/$PROJECT_NAME-firefox"
}

package_source_zip() {
    local out_file list
    out_file="$1"
    rm -f "$out_file"
    if git -C "$(pwd)" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        list="$DIST_DIR/.source-files.txt"
        git ls-files -c -o --exclude-standard > "$list"
        zip -9qX "$out_file" -@ < "$list"
        rm -f "$list"
    else
        zip -9qrX "$out_file" . \
            -x './node_modules/*' -x '*/node_modules/*' \
            -x './build/*' -x './build-*/*' \
            -x './production/*' -x './store-uploads/*' \
            -x './.git/*' -x './.env' -x '*.log'
    fi
    unzip -tq "$out_file" >/dev/null
    echo "source snapshot ready: $out_file"
}

package_store_zips() {
    local browser src out zip
    browser="${1:-both}"
    out="$(pwd)/production"
    if [ "$browser" = "both" ] || [ "$browser" = "chrome" ]; then
        src="$DIST_DIR/$PROJECT_NAME-chrome"
        zip="$out/chrome/$PROJECT_NAME-chrome-webstore.zip"
        if [ ! -d "$src" ]; then
            echo "Error: Chrome production package is missing: $src"
            return 1
        fi
        rm -rf "$out/chrome"
        mkdir -p "$out/chrome"
        ( cd "$src" && zip -9qrX "$zip" . )
        unzip -tq "$zip" >/dev/null
        echo "chrome Web Store upload: $zip"
    fi
    if [ "$browser" = "both" ] || [ "$browser" = "firefox" ]; then
        src="$DIST_DIR/$PROJECT_NAME-firefox"
        zip="$out/firefox/$PROJECT_NAME-firefox-amo.zip"
        if [ ! -d "$src" ]; then
            echo "Error: Firefox production package is missing: $src"
            return 1
        fi
        rm -rf "$out/firefox"
        mkdir -p "$out/firefox"
        ( cd "$src" && zip -9qrX "$zip" . )
        unzip -tq "$zip" >/dev/null
        echo "firefox AMO upload: $zip"
    fi
}

package_hosted_chrome() {
    local src out chromium_bin produced_crx final_crx pack_log extension_id magic

    src="$DIST_DIR/$PROJECT_NAME-chrome"
    out="$HOSTED_DIR/chrome"
    produced_crx="$DIST_DIR/$PROJECT_NAME-chrome.crx"
    final_crx="$out/$PROJECT_NAME-chrome.crx"
    pack_log="$DIST_DIR/.chromium-hosted-pack.log"

    if [ ! -d "$src" ]; then
        echo "Error: Chrome production package is missing: $src"
        return 1
    fi

    chromium_bin=$(find_chromium_binary)
    if [ -z "$chromium_bin" ]; then
        echo "Error: Chromium or Chrome is required to create the hosted .crx"
        return 1
    fi

    ensure_chromium_signing_key "$CHROMIUM_HOSTED_SIGNING_KEY_FILE" "chromium hosted"
    rm -rf "$out"
    mkdir -p "$out"
    rm -f "$produced_crx" "$pack_log"

    if [ -n "$ORION_HOSTED_CHROME_UPDATE_URL" ] && [ -n "$ORION_HOSTED_CHROME_CRX_URL" ]; then
        extension_id=$(node "$APP_DIR/build-scripts/prepare-chromium-package.mjs" \
            "$src" \
            "$CHROMIUM_HOSTED_SIGNING_KEY_FILE" \
            "$ORION_HOSTED_CHROME_UPDATE_URL" \
            "$ORION_HOSTED_CHROME_CRX_URL" \
            "$out/updates.xml")
    else
        extension_id=$(node "$APP_DIR/build-scripts/prepare-chromium-package.mjs" \
            "$src" \
            "$CHROMIUM_HOSTED_SIGNING_KEY_FILE")
        echo "chromium hosted: ORION_HOSTED_CHROME_UPDATE_URL/ORION_HOSTED_CHROME_CRX_URL unset, skipping updates.xml"
    fi
    node "$APP_DIR/build-scripts/audit-package.mjs" "$src"

    if ! "$chromium_bin" \
        --pack-extension="$src" \
        --pack-extension-key="$CHROMIUM_HOSTED_SIGNING_KEY_FILE" \
        >"$pack_log" 2>&1; then
        echo "Error: Chromium failed to create the hosted .crx"
        tail -20 "$pack_log" 2>/dev/null || true
        return 1
    fi

    if [ ! -s "$produced_crx" ]; then
        echo "Error: Chromium reported success but produced no hosted .crx at $produced_crx"
        tail -20 "$pack_log" 2>/dev/null || true
        return 1
    fi

    magic=$(dd if="$produced_crx" bs=1 count=4 2>/dev/null || true)
    if [ "$magic" != "Cr24" ]; then
        echo "Error: invalid Chromium package header in $produced_crx"
        return 1
    fi

    mv "$produced_crx" "$final_crx"
    chmod 644 "$final_crx"
    rm -f "$pack_log"
    echo "chromium hosted CRX ready: $final_crx"
    echo "chromium hosted extension ID: $extension_id"
    [ -f "$out/updates.xml" ] && echo "chromium hosted update manifest: $out/updates.xml"
    return 0
}

package_hosted_firefox() {
    local src out web_ext artifacts source_zip signed_xpi extension_id

    src="$DIST_DIR/$PROJECT_NAME-firefox"
    out="$HOSTED_DIR/firefox"
    web_ext="$APP_DIR/node_modules/.bin/web-ext"
    artifacts="$DIST_DIR/web-ext-artifacts"
    source_zip="$1"

    if [ ! -d "$src" ]; then
        echo "Error: Firefox production package is missing: $src"
        return 1
    fi
    if [ ! -x "$web_ext" ]; then
        echo "Error: web-ext not found at $web_ext (run npm --prefix $APP_DIR install)"
        return 1
    fi
    if [ -z "$AMO_JWT_ISSUER" ] || [ -z "$AMO_JWT_SECRET" ]; then
        echo "Error: AMO_JWT_ISSUER and AMO_JWT_SECRET must be set in $ENV_FILE"
        return 1
    fi
    if [ ! -f "$source_zip" ]; then
        echo "Error: source snapshot is missing: $source_zip"
        return 1
    fi

    rm -rf "$out" "$artifacts"
    mkdir -p "$out" "$artifacts"

    if [ -n "$ORION_HOSTED_FIREFOX_UPDATE_URL" ] && [ -n "$ORION_HOSTED_FIREFOX_XPI_URL" ]; then
        extension_id=$(node "$APP_DIR/build-scripts/prepare-firefox-hosted-package.mjs" \
            "$src" \
            "$ORION_HOSTED_FIREFOX_UPDATE_URL" \
            "$ORION_HOSTED_FIREFOX_XPI_URL" \
            "$out/updates.json")
    else
        extension_id=$(node "$APP_DIR/build-scripts/prepare-firefox-hosted-package.mjs" "$src")
        echo "firefox hosted: ORION_HOSTED_FIREFOX_UPDATE_URL/ORION_HOSTED_FIREFOX_XPI_URL unset, skipping updates.json"
    fi
    node "$APP_DIR/build-scripts/audit-package.mjs" "$src"

    echo "firefox hosted: submitting to AMO for $AMO_CHANNEL signing (this can take a few minutes)"
    if ! NO_UPDATE_NOTIFIER=1 "$web_ext" sign \
        --source-dir "$src" \
        --artifacts-dir "$artifacts" \
        --api-key "$AMO_JWT_ISSUER" \
        --api-secret "$AMO_JWT_SECRET" \
        --channel "$AMO_CHANNEL" \
        --upload-source-code "$source_zip" \
        --no-config-discovery \
        --no-input; then
        echo "Error: AMO signing failed"
        return 1
    fi

    signed_xpi=$(find "$artifacts" -maxdepth 1 -type f -name '*.xpi' -print -quit)
    if [ -z "$signed_xpi" ]; then
        echo "Error: AMO signing produced no XPI in $artifacts"
        return 1
    fi

    cp "$signed_xpi" "$out/$PROJECT_NAME-firefox.xpi"
    rm -rf "$artifacts"
    echo "firefox hosted signed XPI ready: $out/$PROJECT_NAME-firefox.xpi"
    echo "firefox hosted extension ID: $extension_id"
    [ -f "$out/updates.json" ] && echo "firefox hosted update manifest: $out/updates.json"
    return 0
}

launch_chrome_dev() {
    chrome_ext="$(cd "$CHROMIUM_DEV_EXTENSION_DIR" 2>/dev/null && pwd || true)"

    DEV_CDP_PORT=9314
    LAST_ID_FILE="$HOME/.orion-ext-dev-lastid"
    chrome_bin="$(command -v chromium 2>/dev/null || command -v chromium-browser 2>/dev/null || command -v google-chrome 2>/dev/null || command -v google-chrome-stable 2>/dev/null || true)"
    if [ -n "$chrome_bin" ] && printf '%s' "$chrome_bin" | grep -qi tor; then
        echo "chromium auto-install skipped (resolved to Tor: $chrome_bin)"
        chrome_bin=""
    fi
    if [ -n "$chrome_bin" ] && [ -n "$chrome_ext" ]; then
        old_id="$(cat "$LAST_ID_FILE" 2>/dev/null || true)"
        if ! curl -sf "http://127.0.0.1:$DEV_CDP_PORT/json/version" >/dev/null 2>&1; then
            pkill -f "/snap/chromium/" 2>/dev/null || true
            pkill -f "chromium-browser/chrome" 2>/dev/null || true
            pkill -x chrome 2>/dev/null || true
            sleep 1.2
            setsid "$chrome_bin" --no-first-run --no-default-browser-check \
                --remote-debugging-port="$DEV_CDP_PORT" --enable-unsafe-extension-debugging \
                --disable-features=DisableLoadExtensionCommandLineSwitch \
                "$DEV_URL" 9>&- >/dev/null 2>&1 < /dev/null &
            for _ in {1..40}; do
                curl -sf "http://127.0.0.1:$DEV_CDP_PORT/json/version" >/dev/null 2>&1 && break
                sleep 0.5
            done
            old_id=""
            echo "chromium: desktop browser (re)started with CDP debugging on :$DEV_CDP_PORT"
        fi
        if curl -sf "http://127.0.0.1:$DEV_CDP_PORT/json/version" >/dev/null 2>&1; then
            new_id="$(node "$APP_DIR/build-scripts/cdp-load-extension.mjs" --port "$DEV_CDP_PORT" --path "$chrome_ext" --old-id "$old_id" --url "$DEV_URL" 2>/dev/null || true)"
            if [ -n "$new_id" ]; then
                printf '%s' "$new_id" > "$LAST_ID_FILE"
                echo "chromium: extension hot-loaded via CDP -> $new_id (future builds need no restart)"
            else
                echo "chromium: CDP load failed (extension not installed)"
            fi
        else
            echo "chromium: CDP debug instance did not come up on :$DEV_CDP_PORT"
        fi
    else
        echo "chromium/chrome not found; skipping its auto-install"
    fi
}

launch_firefox_dev() {
    local firefox_ext firefox_bin web_ext launcher_pid installed

    firefox_ext="$(cd "$FIREFOX_DEV_EXTENSION_DIR" 2>/dev/null && pwd || true)"
    firefox_bin="$(command -v firefox 2>/dev/null || command -v firefox-esr 2>/dev/null || command -v firefox-developer-edition 2>/dev/null || true)"
    web_ext="$APP_DIR/node_modules/.bin/web-ext"

    if [ -z "$firefox_bin" ]; then
        echo "Error: Firefox not found; cannot install the development extension"
        return 1
    fi
    if [ -z "$firefox_ext" ]; then
        echo "Error: Firefox development extension directory not found"
        return 1
    fi
    if [ ! -x "$web_ext" ]; then
        echo "Error: web-ext not found at $web_ext (run npm --prefix $APP_DIR install)"
        return 1
    fi

    rm -f "$FIREFOX_DEV_LOG_FILE"
    mkdir -p "$FIREFOX_DEV_PROFILE_DIR"
    NO_UPDATE_NOTIFIER=1 setsid "$web_ext" run \
        --source-dir "$firefox_ext" \
        --artifacts-dir "$FIREFOX_DEV_ARTIFACTS_DIR" \
        --target firefox-desktop \
        --firefox "$firefox_bin" \
        --firefox-profile "$FIREFOX_DEV_PROFILE_DIR" \
        --profile-create-if-missing \
        --keep-profile-changes \
        --start-url "$DEV_URL" \
        --no-config-discovery \
        --no-input \
        --no-reload \
        9>&- >"$FIREFOX_DEV_LOG_FILE" 2>&1 < /dev/null &
    launcher_pid=$!
    printf '%s' "$launcher_pid" > "$FIREFOX_DEV_PID_FILE"

    installed=0
    for _ in {1..60}; do
        if grep -Fq "Installed $firefox_ext as a temporary add-on" "$FIREFOX_DEV_LOG_FILE" 2>/dev/null; then
            installed=1
            break
        fi
        if ! kill -0 "$launcher_pid" 2>/dev/null; then
            break
        fi
        sleep 0.5
    done

    if [ "$installed" = "1" ]; then
        echo "firefox: development extension installed temporarily and $DEV_URL opened"
        return 0
    fi

    echo "Error: Firefox started without confirming the temporary extension install"
    tail -20 "$FIREFOX_DEV_LOG_FILE" 2>/dev/null || true
    stop_firefox_dev
    return 1
}

launch_dev() {
    if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
        echo "no display detected; skipping $DEV_BROWSER auto-install (load builds manually)"
        return 0
    fi

    case "$DEV_BROWSER" in
        firefox) launch_firefox_dev ;;
        chrome) launch_chrome_dev ;;
    esac
}

if [ "$ACTION" = "-c" ] || [ "$ACTION" = "-stop" ]; then
    if ! stop_serve; then
        exit 1
    fi
fi

if [ "$ACTION" = "-stop" ]; then
    stop_firefox_dev
fi

if [ "$ACTION" = "build" ]; then
    stop_firefox_dev
    trap 'rm -rf "$APP_DIR/build" 2>/dev/null; [ "$MODE" = "-p" ] && rm -rf "$DIST_DIR" 2>/dev/null; true' EXIT
fi

if [ "$ACTION" = "-stop" ]; then
    echo "extension service stopped"
elif [ "$ACTION" = "build" ] && [ "$MODE" = "-p" ] && [ "$PROD_TARGET" = "hosted" ]; then
    build_app
    reset_dist
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        prepare_production_extension "chrome"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        prepare_production_extension "firefox"
    fi
    HOSTED_SOURCE_ZIP="$DIST_DIR/$PROJECT_NAME-source.zip"
    package_source_zip "$HOSTED_SOURCE_ZIP"
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        package_hosted_chrome
        cp "$HOSTED_SOURCE_ZIP" "$HOSTED_DIR/chrome/$PROJECT_NAME-chrome-source.zip"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        package_hosted_firefox "$HOSTED_SOURCE_ZIP"
        cp "$HOSTED_SOURCE_ZIP" "$HOSTED_DIR/firefox/$PROJECT_NAME-firefox-source.zip"
    fi
    cleanup_production_dist
    echo "self-hosted package(s) for $PROD_BROWSER ($ORION_URL) written to $HOSTED_DIR"
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        echo "  chrome:  serve chrome/$PROJECT_NAME-chrome.crx (+ chrome/updates.xml when ORION_HOSTED_CHROME_UPDATE_URL is set)"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        echo "  firefox: serve firefox/$PROJECT_NAME-firefox.xpi (+ firefox/updates.json when ORION_HOSTED_FIREFOX_UPDATE_URL is set)"
    fi
elif [ "$ACTION" = "build" ] && [ "$MODE" = "-p" ]; then
    build_app
    reset_dist
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        prepare_production_extension "chrome"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        prepare_production_extension "firefox"
    fi
    package_store_zips "$PROD_BROWSER"
    SOURCE_ZIP="$DIST_DIR/$PROJECT_NAME-source.zip"
    package_source_zip "$SOURCE_ZIP"
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        cp "$SOURCE_ZIP" "production/chrome/$PROJECT_NAME-chrome-source.zip"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        cp "$SOURCE_ZIP" "production/firefox/$PROJECT_NAME-firefox-source.zip"
    fi
    cleanup_production_dist
    echo "store upload package(s) for $PROD_BROWSER ($ORION_URL) written to $(pwd)/production"
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "chrome" ]; then
        echo "  chrome:  upload chrome/$PROJECT_NAME-chrome-webstore.zip (+ chrome/$PROJECT_NAME-chrome-source.zip) at https://chrome.google.com/webstore/devconsole"
    fi
    if [ "$PROD_BROWSER" = "both" ] || [ "$PROD_BROWSER" = "firefox" ]; then
        echo "  firefox: upload firefox/$PROJECT_NAME-firefox-amo.zip (+ firefox/$PROJECT_NAME-firefox-source.zip) at https://addons.mozilla.org/developers/addon/submit/distribution"
    fi
elif [ "$ACTION" = "build" ] && [ "$MODE" = "-d" ]; then
    build_app_dev
    reset_dist
    if [ "$DEV_BUILD_BROWSER" = "both" ] || [ "$DEV_BUILD_BROWSER" = "chrome" ]; then
        prepare_dev_extension "chrome"
        package_chromium_dev
    fi
    if [ "$DEV_BUILD_BROWSER" = "both" ] || [ "$DEV_BUILD_BROWSER" = "firefox" ]; then
        prepare_dev_extension "firefox"
        package_unsigned_firefox_dev
    fi
    stage_dev_runtime "$DEV_BROWSER"
    cleanup_dev_dist
    for _br in chrome firefox; do
        if [ "$DEV_BUILD_BROWSER" = "both" ] || [ "$DEV_BUILD_BROWSER" = "$_br" ]; then
            rm -rf "$DIST_DIR/$_br"
            mkdir -p "$DIST_DIR/$_br"
            cp -r "$APP_DIR/build/." "$DIST_DIR/$_br/"
            cp "$APP_DIR/manifests/manifest.$_br.json" "$DIST_DIR/$_br/manifest.json"
        fi
    done
    rm -f "$DIST_DIR/$PROJECT_NAME-chromium.crx" "$DIST_DIR/$PROJECT_NAME-firefox.xpi"
    echo "development load-unpacked extensions written to $DIST_DIR (chrome/ and firefox/)"
    launch_dev
elif [ "$ACTION" = "-c" ]; then
    build_app
    setsid npm --prefix "$APP_DIR" run start 9>&- >"$SERVE_LOG_FILE" 2>&1 < /dev/null &
    echo $! > "$SERVE_PID_FILE"
    echo "extension service started on port $SERVE_PORT"
fi
