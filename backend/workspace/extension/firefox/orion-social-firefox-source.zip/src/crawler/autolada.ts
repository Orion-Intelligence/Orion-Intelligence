import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { forumProfile } from './resource/forum/forum';

export class C_autolada implements Crawler {
  readonly platform = 'autolada';
  readonly base = 'https://autolada.ru';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    return forumProfile('https://autolada.ru/profile.php?mode=viewprofile&u=', '', this.platform, payload);
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
