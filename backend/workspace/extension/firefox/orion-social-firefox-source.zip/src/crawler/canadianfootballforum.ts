import { CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { openSession } from './tab_management/tab.controller';

export class C_canadianfootballforum implements Crawler {
  readonly platform = 'canadianfootballforum';
  readonly base = 'https://canadianfootball.forum';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    if (type === 'posts') {
      return this.fetch_social_resource(type, payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '').trim().replace(/^@/, '');
    if (!username) {
      return [];
    }
    const tab = await openSession(this.base + '/');
    if (!tab) {
      return [];
    }
    try {
      const res = await tab.fetch(this.base + '/u/' + encodeURIComponent(username) + '.json', { headers: { Accept: 'application/json' } });
      if (!res.ok || !res.body) {
        return [];
      }
      let data: { user?: Record<string, unknown> };
      try { data = JSON.parse(res.body); } catch { return []; }
      const u = data?.user;
      const uname = u ? u['username'] : undefined;
      if (!u || typeof uname !== 'string') {
        return [];
      }
      let totalPosts = '';
      let totalLikes = '';
      try {
        const s = await tab.fetch(this.base + '/u/' + encodeURIComponent(username) + '/summary.json', { headers: { Accept: 'application/json' } });
        if (s.ok && s.body) {
          const sj = JSON.parse(s.body) as { user_summary?: Record<string, unknown> };
          const us = sj?.user_summary ?? {};
          totalPosts = us['post_count'] != null ? String(us['post_count']) : '';
          totalLikes = us['likes_received'] != null ? String(us['likes_received']) : '';
        }
      } catch { /* summary optional */ }
      const at = typeof u['avatar_template'] === 'string' ? u['avatar_template'] as string : '';
      const avatar = at ? (at.startsWith('http') ? at : this.base + at).replace('{size}', '120') : '';
      const bio = String(u['bio_raw'] ?? '').replace(/\s+/g, ' ').trim();
      return [{
        real_name: String(u['name'] || uname),
        bio,
        description: bio,
        location: String(u['location'] ?? ''),
        profile_url: this.base + '/u/' + uname,
        total_posts: totalPosts,
        total_followers: '',
        total_likes: totalLikes,
        avatar,
        banner: '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: uname,
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[]> {
    if (type !== 'posts') {
      return [];
    }
    const username = String(payload.username ?? '').trim().replace(/^@/, '');
    if (!username) {
      return [];
    }
    const tab = await openSession(this.base + '/');
    if (!tab) {
      return [];
    }
    try {
      const res = await tab.fetch(this.base + '/user_actions.json?username=' + encodeURIComponent(username) + '&filter=4,5&offset=0', { headers: { Accept: 'application/json' } });
      if (!res.ok || !res.body) {
        return [];
      }
      let data: { user_actions?: Record<string, unknown>[] };
      try { data = JSON.parse(res.body); } catch { return []; }
      const acts = Array.isArray(data?.user_actions) ? data.user_actions : [];
      const out: social_resource[] = [];
      for (const a of acts.slice(0, 25)) {
        const slug = String(a['slug'] ?? '');
        const tid = a['topic_id'] != null ? String(a['topic_id']) : '';
        const pn = a['post_number'] != null ? String(a['post_number']) : '';
        const url = slug && tid ? this.base + '/t/' + slug + '/' + tid + (pn ? '/' + pn : '') : this.base;
        out.push({
          type: 'posts',
          resource_id: String(a['post_id'] ?? tid ?? ''),
          url,
          parent_url: this.base + '/u/' + username,
          title: String(a['title'] ?? ''),
          caption: String(a['excerpt'] ?? '').replace(/<[^>]+>/g, ' ').replace(/&hellip;/g, ' ').replace(/\s+/g, ' ').trim(),
          author: username,
          datetime: String(a['created_at'] ?? ''),
          media_type: '',
          media_url: '',
          thumbnail_url: '',
          likes: '',
          shares: '',
          views: '',
        });
      }
      return out;
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
