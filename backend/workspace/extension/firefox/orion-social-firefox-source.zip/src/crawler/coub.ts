import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { videos } from './resource/coub/coub';

export class Coub implements Crawler {
  readonly platform = 'coub';
  readonly base = 'https://coub.com';
  readonly loginUrl = 'https://coub.com/login';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'videos'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'videos':
        return videos(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://coub.com/api/v2/channels/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const data: any = await response.json();
      if (!data?.permalink) {
        return [];
      }

      return [{
        real_name: data.title ?? data.permalink,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: '',
        profile_url: `https://coub.com/${data.permalink ?? username}`,
        total_posts: String((data.simple_coubs_count ?? 0) || ''),
        total_followers: String((data.followers_count ?? 0) || ''),
        total_likes: String((data.likes_count ?? 0) || ''),
        avatar: data.avatar_versions?.template ?? '',
        banner: data.background_image ?? '',
        crawl_type: ['details', 'videos'],
        platform: this.platform,
        username: data.permalink ?? username,
        id: data.id ?? 0,
        user_id: data.user_id ?? 0,
        total_following: String((data.following_count ?? 0) || ''),
        views_count: data.views_count ?? 0,
        recoubs_count: data.recoubs_count ?? 0,
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://coub.com/api/v2/users/me', { headers: { Accept: 'application/json' }, credentials: 'include' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
