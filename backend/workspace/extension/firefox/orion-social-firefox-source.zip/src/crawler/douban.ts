import { CrawlPage, CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';

export class Douban implements Crawler {
  readonly platform = 'douban';
  readonly base = 'https://www.douban.com';
  readonly loginUrl = 'https://accounts.douban.com/passport/login';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return { items: [] };
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const id = String(payload.username ?? '');
    if (!id) {
      return [];
    }

    try {
      const response = await fetch(`https://www.douban.com/people/${encodeURIComponent(id)}/`, { credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const strip = (value: string): string => value.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#0?39;/g, "'").replace(/\s+/g, ' ').trim();
      const infoMatch = /people_info\s*=\s*(\{[\s\S]*?\})/.exec(html);
      let info: any = {};
      try {
        info = infoMatch ? JSON.parse(infoMatch[1]) : {};
      }
      catch {
        info = {};
      }

      const titleMatch = /<title>([\s\S]*?)<\/title>/i.exec(html);
      const name = info.name ?? (titleMatch ? strip(titleMatch[1]) : '');
      if (!name) {
        return [];
      }

      const numericId = info.id ?? (/up(\d+)-/.exec(html)?.[1] ?? id);
      const introMatch = /id="intro_display"[^>]*>([\s\S]*?)<\/(?:span|div)>/i.exec(html);
      const signatureMatch = /class="signature_display"[^>]*>([\s\S]*?)<\/span>/i.exec(html) ?? /id="display"[^>]*>([\s\S]*?)<\/span>/i.exec(html);
      const locationMatch = /常居[:：][\s\S]{0,80}?<a[^>]*>([\s\S]*?)<\/a>/i.exec(html);

      return [{
        real_name: name,
        bio: introMatch ? strip(introMatch[1]) : '',
        description: introMatch ? strip(introMatch[1]) : '',
        location: locationMatch ? strip(locationMatch[1]) : '',
        profile_url: `https://www.douban.com/people/${id}/`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: `https://img9.doubanio.com/icon/up${numericId}-66.jpg`,
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username: id,
        id: numericId,
        signature: signatureMatch ? strip(signatureMatch[1]) : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.douban.com/mine/', { credentials: 'include', redirect: 'follow' });
      return response.ok && !/passport\/login|accounts\.douban/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
