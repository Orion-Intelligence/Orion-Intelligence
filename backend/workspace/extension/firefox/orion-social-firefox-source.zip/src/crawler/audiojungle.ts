import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { ogDetails } from './resource/og/og';

export class C_audiojungle implements Crawler {
  readonly platform = 'audiojungle';
  readonly base = 'https://audiojungle.net';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') { return this.details(payload); }
    return [];
  }
  async details(payload: CrawlPayload): Promise<social_profile_details[]> { return ogDetails('https://audiojungle.net/user/', '', this.platform, payload); }
  async verifyLogin(): Promise<boolean> { return false; }
}
