import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, projects } from './resource/codewars/codewars';

export class Codewars implements Crawler {
  readonly platform = 'codewars';
  readonly base = 'https://www.codewars.com';
  readonly loginUrl = 'https://www.codewars.com/users/sign_in';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'projects', 'answers'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'answers':
        return answers(payload);
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.codewars.com/api/v1/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.username) {
        return [];
      }

      return [{
        real_name: data.name ?? data.username ?? username,
        bio: data.clan ?? '',
        description: data.clan ?? '',
        location: '',
        profile_url: `https://www.codewars.com/users/${data.username ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: String((data.honor ?? 0) || ''),
        avatar: '',
        banner: '',
        crawl_type: ['details', 'answers', 'projects'],
        platform: this.platform,
        username: data.username ?? username,
        id: data.id ?? '',
        clan: data.clan ?? '',
        honor: data.honor ?? 0,
        leaderboard_position: data.leaderboardPosition ?? 0,
        overall_rank: data.ranks?.overall?.name ?? '',
        overall_score: data.ranks?.overall?.score ?? 0,
        overall_color: data.ranks?.overall?.color ?? '',
        completed_challenges: data.codeChallenges?.totalCompleted ?? 0,
        authored_challenges: data.codeChallenges?.totalAuthored ?? 0,
        languages: Object.keys(data.ranks?.languages ?? {}).join(', '),
        skills: Array.isArray(data.skills) ? data.skills.join(', ') : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.codewars.com/users/edit', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/users\/sign_in/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
