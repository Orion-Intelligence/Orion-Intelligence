import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { projects } from './resource/dribbble/dribbble';

export class Dribbble implements Crawler {
  readonly platform = 'dribbble';
  readonly base = 'https://dribbble.com';
  readonly loginUrl = 'https://dribbble.com/session/new';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'projects'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'projects':
        return projects(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://dribbble.com/${encodeURIComponent(username)}`, { redirect: 'follow' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const decode = (value: string): string => value.replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
      const meta = (key: string): string => decode(new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html)?.[1] ?? new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${key}["']`, 'i').exec(html)?.[1] ?? '');
      const title = decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '');
      const embedded = (key: string): string => {
        const found = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`).exec(html);
        if (!found) {
          return '';
        }
        try {
          return String(JSON.parse(`"${found[1]}"`)).replace(/\s+/g, ' ').trim();
        }
        catch {
          return found[1];
        }
      };

      const displayName = title.replace(/\s*\|\s*Dribbble$/i, '').trim();
      if (!displayName) {
        return [];
      }

      const stat = (label: string): number => {
        const found = new RegExp(`([\\d,]+)\\s*(?:<[^>]+>\\s*)*${label}`, 'i').exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };
      const count = (label: string): number => {
        const found = new RegExp(`([\\d,]+)\\s*${label}`, 'i').exec(html);
        return found ? Number(found[1].replace(/,/g, '')) || 0 : 0;
      };
      const followers = count('Followers') || stat('followers');

      return [{
        real_name: displayName,
        bio: meta('og:description') || meta('description'),
        description: meta('og:description') || meta('description'),
        location: embedded('location'),
        profile_url: `https://dribbble.com/${username}`,
        total_posts: String((count('Shots') || stat('shots')) || ''),
        total_followers: String(followers || ''),
        total_likes: String((stat('likes')) || ''),
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details', 'projects'],
        platform: this.platform,
        username: username,
        followers_count: followers,
        shots_count: count('Shots') || stat('shots'),
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://dribbble.com/account/settings', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/session\/new|\/signin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
