import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { ucozDetails } from './resource/ucoz/ucoz';

export class C_cssnn52rusucozru implements Crawler {
  readonly platform = 'cssnn52rusucozru';
  readonly base = 'https://css-nn-52-rus.ucoz.ru';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    return ucozDetails(this.base, this.platform, payload);
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
