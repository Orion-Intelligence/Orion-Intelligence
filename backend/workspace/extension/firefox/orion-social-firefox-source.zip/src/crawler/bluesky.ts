import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { connections, followers, friends, organizations, posts, projects } from './resource/bluesky/bluesky';

export class Bluesky implements Crawler {
  readonly platform = 'bluesky';
  readonly base = 'https://bsky.app';
  readonly loginUrl = 'https://bsky.app/';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts', 'followers', 'friends', 'projects', 'organizations', 'connections'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    if (type === 'connections') {
      return connections(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'friends':
        return friends(payload);
      case 'projects':
        return projects(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      if (!data?.did) {
        return [];
      }

      return [{
        real_name: data.displayName ?? data.handle ?? username,
        bio: data.description ?? '',
        description: data.description ?? '',
        location: '',
        profile_url: `https://bsky.app/profile/${data.handle ?? username}`,
        total_posts: String((data.postsCount ?? 0) || ''),
        total_followers: String((data.followersCount ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar ?? '',
        banner: data.banner ?? '',
        crawl_type: ['details', 'posts', 'followers', 'friends', 'projects', 'organizations', 'connections'],
        platform: this.platform,
        username: data.handle ?? username,
        handle: data.handle ?? '',
        did: data.did ?? '',
        posts_count: data.postsCount ?? 0,
        followers_count: data.followersCount ?? 0,
        follows_count: data.followsCount ?? 0,
        verified_status: data.verification?.verifiedStatus ?? '',
        trusted_verifier_status: data.verification?.trustedVerifierStatus ?? '',
        verifications_count: Array.isArray(data.verification?.verifications) ? data.verification.verifications.length : 0,
        labels: (Array.isArray(data.labels) ? data.labels : []).map((l: any) => l.val ?? '').filter(Boolean).join(', '),
        pinned_post: data.pinnedPost?.uri ?? '',
        has_chat: Boolean(data.associated?.chat),
        has_labeler: data.associated?.labeler ?? false,
        lists_count: data.associated?.lists ?? 0,
        feedgens_count: data.associated?.feedgens ?? 0,
        starter_packs_count: data.associated?.starterPacks ?? 0,
        indexed_at: data.indexedAt ?? '',
        created_at: data.createdAt ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const stored = globalThis.localStorage?.getItem('BSKY_STORAGE') ?? '';
      return /"currentAccount"\s*:\s*\{[^}]*"did"\s*:\s*"did:/.test(stored);
    }
    catch {
      return false;
    }
  }
}
