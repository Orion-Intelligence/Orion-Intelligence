import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { games, organizations } from './resource/chesscom/chesscom';

export class ChessCom implements Crawler {
  readonly platform = 'chesscom';
  readonly base = 'https://www.chess.com';
  readonly loginUrl = 'https://www.chess.com/login';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'games', 'organizations'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'games':
        return games(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://api.chess.com/pub/player/${encodeURIComponent(username.toLowerCase())}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = payload;
      if (!data?.username) {
        return [];
      }

      return [{
        real_name: data.name ?? data.username,
        bio: data.status ?? '',
        description: data.status ?? '',
        location: data.location ?? '',
        profile_url: data.url ?? `https://www.chess.com/member/${username}`,
        total_posts: '',
        total_followers: String((data.followers ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar ?? '',
        banner: '',
        crawl_type: ['details', 'games', 'organizations'],
        platform: this.platform,
        username: data.username,
        player_id: data.player_id ?? 0,
        title: data.title ?? '',
        country: data.country ? String(data.country).split('/').pop() : '',
        league: data.league ?? '',
        followers: data.followers ?? 0,
        status: data.status ?? '',
        verified: data.verified ?? false,
        is_streamer: data.is_streamer ?? false,
        twitch_url: data.twitch_url ?? '',
        streaming_platforms: (Array.isArray(data.streaming_platforms) ? data.streaming_platforms : []).map((s: any) => s.type ?? s).filter(Boolean).join(', '),
        last_online: data.last_online ? new Date(data.last_online * 1000).toISOString() : '',
        created_at: data.joined ? new Date(data.joined * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.chess.com/callback/user/current', { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      return Boolean(data?.user?.id || data?.id || data?.username);
    }
    catch {
      return false;
    }
  }
}
