import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { openSession } from './tab_management/tab.controller';

export class Coderwall implements Crawler {
  readonly platform = 'coderwall';
  readonly base = 'https://coderwall.com';
  readonly loginUrl = 'https://coderwall.com/login';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }

    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '').trim().replace(/^@/, '');
    if (!username) {
      return [];
    }

    const tab = await openSession(this.base + '/');
    if (!tab) {
      return [];
    }

    try {
      const response = await tab.fetch(`https://coderwall.com/${encodeURIComponent(username)}.json`, { headers: { accept: 'application/json' } });
      if (!response.ok) {
        return [];
      }

      const data = JSON.parse(response.body);
      if (!data || !data.username) {
        return [];
      }

      const badges: any[] = Array.isArray(data.badges) ? data.badges : [];
      return [{
        real_name: data.name || data.username,
        bio: String(data.about ?? '').trim(),
        description: String(data.about ?? '').trim(),
        location: data.location ?? '',
        profile_url: `https://coderwall.com/${data.username}`,
        total_posts: '',
        total_followers: '',
        total_likes: String((data.karma ?? 0) || ''),
        avatar: '',
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username: data.username,
        id: data.id ?? 0,
        title: data.title ?? '',
        company: data.company ?? '',
        endorsements: data.endorsements ?? 0,
        github: data.accounts?.github ?? '',
        twitter: data.accounts?.twitter ?? '',
        specialties: Array.isArray(data.specialties) ? data.specialties : [],
        badges: badges.map((badge) => badge?.name ?? '').filter(Boolean),
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://coderwall.com/settings', { credentials: 'include', redirect: 'follow' });
      return response.ok && !/\/login|\/signin/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
