import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { ogDetails } from './resource/og/og';

export class C_biggerpockets implements Crawler {
  readonly platform = 'biggerpockets';
  readonly base = 'https://www.biggerpockets.com';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    return ogDetails('https://www.biggerpockets.com/users/', '', this.platform, payload);
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
