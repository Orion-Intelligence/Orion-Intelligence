import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { openSession } from './tab_management/tab.controller';

export class Arena implements Crawler {
  readonly platform = 'arena';
  readonly base = 'https://www.are.na';
  readonly loginUrl = 'https://www.are.na/sign-in';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }

    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '').trim().replace(/^@/, '');
    if (!username) {
      return [];
    }

    const tab = await openSession(this.base + '/');
    if (!tab) {
      return [];
    }

    try {
      const response = await tab.fetch(`https://api.are.na/v2/users/${encodeURIComponent(username)}`);
      if (!response.ok) {
        return [];
      }

      const data = JSON.parse(response.body);
      if (!data || (!data.slug && !data.username)) {
        return [];
      }

      const slug = data.slug ?? username;
      return [{
        real_name: data.full_name || data.username || slug,
        bio: data.metadata?.description ?? '',
        description: data.metadata?.description ?? '',
        location: '',
        profile_url: `https://www.are.na/${slug}`,
        total_posts: String((data.channel_count ?? 0) || ''),
        total_followers: String((data.follower_count ?? 0) || ''),
        total_likes: '',
        avatar: data.avatar_image?.display ?? data.avatar ?? '',
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username: slug,
        id: data.id ?? 0,
        following_count: data.following_count ?? 0,
        channel_count: data.channel_count ?? 0,
        badge: data.badge ?? '',
        is_premium: data.is_premium ?? false,
        created_at: data.created_at ?? '',
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.are.na/settings', { credentials: 'include', redirect: 'follow' });
      return response.ok && !/sign-in/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
