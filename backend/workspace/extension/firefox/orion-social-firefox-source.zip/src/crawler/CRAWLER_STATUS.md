# Crawler status (auto-classified 2026-09-11)

Stub platforms classified: 2621 | reachable: 1357 | verified-real conversions: 26

## Engine breakdown of the generated coverage entries

- dead: 1264
- unknown: 507
- ucoz: 409
- og: 276
- xenforo: 63
- wordpress: 55
- phpbb: 34
- vbulletin: 8
- ipb: 5

## Verified-real (converted, live-confirmed username->profile, shown green):

- forumsvisualparadigmcom  ->  https://forums.visual-paradigm.com/u/rain
- duno  ->  https://duno.com/user/Mommydommy
- forumlanguagelearningwithnetflixcom  ->  https://forum.languagelearningwithnetflix.com/u/david_wilkinson
- forumsoperacom  ->  https://forums.opera.com/user/kevinoperauser123
- airlinepilotlife  ->  https://airlinepilot.life/user/ATPFlightSchool
- trepupcom  ->  https://trepup.com/@trepup
- forumuipathcom  ->  https://forum.uipath.com/u/suhani_singh
- forumseeedstudiocom  ->  https://forum.seeedstudio.com/u/iman
- samlib  ->  https://samlib.com/user/samaritanhealth
- chiefdelphicom  ->  https://chiefdelphi.com/u/thatonerandomguy
- commonscommondreamsorg  ->  https://commons.commondreams.org/u/common-dreams
- webflowcom  ->  https://webflow.com/@webflow
- galactictalkorg  ->  https://galactictalk.org/u/bkolobara
- forumswyzecamcom  ->  https://forums.wyzecam.com/u/usercustomergwen
- forumstnationcom  ->  https://forums.t-nation.com/u/system
- discussflarumorg  ->  https://discuss.flarum.org/u/flarum
- planetminecraft  ->  https://planetminecraft.com/member/emanuel2011
- nhl  ->  https://nhl.com/@nhl
- communitysweatcoin  ->  https://community.sweatco.in/@sweatcoin
- xgmguru  ->  https://xgm.guru/user/N7%2BMolot
- flutterforumorg  ->  https://flutterforum.org/u/Bahadir
- cytoidio  ->  https://cytoid.io/profile/kagamine_39
- xing  ->  https://xing.com/profile/Veronika_Gersdorf
- lnkbio  ->  https://lnk.bio/@lnkbio
- tradingview  ->  https://tradingview.com/u/TradingView
- cyberharvardedu  ->  https://cyber.harvard.edu/people/fran-berman

## Honest skips (no public username->profile to fetch): dead / unknown / ucoz(login-walled) — remain as best-effort stubs, will show failing.
