import { CrawlPage, CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';

export class AboutMe implements Crawler {
  readonly platform = 'aboutme';
  readonly base = 'https://about.me';
  readonly loginUrl = 'https://about.me/signin';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return { items: [] };
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://about.me/${encodeURIComponent(username)}`, { credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const html = await response.text();
      const match = /<script[^>]*class="contextData"[^>]*>([\s\S]*?)<\/script>/i.exec(html);
      if (!match) {
        return [];
      }

      const ctx: any = JSON.parse(match[1]);
      const user: any = ctx?.page?.user;
      if (!user || ctx?.page?.id !== 'profile') {
        return [];
      }

      const unescapeOnce = (value: string): string => value.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&#x27;/g, "'");
      const bio = unescapeOnce(String(user.bio ?? '')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
      const real_name = [user.first_name, user.last_name].filter(Boolean).join(' ').trim() || user.user_name || username;
      const links = Array.isArray(user.apps) ? user.apps.filter((app: any) => app?.site_url).map((app: any) => ({ platform: app.platform ?? '', url: app.site_url })) : [];

      return [{
        real_name,
        bio,
        description: bio,
        location: user.locations?.[0]?.location ?? '',
        profile_url: `https://about.me/${user.user_name ?? username}`,
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: '',
        banner: user.images?.[0]?.url ?? '',
        crawl_type: ['details'],
        platform: this.platform,
        username: user.user_name ?? username,
        user_id: user.user_id ?? 0,
        job_title: Array.isArray(user.jobs) ? (user.jobs[0] ?? '') : '',
        external_links: links,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://about.me/account', { credentials: 'include', redirect: 'follow' });
      return response.ok && !/signin|login/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
