import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { followers, organizations, posts } from './resource/bandlab/bandlab';

export class BandLab implements Crawler {
  readonly platform = 'bandlab';
  readonly base = 'https://www.bandlab.com';
  readonly loginUrl = 'https://www.bandlab.com/signin';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts', 'followers', 'organizations'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'followers':
        return followers(payload);
      case 'organizations':
        return organizations(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://www.bandlab.com/api/v1.3/users/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const data: any = await response.json();
      if (!data?.username) {
        return [];
      }

      const banner = data.backgroundPicture?.isDefault ? '' : (data.backgroundPicture?.url ?? '');

      return [{
        real_name: data.name ?? data.username,
        bio: data.about ?? '',
        description: data.about ?? '',
        location: data.place?.name ?? '',
        profile_url: `https://www.bandlab.com/${data.username}`,
        total_posts: '',
        total_followers: String((data.counters?.followers ?? 0) || ''),
        total_likes: '',
        avatar: data.picture?.url ?? '',
        banner,
        crawl_type: ['details', 'posts', 'followers', 'organizations'],
        platform: this.platform,
        username: data.username,
        id: data.id ?? '',
        total_following: String((data.counters?.following ?? 0) || ''),
        bands_count: data.counters?.bands ?? 0,
        plays: data.counters?.plays ?? 0,
        verified: data.isVerified ?? false,
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://www.bandlab.com/api/v1.3/me', { headers: { Accept: 'application/json' }, credentials: 'include' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
