import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { discourseDetails, discoursePosts } from './resource/discourse/discourse';

export class C_communitymycroftai implements Crawler {
  readonly platform = 'communitymycroftai';
  readonly base = 'https://community.openconversational.ai';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    if (type === 'posts') {
      return discoursePosts(this.base, payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    return discourseDetails(this.base, this.platform, payload);
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
