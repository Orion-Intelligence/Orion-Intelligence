import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { answers, games, posts } from './resource/codeforces/codeforces';

export class Codeforces implements Crawler {
  readonly platform = 'codeforces';
  readonly base = 'https://codeforces.com';
  readonly loginUrl = 'https://codeforces.com/enter';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts', 'games', 'answers'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      case 'answers':
        return answers(payload);
      case 'games':
        return games(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://codeforces.com/api/user.info?handles=${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const payload: any = await response.json();
      const data: any = Array.isArray(payload?.result) ? payload.result[0] : null;
      if (!data?.handle) {
        return [];
      }

      return [{
        real_name: [data.firstName, data.lastName].filter(Boolean).join(' ') || data.handle,
        bio: data.rank ?? '',
        description: data.rank ?? '',
        location: [data.city, data.country].filter(Boolean).join(', '),
        profile_url: `https://codeforces.com/profile/${data.handle ?? username}`,
        total_posts: '',
        total_followers: String((data.friendOfCount ?? 0) || ''),
        total_likes: '',
        avatar: data.titlePhoto ?? data.avatar ?? '',
        banner: '',
        crawl_type: ['details', 'posts', 'answers', 'games'],
        platform: this.platform,
        username: data.handle ?? username,
        first_name: data.firstName ?? '',
        last_name: data.lastName ?? '',
        organization: data.organization ?? '',
        city: data.city ?? '',
        country: data.country ?? '',
        rank: data.rank ?? '',
        max_rank: data.maxRank ?? '',
        rating: data.rating ?? 0,
        max_rating: data.maxRating ?? 0,
        contribution: data.contribution ?? 0,
        friend_of_count: data.friendOfCount ?? 0,
        last_online: data.lastOnlineTimeSeconds ? new Date(data.lastOnlineTimeSeconds * 1000).toISOString() : '',
        created_at: data.registrationTimeSeconds ? new Date(data.registrationTimeSeconds * 1000).toISOString() : '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://codeforces.com/settings/general', { credentials: 'include', redirect: 'follow' });
      if (!response.ok) {
        return false;
      }

      return !/\/enter/i.test(response.url);
    }
    catch {
      return false;
    }
  }
}
