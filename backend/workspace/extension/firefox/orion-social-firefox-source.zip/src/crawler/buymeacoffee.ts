import { CrawlPage, CrawlPayload, CrawlType, social_profile_details, social_resource } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { posts } from './resource/buymeacoffee/buymeacoffee';

export class BuyMeACoffee implements Crawler {
  readonly platform = 'buymeacoffee';
  readonly base = 'https://buymeacoffee.com';
  readonly loginUrl = 'https://buymeacoffee.com/sign-in';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details', 'posts'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[] | CrawlPage> {
    if (type === 'details') {
      return this.details(payload);
    }

    return this.fetch_social_resource(type, payload);
  }

  async fetch_social_resource(type: CrawlType, payload: CrawlPayload): Promise<social_resource[] | CrawlPage> {
    switch (type) {
      case 'posts':
        return posts(payload);
      default:
        return { items: [] };
    }
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '');
    if (!username) {
      return [];
    }

    try {
      const response = await fetch(`https://app.buymeacoffee.com/api/creators/slug/${encodeURIComponent(username)}`, { headers: { Accept: 'application/json' }, credentials: 'include' });
      if (!response.ok) {
        return [];
      }

      const body: any = await response.json();
      const data: any = body?.data;
      if (!data?.project_slug) {
        return [];
      }

      const bio = String(data.project_description_small ?? data.profile?.profile_description ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

      return [{
        real_name: data.profile?.profile_full_name ?? data.project_slug,
        bio,
        description: bio,
        location: data.profile?.profile_country ?? '',
        profile_url: `https://buymeacoffee.com/${data.project_slug}`,
        total_posts: String((data.posts_count ?? 0) || ''),
        total_followers: String((data.public_supporters_count ?? data.followers_count ?? 0) || ''),
        total_likes: '',
        avatar: data.profile?.profile_picture_url ?? '',
        banner: data.project_cover_image ?? '',
        crawl_type: ['details', 'posts'],
        platform: this.platform,
        username: data.project_slug,
        twitter: data.project_twitter_handle ?? '',
        verified: data.profile?.profile_is_verified ?? false,
        work: data.profile?.profile_work ?? '',
      }];
    }
    catch {
      return [];
    }
  }

  async verifyLogin(): Promise<boolean> {
    try {
      const response = await fetch('https://app.buymeacoffee.com/api/creator', { headers: { Accept: 'application/json' }, credentials: 'include' });
      return response.ok;
    }
    catch {
      return false;
    }
  }
}
