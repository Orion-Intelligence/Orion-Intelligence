import { CrawlPayload, CrawlType, social_profile_details } from '../app/extension/model/extension.model';
import { Crawler } from './abstract/crawler';
import { NO_AUTH } from './constant/crawlers';
import { openSession } from './tab_management/tab.controller';

export class C_discussfastpitch implements Crawler {
  readonly platform = 'discussfastpitch';
  readonly base = 'https://www.discussfastpitch.com';
  readonly authwall = NO_AUTH;
  readonly crawlTypes: CrawlType[] = ['details'];

  async invoke(type: CrawlType, payload: CrawlPayload): Promise<unknown[]> {
    if (type === 'details') {
      return this.details(payload);
    }
    return [];
  }

  async details(payload: CrawlPayload): Promise<social_profile_details[]> {
    const username = String(payload.username ?? '').trim().replace(/^@/, '');
    if (!username) {
      return [];
    }
    const tab = await openSession(this.base + '/');
    if (!tab) {
      return [];
    }
    try {
      await tab.navigate('https://www.discussfastpitch.com/members/?username=' + encodeURIComponent(username) + '');
      await tab.settle();
      const html = await tab.html();
      const meta = (k: string): string => {
        const m = new RegExp('<meta[^>]+(?:property|name)="' + k + '"[^>]+content="([^"]*)"', 'i').exec(html) || new RegExp('<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="' + k + '"', 'i').exec(html);
        return m ? m[1].replace(/&amp;/g, '&').replace(/&#0?39;/g, "'").replace(/&quot;/g, '"').trim() : '';
      };
      const title = meta('og:title');
      if (!title) {
        return [];
      }
      return [{
        real_name: title,
        bio: meta('og:description'),
        description: meta('og:description'),
        location: '',
        profile_url: meta('og:url') || ('https://www.discussfastpitch.com/members/?username=' + encodeURIComponent(username) + ''),
        total_posts: '',
        total_followers: '',
        total_likes: '',
        avatar: meta('og:image'),
        banner: '',
        crawl_type: ['details'],
        platform: this.platform,
        username,
      }];
    }
    catch {
      return [];
    }
    finally {
      await tab.close();
    }
  }

  async verifyLogin(): Promise<boolean> {
    return false;
  }
}
