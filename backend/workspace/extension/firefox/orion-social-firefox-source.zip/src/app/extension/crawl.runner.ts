import { inject, Injectable } from '@angular/core';
import { ExtensionManager } from './extension.manager';
import { ExtensionRoute } from './extension.route';

interface RuntimeMessaging {
  runtime?: {
    onMessage?: { addListener(callback: (message: unknown, sender: unknown, sendResponse: (response: unknown) => void) => unknown): void };
  };
}

@Injectable({ providedIn: 'root' })
export class CrawlRunner {
  private readonly manager = inject(ExtensionManager);
  private readonly route = inject(ExtensionRoute);

  install(): void {
    const scope = globalThis as unknown as { chrome?: RuntimeMessaging; browser?: RuntimeMessaging };
    const runtime = (scope.browser ?? scope.chrome)?.runtime;
    if (!runtime?.onMessage?.addListener) {
      return;
    }

    runtime.onMessage.addListener((message, _sender, sendResponse) => {
      const command = message as { type?: string; command?: unknown; message?: string };
      if (command?.type === 'orion-task' && typeof command.message === 'string') {
        // The socket hands ExtensionRoute the raw task string and returns what it
        // gives back, so a task delivered here runs exactly as a dispatched one does.
        this.route.handle(command.message).then(
          (result) => sendResponse(result ?? { items: [], error: 'no result' }),
          (error: unknown) => sendResponse({ items: [], error: String((error as Error)?.message ?? error) }));
        return true;
      }
      if (command?.type !== 'orion-run') {
        return undefined;
      }

      this.#run(command.command).then((result) => sendResponse(result), (error: unknown) => sendResponse({ items: [], error: String((error as Error)?.message ?? error) }));
      return true;
    });
  }

  async #run(command: unknown): Promise<{ items: unknown[]; error?: string; ok?: boolean; per_type?: { type: string; count: number; error?: string }[] }> {
    const input = (command ?? {}) as { platform?: string; url?: string; username?: string; crawl_type?: string; type?: string; action?: string; text?: string; session?: unknown };
    const url = String(input.url ?? '');
    if (String(input.action ?? '').toLowerCase() === 'post') {
      const result = await this.manager.invoke({ command: 'post', platform: String(input.platform ?? ''), type: 'post', url, payload: { url, text: String(input.text ?? ''), session: input.session } });
      return { items: result.items ?? [], error: result.error, ok: result.implemented };
    }
    if (String(input.action ?? '').toLowerCase() === 'crawl-all') {
      const username = String(input.username ?? '') || this.#usernameFromUrl(url);
      const result = await this.manager.invoke({ command: 'crawl-all', platform: String(input.platform ?? ''), type: 'details', url, username });
      return { items: result.items ?? [], error: result.error, per_type: result.per_type };
    }
    const username = String(input.username ?? '') || this.#usernameFromUrl(url);
    const type = String(input.crawl_type ?? input.type ?? 'details').toLowerCase();
    const result = await this.manager.invoke({ command: 'crawl', platform: String(input.platform ?? ''), type, url, username });
    return { items: result.items ?? [], error: result.error };
  }

  #usernameFromUrl(url: string): string {
    try {
      const parts = new URL(url).pathname.split('/').filter(Boolean);
      return (parts[parts.length - 1] ?? '').replace(/^@/, '');
    }
    catch {
      return '';
    }
  }
}
