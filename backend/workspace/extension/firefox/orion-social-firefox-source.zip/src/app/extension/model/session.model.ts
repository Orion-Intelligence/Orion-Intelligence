export interface BrowserCookie {
  name: string;
  value: string;
  domain: string;
  path: string;
  secure: boolean;
  httpOnly: boolean;
  sameSite?: string;
  expirationDate?: number;
}

export interface Captured {
  cookies?: BrowserCookie[];
  localStorage?: Record<string, string>;
  sessionStorage?: Record<string, string>;
  indexedDB?: Record<string, unknown>;
  origin?: string;
  username?: string;
  userAgent?: string;
}

export interface RuntimeApi {
  runtime?: {
    sendMessage?(message: unknown, callback: (response: Captured | string | undefined) => void): void;
    lastError?: unknown;
  };
}
