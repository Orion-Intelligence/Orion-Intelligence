import { inject, Injectable, signal } from '@angular/core';
import { ExtensionRoute } from '../../extension/extension.route';
import { ApiService } from './api.service';

interface RuntimeMessaging { sendMessage(message: unknown, callback: (response: any) => void): void; lastError?: unknown; }

const RECONNECT_DELAY_MS = 5_000;
const ACK_INTERVAL_MS = 5_000;
const KEEPALIVE_INTERVAL_MS = 25_000;

@Injectable({ providedIn: 'root' })
export class SocketService {
  private readonly route = inject(ExtensionRoute);
  private readonly api = inject(ApiService);

  readonly status = signal('Disconnected');
  #socket: WebSocket | null = null;
  #retry: ReturnType<typeof setTimeout> | null = null;
  #keepAlive = false;
  #tokenWatch = false;
  #keepAliveTimer: ReturnType<typeof setInterval> | null = null;

  #report(state: string, detail = ''): void {
    const info = { state, detail, at: Date.now() };
    const scope = globalThis as unknown as {
      chrome?: { storage?: { local?: { set(v: Record<string, unknown>): void } }; runtime?: { sendMessage(m: unknown): void } };
      browser?: { storage?: { local?: { set(v: Record<string, unknown>): void } }; runtime?: { sendMessage(m: unknown): void } };
    };
    const api = scope.browser ?? scope.chrome;
    try {
      api?.storage?.local?.set({ 'orion-socket': info });
    }
    catch (error) {
      void error;
    }
    try {
      api?.runtime?.sendMessage({ type: 'orion-socket', info });
    }
    catch (error) {
      void error;
    }
  }

  #installTokenWatch(): void {
    const scope = globalThis as unknown as { chrome?: { storage?: { onChanged?: { addListener(cb: (c: Record<string, { newValue?: unknown }>, a: string) => void): void } } }; browser?: { storage?: { onChanged?: { addListener(cb: (c: Record<string, { newValue?: unknown }>, a: string) => void): void } } } };
    const onChanged = (scope.browser ?? scope.chrome)?.storage?.onChanged;
    onChanged?.addListener((changes, area) => {
      if (area !== 'local' || !('orion-token' in changes)) {
        return;
      }
      const token = changes['orion-token'].newValue;
      if (!token) {
        console.info('[orion] token cleared -> disconnect socket');
        this.disconnect();
      }
      else if (!this.#socket) {
        console.info('[orion] token set while socket down -> connect');
        this.connect();
      }
    });
  }

  connect(): void {
    console.info('[orion] socket.connect');
    if (!this.#tokenWatch) {
      this.#tokenWatch = true;
      this.#installTokenWatch();
    }
    this.#report('connecting');
    this.#keepAlive = true;
    void this.#open();
  }

  disconnect(): void {
    console.warn('[orion] socket.disconnect');
    this.#keepAlive = false;
    this.#stopKeepAlive();

    if (this.#retry) {
      clearTimeout(this.#retry);
      this.#retry = null;
    }

    const socket = this.#socket;
    this.#socket = null;
    if (socket) {
      socket.onclose = null;
      socket.close();
    }
    this.status.set('Disconnected');
    this.#report('disconnected');
  }

  async #open(): Promise<void> {
    if (this.#socket) {
      return;
    }

    this.status.set('Connecting');
    if (!await this.api.load()) {
      this.#report('no-url');
      this.status.set('Disconnected');
      this.#scheduleRetry();
      return;
    }

    const ticket = await this.#fetchTicket();
    if (this.#socket || !this.#keepAlive) {
      return;
    }

    const socketUrl = this.api.socketUrl();
    const socket = new WebSocket(ticket ? `${socketUrl}?ticket=${encodeURIComponent(ticket)}` : socketUrl);
    this.#socket = socket;

    socket.onopen = () => {
      console.info('[orion] socket OPEN', socketUrl);
      this.#report('open', socketUrl);
      this.status.set('Connection made');
      this.#startKeepAlive(socket);
    };
    socket.onmessage = (event) => this.#dispatch(socket, String(event.data));
    socket.onclose = (event) => {
      console.warn('[orion] socket CLOSE code=' + event.code + ' clean=' + event.wasClean + ' keepAlive=' + this.#keepAlive);
      this.#stopKeepAlive();
      this.#report('closed', 'code=' + event.code);
      this.#socket = null;
      this.status.set(this.#keepAlive ? 'Reconnecting' : 'Disconnected');
      this.#scheduleRetry();
    };
  }

  #startKeepAlive(socket: WebSocket): void {
    this.#stopKeepAlive();
    this.#keepAliveTimer = setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        try {
          socket.send(JSON.stringify({ keepalive: true }));
        }
        catch (error) {
          void error;
        }
      }
    }, KEEPALIVE_INTERVAL_MS);
  }

  #stopKeepAlive(): void {
    if (this.#keepAliveTimer) {
      clearInterval(this.#keepAliveTimer);
      this.#keepAliveTimer = null;
    }
  }

  #dispatch(socket: WebSocket, message: string): void {
    if (this.#relayNotification(message)) {
      return;
    }
    const stopAck = this.#acknowledge(socket, message);
    this.route.handle(message).then((result) => {
      stopAck();
      if (result && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(result));
      }
    }, (error) => {
      void error;
      stopAck();
    });
  }

  #relayNotification(message: string): boolean {
    let frame: { command?: unknown; type?: string } | null = null;
    try {
      frame = JSON.parse(message);
    }
    catch {
      return false;
    }
    if (!frame || frame.command || frame.type !== 'comm-captured') {
      return false;
    }
    const scope = globalThis as unknown as { browser?: { runtime?: { sendMessage(m: unknown): void } }; chrome?: { runtime?: { sendMessage(m: unknown): void } } };
    const runtime = scope.browser?.runtime ?? scope.chrome?.runtime;
    try {
      runtime?.sendMessage?.({ source: 'orion-extension', ...frame });
    }
    catch (error) {
      void error;
    }
    return true;
  }

  #acknowledge(socket: WebSocket, message: string): () => void {
    let requestId: string | undefined;
    try {
      requestId = (JSON.parse(message) as { request_id?: string })?.request_id;
    }
    catch (error) {
      void error;
    }
    if (!requestId) {
      return () => void 0;
    }

    const id = requestId;
    const send = () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ request_id: id, ack: true }));
      }
    };
    send();
    const timer = setInterval(send, ACK_INTERVAL_MS);
    return () => clearInterval(timer);
  }

  async #fetchTicket(): Promise<string | null> {
    const viaBackground = await this.#ticketFromBackground();
    if (viaBackground) {
      return viaBackground;
    }

    try {
      const response = await fetch(this.api.ticketUrl(), { method: 'POST', credentials: 'include' });
      const body = response.ok ? await response.json() : null;
      return body?.ticket ?? null;
    }
    catch (error) {
      void error;
      return null;
    }
  }

  #ticketFromBackground(): Promise<string | null> {
    try {
      const parent = (globalThis as unknown as { parent?: { wsTicket?: () => Promise<string | null> } }).parent;
      if (parent && (parent as unknown) !== globalThis && typeof parent.wsTicket === 'function') {
        return Promise.resolve(parent.wsTicket()).then(ticket => ticket ?? null, () => null);
      }
    }
    catch (error) {
      void error;
    }

    const runtime = (globalThis as unknown as { browser?: { runtime?: RuntimeMessaging }; chrome?: { runtime?: RuntimeMessaging } }).browser?.runtime
      ?? (globalThis as unknown as { chrome?: { runtime?: RuntimeMessaging } }).chrome?.runtime;
    return new Promise((resolve) => {
      if (!runtime?.sendMessage) {
        resolve(null);
        return;
      }
      try {
        runtime.sendMessage({ type: 'orion-ws-ticket' }, (response: { ticket?: string } | undefined) => {
          void runtime.lastError;
          resolve(response?.ticket ?? null);
        });
      }
      catch (error) {
        void error;
        resolve(null);
      }
    });
  }

  #scheduleRetry(): void {
    if (!this.#keepAlive || this.#retry) {
      return;
    }

    this.#retry = setTimeout(() => {
      this.#retry = null;
      void this.#open();
    }, RECONNECT_DELAY_MS);
  }
}
