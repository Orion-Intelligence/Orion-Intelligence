import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { computed, inject, Injectable, signal } from '@angular/core';
import { Observable } from 'rxjs';

const ORION_URL_KEY = 'orion-url';
const ORION_URLS_KEY = 'orion-urls';
const ORION_TOKEN_KEY = 'orion-token';
const LOCAL_ORIGIN = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|$)/i;

interface ExtensionStorage {
  get(keys: string[]): Promise<Record<string, unknown>>;
  set(items: Record<string, unknown>): Promise<void>;
}

interface ApiOptions {
  headers?: HttpHeaders;
  params?: HttpParams;
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);

  readonly orionUrl = signal('');
  readonly orionUrls = signal<string[]>([]);
  readonly socketState = signal('connecting');
  #socketGraceTimer: ReturnType<typeof setTimeout> | null = null;
  #token = '';
  readonly loginUrl = computed(() => `${this.orionUrl()}/login`);
  readonly socketUrl = computed(() => `${this.orionUrl().replace(/^http/, 'ws')}/api/extension/socket`);
  readonly ticketUrl = computed(() => `${this.orionUrl()}/api/extension/ws-ticket`);

  constructor() {
    void this.#storage()?.get([ORION_TOKEN_KEY]).then(v => {
      const t = (v as Record<string, unknown>)[ORION_TOKEN_KEY];
      if (typeof t === 'string') {
        this.#token = t;
      }
    });
    void this.#storage()?.get(['orion-socket']).then(v => {
      const info = (v as { 'orion-socket'?: { state?: string } })['orion-socket'];
      if (info?.state) {
        this.#setSocketState(info.state, false);
      }
    });
    this.#onChanged()?.addListener((changes, area) => {
      if (area !== 'local') {
        return;
      }
      if (changes['orion-socket']) {
        const info = changes['orion-socket'].newValue as { state?: string } | undefined;
        this.#setSocketState(info?.state ?? 'unknown', true);
      }
      if (changes[ORION_URLS_KEY]) {
        const next = changes[ORION_URLS_KEY].newValue;
        this.orionUrls.set(Array.isArray(next) ? next.filter((url): url is string => typeof url === 'string') : []);
      }
      if (changes[ORION_URL_KEY]) {
        const next = changes[ORION_URL_KEY].newValue;
        if (typeof next === 'string' && next) {
          this.orionUrl.set(next);
        }
      }
    });
  }

  #setSocketState(state: string, allowGrace: boolean): void {
    if (this.#socketGraceTimer) {
      clearTimeout(this.#socketGraceTimer);
      this.#socketGraceTimer = null;
    }
    if (state === 'open' || !allowGrace || this.socketState() !== 'open') {
      this.socketState.set(state);
      return;
    }
    this.#socketGraceTimer = setTimeout(() => {
      this.#socketGraceTimer = null;
      this.socketState.set(state);
    }, 2500);
  }

  async setToken(token: string): Promise<void> {
    const next = typeof token === 'string' ? token : '';
    if (next === this.#token) {
      return;
    }
    this.#token = next;
    await this.#storage()?.set({ [ORION_TOKEN_KEY]: this.#token });
  }

  async clearToken(): Promise<void> {
    this.#token = '';
    await this.#storage()?.set({ [ORION_TOKEN_KEY]: '' });
  }

  #authHeaders(options?: ApiOptions): HttpHeaders {
    const headers = options?.headers ?? new HttpHeaders();
    return this.#token ? headers.set('Authorization', `Bearer ${this.#token}`) : headers;
  }

  async load(): Promise<string> {
    if (!this.#storage()) {
      const url = await this.#ask();
      this.orionUrls.set(url ? [url] : []);
      this.orionUrl.set(url);
      return url;
    }

    const saved = await this.#storage()?.get([ORION_URL_KEY, ORION_URLS_KEY]) ?? {};
    const urls = Array.isArray(saved[ORION_URLS_KEY]) ? saved[ORION_URLS_KEY].filter((url): url is string => typeof url === 'string') : [];
    const selected = typeof saved[ORION_URL_KEY] === 'string' ? saved[ORION_URL_KEY] : '';
    this.orionUrls.set(urls);
    const remote = urls.find(url => !LOCAL_ORIGIN.test(url));
    this.orionUrl.set(urls.includes(selected) ? selected : remote || urls[0] || '');
    return this.orionUrl();
  }

  async select(url: string): Promise<void> {
    const current = ((await this.#storage()?.get([ORION_URL_KEY])) ?? {})[ORION_URL_KEY];
    if (url !== current) {
      await this.#storage()?.set({ [ORION_URL_KEY]: url });
    }
    this.orionUrl.set(url);
  }

  get<T>(endpoint: string, options?: ApiOptions): Observable<T> {
    return this.http.get<T>(this.#url(endpoint), {
      ...options,
      headers: this.#authHeaders(options),
      withCredentials: true
    });
  }

  post<T>(endpoint: string, body: unknown, options?: ApiOptions): Observable<T> {
    return this.http.post<T>(this.#url(endpoint), body, {
      ...options,
      headers: this.#authHeaders(options),
      withCredentials: true
    });
  }

  #url(endpoint: string): string {
    return `${this.orionUrl()}/api/${endpoint.replace(/^\/+/, '')}`;
  }

  #ask(): Promise<string> {
    const scope = globalThis as unknown as { chrome?: { runtime?: { sendMessage?(m: unknown, cb: (r: unknown) => void): void; lastError?: unknown } } };
    const runtime = scope.chrome?.runtime;
    return new Promise((resolve) => {
      if (!runtime?.sendMessage) {
        resolve('');
        return;
      }
      try {
        runtime.sendMessage({ type: 'orion-url' }, (response) => {
          void runtime.lastError;
          const url = (response as { url?: unknown } | null)?.url;
          resolve(typeof url === 'string' ? url : '');
        });
      }
      catch {
        resolve('');
      }
    });
  }

  #storage(): ExtensionStorage | null {
    const scope = globalThis as unknown as { chrome?: { storage?: { local?: ExtensionStorage } }; browser?: { storage?: { local?: ExtensionStorage } } };
    return (scope.browser ?? scope.chrome)?.storage?.local ?? null;
  }

  #onChanged(): { addListener(cb: (changes: Record<string, { newValue?: unknown }>, area: string) => void): void } | null {
    const scope = globalThis as unknown as { chrome?: { storage?: { onChanged?: { addListener(cb: (c: Record<string, { newValue?: unknown }>, a: string) => void): void } } }; browser?: { storage?: { onChanged?: { addListener(cb: (c: Record<string, { newValue?: unknown }>, a: string) => void): void } } } };
    return (scope.browser ?? scope.chrome)?.storage?.onChanged ?? null;
  }
}
