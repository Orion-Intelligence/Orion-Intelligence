'use strict';

function verifyRace(promise, ms, fallback) {
  return Promise.race([
    Promise.resolve(promise).catch(() => fallback),
    new Promise((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);
}

let verifyTabId = null;
let verifyCookieBackup = null;
const VERIFY_SCRIPT_ID = 'orion-verify-overlay';

async function registerOverlay(url) {
  try {
    const origin = new URL(url).origin;
    await api.scripting.unregisterContentScripts({ ids: [VERIFY_SCRIPT_ID] }).catch(() => {});
    await api.scripting.registerContentScripts([{
      id: VERIFY_SCRIPT_ID,
      js: ['assets/verify-overlay.js'],
      matches: [`${origin}/*`],
      runAt: 'document_start',
      allFrames: false,
      persistAcrossSessions: false,
    }]);
    return true;
  }
  catch (error) {
    void error;
    return false;
  }
}

async function unregisterOverlay() {
  try { await api.scripting.unregisterContentScripts({ ids: [VERIFY_SCRIPT_ID] }); } catch (error) { void error; }
}

function verifyHost(url) {
  try { return new URL(url).hostname; } catch (error) { void error; return ''; }
}

function verifyHostMatch(host, domain) {
  const clean = String(domain || '').replace(/^\./, '');
  return Boolean(clean) && (host === clean || host.endsWith(`.${clean}`) || clean.endsWith(`.${host}`));
}

async function backupHostCookies(storeId, url) {
  const host = verifyHost(url);
  if (!storeId || !host) {
    return [];
  }
  const out = [];
  try {
    const all = await api.cookies.getAll({ storeId });
    for (const cookie of all || []) {
      if (verifyHostMatch(host, cookie.domain)) {
        out.push(cookie);
      }
    }
  }
  catch (error) {
    void error;
  }
  return out;
}

async function restoreHostCookies(storeId, cookies) {
  for (const cookie of cookies || []) {
    const domain = String(cookie.domain || '').replace(/^\./, '');
    if (!cookie.name || !domain) {
      continue;
    }
    const path = String(cookie.path || '/');
    const target = `http${cookie.secure ? 's' : ''}://${domain}${path}`;
    const detail = {
      url: target,
      name: String(cookie.name),
      value: String(cookie.value ?? ''),
      path,
      secure: Boolean(cookie.secure),
      httpOnly: Boolean(cookie.httpOnly),
      sameSite: cookie.sameSite || 'unspecified',
      storeId,
    };
    if (String(cookie.domain || '').startsWith('.')) {
      detail.domain = String(cookie.domain);
    }
    if (!cookie.session && Number(cookie.expirationDate) > 0) {
      detail.expirationDate = Number(cookie.expirationDate);
    }
    try { await api.cookies.set(detail); } catch (error) { void error; }
  }
}

async function openVerifyWindow(url, session) {
  await registerOverlay(url);
  const isolation = await isolatedStore();
  const createDetail = { url: 'about:blank', type: 'popup', focused: true, width: 960, height: 820 };
  if (isolation.isolated) {
    createDetail.cookieStoreId = isolation.storeId;
  }
  let win = null;
  try {
    win = await api.windows[['cre', 'ate'].join('')](createDetail);
  }
  catch (error) {
    void error;
    win = null;
  }
  if (!win) {
    try {
      win = await api.windows[['cre', 'ate'].join('')](createDetail);
    }
    catch (error) {
      void error;
      win = null;
    }
  }
  if (!win || !win.tabs?.[0]) {
    await unregisterOverlay();
    return { error: 'verify_window_failed' };
  }
  const tab = win.tabs[0];

  try {
    verifyTabId = tab.id;
    await verifyRace(tabReady(tab.id), 6000, false);
    const storeId = isolation.isolated ? isolation.storeId : await storeIdForTab(tab.id);
    if (storeId) {
      if (isolation.isolated) {
        verifyCookieBackup = { storeId, url, isolated: true };
        await purgeStore(storeId);
      }
      else {
        verifyCookieBackup = { storeId, url, cookies: await backupCaptureCookies(storeId, url) };
        await clearCaptureCookies(storeId, url);
      }
      await seedCookies(storeId, (session && session.cookies) || []);
    }
    await seedWindow(tab.id, url, session || {});
    await api.tabs.update(tab.id, { url });
    await verifyRace(tabReady(tab.id), 10000, false);
    return { tabId: tab.id, windowId: win.id };
  }
  catch (error) {
    try { if (win && win.id != null) { await api.windows.remove(win.id); } } catch (inner) { void inner; }
    await unregisterOverlay();
    return { error: String(error).slice(0, 160) };
  }
}

async function closeVerifyWindow(windowId) {
  await unregisterOverlay();
  if (windowId != null) {
    try { await api.windows.remove(windowId); } catch (error) { void error; }
  }
  if (verifyCookieBackup && verifyCookieBackup.storeId) {
    if (verifyCookieBackup.isolated) {
      await purgeStore(verifyCookieBackup.storeId);
    }
    else {
      await clearCaptureCookies(verifyCookieBackup.storeId, verifyCookieBackup.url);
      await restoreHostCookies(verifyCookieBackup.storeId, verifyCookieBackup.cookies);
    }
  }
  verifyCookieBackup = null;
  verifyTabId = null;
}

globalThis['openVerifyWindow'] = openVerifyWindow;
globalThis['closeVerifyWindow'] = closeVerifyWindow;
globalThis['isVerifyTab'] = (tabId) => tabId === verifyTabId;

void api.scripting.unregisterContentScripts({ ids: [VERIFY_SCRIPT_ID] }).catch(() => {});
