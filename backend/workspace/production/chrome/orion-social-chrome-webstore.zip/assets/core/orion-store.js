'use strict';

const ORION_CONTAINER_NAME = 'Orion Social';
let orionContainerStoreId = null;

async function isolatedStore() {
  const identities = api['contextualIdentities'];
  if (!identities || typeof identities.query !== 'function') {
    return { storeId: null, isolated: false };
  }
  if (orionContainerStoreId) {
    return { storeId: orionContainerStoreId, isolated: true };
  }
  try {
    const existing = await identities.query({ name: ORION_CONTAINER_NAME });
    const identity = (existing && existing.length)
      ? existing[0]
      : await identities.create({ name: ORION_CONTAINER_NAME, color: 'blue', icon: 'briefcase' });
    orionContainerStoreId = identity.cookieStoreId;
    return { storeId: orionContainerStoreId, isolated: true };
  }
  catch (error) {
    void error;
    return { storeId: null, isolated: false };
  }
}

async function purgeStore(storeId) {
  if (!storeId) {
    return;
  }
  try {
    const all = await api.cookies.getAll({ storeId });
    for (const cookie of all || []) {
      const domain = String(cookie.domain || '').replace(/^\./, '');
      if (!domain) {
        continue;
      }
      const target = `http${cookie.secure ? 's' : ''}://${domain}${cookie.path || '/'}`;
      try { await api.cookies.remove({ url: target, name: cookie.name, storeId }); } catch (error) { void error; }
    }
  }
  catch (error) {
    void error;
  }
}

globalThis['isolatedStore'] = isolatedStore;
globalThis['purgeStore'] = purgeStore;
