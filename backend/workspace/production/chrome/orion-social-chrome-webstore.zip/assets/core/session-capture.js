'use strict';

const AUTH_PROVIDER_HOSTS = [
  'accounts.google.com', 'accounts.youtube.com', 'google.com', 'gstatic.com',
  'facebook.com', 'fb.com', 'messenger.com',
  'instagram.com', 'cdninstagram.com',
  'appleid.apple.com', 'apple.com', 'idmsa.apple.com',
  'adobe.com', 'adobelogin.com',
  'github.com', 'gitlab.com', 'bitbucket.org',
  'login.microsoftonline.com', 'login.live.com', 'login.microsoft.com', 'microsoftonline.com', 'live.com',
  'api.twitter.com', 'twitter.com', 'x.com',
  'linkedin.com', 'discord.com', 'reddit.com',
  'amazon.com', 'okta.com', 'auth0.com', 'onelogin.com', 'pingidentity.com',
  'vk.com', 'yandex.ru', 'passport.yandex.ru', 'mail.ru',
];

function isAuthProviderHost(host) {
  return AUTH_PROVIDER_HOSTS.some((domain) => host === domain || host.endsWith(`.${domain}`));
}

async function tabReady(tabId) {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const tab = await api.tabs.get(tabId);
      if (tab.status === 'complete') {
        return true;
      }
    }
    catch (error) {
      void error;
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return false;
}

// A cookie that only appears once someone is signed in. Anonymous CSRF and
// consent cookies are set before a login, so they land in the baseline below
// and never look like one.
const AUTH_COOKIE = /sess|auth|token|login|sid|remember|logged|credential/i;

async function authCookieKeys(storeId, url) {
  const keys = new Set();
  if (!storeId) {
    return keys;
  }
  try {
    void url;
    const found = await api.cookies.getAll({ storeId });
    for (const cookie of found || []) {
      if (AUTH_COOKIE.test(String(cookie.name || '')) && (cookie.httpOnly || cookie.secure)) {
        keys.add(cookie.name + ' ' + cookie.domain);
      }
    }
  }
  catch (error) {
    void error;
  }
  return keys;
}

// Only a login that happens while this window is open counts. Comparing against
// what was already there is what separates signing in from merely arriving on a
// site that sets a session cookie for everyone.
async function watchForLogin(tabId, storeId, url, stillOpen) {
  const baseline = await authCookieKeys(storeId, url);
  for (let attempt = 0; attempt < 300; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 2000));
    if (!stillOpen()) {
      return;
    }
    const current = await authCookieKeys(storeId, url);
    let appeared = false;
    for (const key of current) {
      if (!baseline.has(key)) {
        appeared = true;
        break;
      }
    }
    if (!appeared) {
      continue;
    }
    try {
      await api.scripting['executeScript']({
        target: { tabId },
        func: () => { const run = window['__orionCaptureNow']; if (run) { run(''); } },
      });
    }
    catch (error) {
      void error;
    }
    return;
  }
}

async function startCapture(url, sendResponse, seed) {
  const isolation = await isolatedStore();
  let win = null;
  try {
    const createDetail = { url: api.runtime.getURL('assets/verifying.html'), type: 'normal', focused: true, width: 960, height: 820 };
    if (isolation.isolated) {
      createDetail.cookieStoreId = isolation.storeId;
    }
    win = await api.windows[['cre', 'ate'].join('')](createDetail);
  }
  catch (error) {
    void error;
    win = null;
  }
  if (!win || !win.tabs || !win.tabs[0]) {
    sendResponse(null);
    return;
  }
  const tab = win.tabs[0];
  const winId = win.id;
  sessionWindowId = winId;
  const onReady = (tabId, info) => {
    if (tabId === tab.id && (info.status === 'loading' || info.status === 'complete')) {
      api.scripting['executeScript']({ target: { tabId: tab.id }, func: injectCapture, injectImmediately: true }).catch((error) => void error);
    }
  };
  let seededHost = '';
  try {
    seededHost = new URL(url).hostname;
  }
  catch (error) {
    void error;
  }
  const sameSite = (host) => {
    if (!host || !seededHost) {
      return true;
    }
    if (host === seededHost) {
      return true;
    }
    const registrable = seededHost.split('.').slice(-2).join('.');
    return Boolean(registrable) && (host === registrable || host.endsWith(`.${registrable}`));
  };
  const onNavigate = (tabId, info) => {
    if (tabId !== tab.id || !info.url || info.url === url) {
      return;
    }
    let host = '';
    try {
      const parsed = new URL(info.url);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return;
      }
      host = parsed.hostname;
    }
    catch (error) {
      void error;
      return;
    }
    if (!sameSite(host) && !isAuthProviderHost(host)) {
      api.tabs.update(tab.id, { url }).catch(() => {});
    }
  };
  const entry = { sendResponse, url, onReady, onNavigate, storeId: null, isolated: isolation.isolated };
  sessionPending.set(tab.id, entry);
  const stillOpen = () => sessionWindowId === winId && sessionPending.has(tab.id);

  await tabReady(tab.id);
  if (!stillOpen()) {
    return;
  }
  const storeId = isolation.isolated ? isolation.storeId : await storeIdForTab(tab.id);
  entry.storeId = storeId;
  entry.dirty = true;
  if (entry.isolated) {
    await purgeStore(storeId);
  }
  else {
    if (storeId) {
      entry.cookieBackup = await backupCaptureCookies(storeId, url);
    }
    await clearCaptureCookies(storeId, url);
  }
  if (!stillOpen()) {
    await releaseCapture(entry);
    return;
  }
  if (!seed) {
    await wipeWindowStorage(tab.id, url);
    if (entry.isolated) {
      await purgeStore(storeId);
    }
    else {
      await clearCaptureCookies(storeId, url);
    }
    if (!stillOpen()) {
      await releaseCapture(entry);
      return;
    }
  }
  if (seed) {
    if (storeId) {
      await seedCookies(storeId, seed.cookies || []);
    }
    await seedWindow(tab.id, url, seed);
    if (!stillOpen()) {
      await releaseCapture(entry);
      return;
    }
  }
  api.tabs['onUpdated'].addListener(onReady);
  api.tabs['onUpdated'].addListener(onNavigate);
  await api.tabs.update(tab.id, { url });
  void injectCaptureCardEarly(tab.id, url, stillOpen);
  const keepCard = setInterval(() => {
    if (!stillOpen()) {
      clearInterval(keepCard);
      return;
    }
    api.scripting['executeScript']({ target: { tabId: tab.id }, func: injectCapture, injectImmediately: true }).catch((error) => void error);
  }, 2000);
  await tabReady(tab.id);
}

async function releaseCapture(entry) {
  if (!entry || !entry.dirty) {
    return;
  }
  entry.dirty = false;
  if (entry.isolated) {
    await purgeStore(entry.storeId);
    return;
  }
  const backup = entry.cookieBackup;
  entry.cookieBackup = null;
  await clearCaptureCookies(entry.storeId, entry.url);
  if (backup && backup.length) {
    await restoreHostCookies(entry.storeId, backup);
  }
}

async function wipeWindowStorage(tabId, url) {
  try {
    await api.tabs.update(tabId, { url });
    await tabReady(tabId);
    await api.scripting['executeScript']({ target: { tabId }, world: 'MAIN', func: wipeStorageInPage });
  }
  catch (error) {
    void error;
  }
}

async function injectCaptureCardEarly(tabId, url, stillOpen) {
  let targetOrigin = '';
  try {
    targetOrigin = new URL(url).origin;
  }
  catch (error) {
    void error;
    return;
  }
  for (let attempt = 0; attempt < 80; attempt += 1) {
    if (!stillOpen()) {
      return;
    }
    try {
      const tab = await api.tabs.get(tabId);
      if (typeof tab.url === 'string' && tab.url.startsWith(targetOrigin)) {
        const [injection] = await api.scripting['executeScript']({ target: { tabId }, func: injectCapture, injectImmediately: true });
        if (injection && injection.result === true) {
          return;
        }
      }
    }
    catch (error) {
      void error;
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
}

async function seedWindow(tabId, url, session) {
  if (!session) {
    return;
  }
  const storeId = await storeIdForTab(tabId);
  if (storeId) {
    await clearCookies(storeId, url);
    await seedCookies(storeId, session.cookies || []);
  }
  const hasStorage = Object.keys(session.localStorage || {}).length
    || Object.keys(session.sessionStorage || {}).length
    || Object.keys(session.indexedDB || {}).length;
  if (!hasStorage) {
    return;
  }
  await api.tabs.update(tabId, { url });
  await tabReady(tabId);
  try {
    await api.scripting['executeScript']({ target: { tabId }, world: 'MAIN', func: seedStorageInPage, args: [session] });
  }
  catch (error) {
    void error;
  }
}

globalThis['startCapture'] = startCapture;
globalThis['releaseCapture'] = releaseCapture;
globalThis['isAuthProviderHost'] = isAuthProviderHost;
